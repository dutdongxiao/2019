﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;
using HTC.UnityPlugin.Vive;
public class RotateOpenClose : MonoBehaviour {

	public GameObject goHinge;
    public GameObject window;
    public Text text;
    public Font m_Font;
    public float degreesRotate = 80;
	public float secondsToOpen = 1.0f;
	public float secondsToClose;

	protected float degreesClosed;
	protected float degreesOpened;





    string editString = "dingyi"; //编辑框文字
    Socket serverSocket; //服务器端socket
    IPAddress ip; //主机ip
    string ip11;
    IPEndPoint ipEnd;
    string recvStr; //接收的字符串
    string sendStr; //发送的字符串
    byte[] recvData = new byte[1024]; //接收的数据，必须为字节
    byte[] sendData = new byte[1024]; //发送的数据，必须为字节
    int recvLen; //接收的数据长度






    protected enum HingeState
	{
		closed,
		opening,
		opened,
		closing
	}
	protected HingeState hingeState;

	protected bool isPlayerNear;
	protected float timeStartedRotation;





    void InitSocket()
    {
        while (true)
        {
            if (Global.ip111 != null)
            {
                ip11 = Global.ip111;
                break;
            }
        }
        //定义服务器的IP和端口，端口与服务器对应
        //ip11 = "192.168.199.103";
        ip = IPAddress.Parse(ip11); //可以是局域网或互联网ip，此处是本机
        //ipEnd = new IPEndPoint(ip, 8081);                    ///////////////////////////////////
        ipEnd = new IPEndPoint(ip, 8081);
        SocketConnet();
    }
    void SocketSend(string sendStr)
    {
        //清空发送缓存
        sendData = new byte[1024];
        //数据类型转换
        sendData = Encoding.ASCII.GetBytes(sendStr);
        //发送
        serverSocket.Send(sendData, sendData.Length, SocketFlags.None);
    }
    void SocketConnet()
    {
        if (serverSocket != null)
            serverSocket.Close();
        //定义套接字类型,必须在子线程中定义
        serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        print("ready to connect");
        //连接
        serverSocket.Connect(ipEnd);


        ////////////////////////////////////////////////////////////////////////SocketSend(editString);

    }



    void SocketQuit()
    {

        //最后关闭服务器
        if (serverSocket != null)
            serverSocket.Close();
        print("diconnect");
    }








    // Use this for initialization
    void Start () {
        text.font = m_Font;
        text.text = "[MENU] OPEN";
        hingeState = HingeState.closed;
        window.gameObject.SetActive(false);
		if (secondsToClose <= 0)
		{
			Debug.LogWarning("Seconds To Close must be > 0. Defaulting to 1 second.");
			secondsToClose = 1.0f;
		}
		if (secondsToOpen <= 0)
		{
			Debug.LogWarning("Seconds To Open must be > 0. Defaulting to 1 second.");
			secondsToOpen = 1.0f;
		}
		degreesClosed = goHinge.transform.eulerAngles.y;
		degreesOpened = degreesClosed + degreesRotate;
        InitSocket();
        //string[] str = File.ReadAllLines(@"D:\state.txt");
        //if (str[1][0] == '0')
        //{
        //    text.text = "[MENU] OPEN";
        //    hingeState = HingeState.closed;
        //}
        //else if (str[1][0] == '1')
        //{
        //    text.text = "[MENU] CLOSE";
        //    hingeState = HingeState.opened;
        //}


    }
	
	// Update is called once per frame
	void Update () {
        if (isPlayerNear)
            window.gameObject.SetActive(true);
        else
            window.gameObject.SetActive(false);
        string[] str = File.ReadAllLines(@"D:\state.txt");
        if (str[1][0] == '0')
        {
            text.text = "[MENU] OPEN";
            hingeState = HingeState.closed;
        }
        else if (str[1][0] == '1')
        {
            text.text = "[MENU] CLOSE";
            hingeState = HingeState.opened;
        }
        else if (str[1][0] == '2')
        {
            window.gameObject.SetActive(false);
        }
        else if (str[1][0] == '3')
        {
            window.gameObject.SetActive(false);
        }

       

        if (isPlayerNear)
		{
			if (hingeState == HingeState.closed || hingeState == HingeState.opened)
			{
				if (Input.GetKeyDown(KeyCode.R) || ViveInput.GetPressUp(HandRole.RightHand, ControllerButton.Menu))
				{
                    window.gameObject.SetActive(false);
                    hingeState = (hingeState == HingeState.closed) ? HingeState.opening : HingeState.closing;
                    if (hingeState == HingeState.closing)
                    {
                        SocketSend("CLOSE_DOOR");
                        StringBuilder builder = new StringBuilder(str[1]);
                        builder.Remove(0, 1);
                        builder.Insert(0, "2");
                        str[1] = builder.ToString();
                        File.WriteAllLines(@"D:\state.txt", str);
                    }
                    else if (hingeState == HingeState.opening)
                    {
                        SocketSend("OPEN_DOOR");
                        StringBuilder builder = new StringBuilder(str[1]);
                        builder.Remove(0, 1);
                        builder.Insert(0, "3");
                        str[1] = builder.ToString();
                        File.WriteAllLines(@"D:\state.txt", str);
                    }
                    timeStartedRotation = Time.time;
				}
			}
		}

		// Update rotation if in closing or opening state
		if (hingeState == HingeState.closing)
		{
            //SocketSend("04");
            if (InterpRotationY(goHinge.transform, timeStartedRotation, secondsToClose, degreesOpened, degreesClosed))
			{ // Done rotating
				hingeState = HingeState.closed;
                if (isPlayerNear)
                    window.gameObject.SetActive(true);
                text.text = "[MENU] OPEN";
                StringBuilder builder = new StringBuilder(str[1]);
                builder.Remove(0, 1);
                builder.Insert(0, "0");
                str[1] = builder.ToString();
                File.WriteAllLines(@"D:\state.txt", str);
            }
		}
		else if (hingeState == HingeState.opening)
		{
            //SocketSend("03");
            if (InterpRotationY(goHinge.transform, timeStartedRotation, secondsToOpen, degreesClosed, degreesOpened))
			{ // Done rotating
				hingeState = HingeState.opened;
                if (isPlayerNear)
                    window.gameObject.SetActive(true);
                text.text = "[MENU] CLOSE";
                StringBuilder builder = new StringBuilder(str[1]);
                builder.Remove(0, 1);
                builder.Insert(0, "1");
                str[1] = builder.ToString();
                File.WriteAllLines(@"D:\state.txt", str);
            }
		}
	}

	// Returns true when rotation is complete
	bool InterpRotationY(Transform trans, float timeStarted, float secondsDuration, float degreesStart, float degreesEnd)
	{

		float timeElapsed = Time.time - timeStarted;
		float interp = timeElapsed / secondsDuration;
		if (interp < 1.0f)
		{
			float degreesInterp = degreesStart + (degreesEnd - degreesStart) * interp;
			trans.eulerAngles = new Vector3(0, degreesInterp, 0);
		}
		else
		{
			trans.eulerAngles = new Vector3(0, degreesEnd, 0);
			return true;
		}
		return false;
	}

	void OnTriggerEnter(Collider other)
	{
		Debug.Log("Trigger Entered by: " + other.name);
		isPlayerNear = true;
        window.gameObject.SetActive(true);
	}
	void OnTriggerExit(Collider other)
	{
		Debug.Log("Trigger Exited by: " + other.name);
		isPlayerNear = false;
        window.gameObject.SetActive(false);
	}
}
