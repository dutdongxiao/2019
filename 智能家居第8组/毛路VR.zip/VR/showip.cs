﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class showip : MonoBehaviour
{
    private string ip;
    
    // Start is called before the first frame update
    void Start()
    {
        while (true)
        {
            if (Global.ip111 != null)
            {
                ip = Global.ip111;
                break;
            }
        }
        Debug.Log(ip);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
