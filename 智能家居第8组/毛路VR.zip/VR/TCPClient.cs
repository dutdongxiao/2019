﻿using UnityEngine;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;

[System.Serializable]
public class HomeStatus
{
    public bool door;
    public bool window;
    public bool fan;
    public bool light;
    public double temperature;
    public double humidity;
    public bool gas;
    public bool fire;
}
public static class Menuvalue
{
    public static double temperature;
    public static double humidity;
    public static bool gas;
    public static bool fire;
}


public class TCPClient : MonoBehaviour
{

    public GameObject goHinge;
    public GameObject shanye;
    public Light light;
    public float degreesRotate = 80;
    public float secondsToOpen = 1.0f;
    public float secondsToClose;
    protected float degreesClosed;
    protected float degreesOpened;
    string[] str = File.ReadAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt");
    protected enum HingeState
    {
        closed,
        opening,
        opened,
        closing
    }
    protected HingeState hingeState;
    protected float timeStartedRotation;
    int flag = 0;
    float speed = 0;
    float start_time;
    protected enum FanState
    {
        closed,
        closing,
        opening,
        opened,
    }
    protected FanState fanState;

    protected enum LightState
    {
        closed,
        opened,
    }
    protected LightState lightState;

    protected enum CurtainState
    {
        closed,
        opened,
    }
    protected CurtainState curtainState;
    private string jsonStr;

    string ip11;


















    string editString = "1"; //编辑框文字

    Socket serverSocket; //服务器端socket
    IPAddress ip; //主机ip
    IPEndPoint ipEnd;
    string recvStr; //接收的字符串
    string sendStr; //发送的字符串
    byte[] recvData = new byte[1024]; //接收的数据，必须为字节
    byte[] sendData = new byte[1024]; //发送的数据，必须为字节
    int recvLen; //接收的数据长度
    Thread connectThread; //连接线程

    //初始化
    void InitSocket()
    {
        while (true)
        {
            if (Global.ip111 != null)
            {
                ip11 = Global.ip111;
                break;
            }
        }
        //定义服务器的IP和端口，端口与服务器对应
        ip = IPAddress.Parse(ip11); //可以是局域网或互联网ip，此处是本机
        ipEnd = new IPEndPoint(ip, 8081);

        //开启一个线程连接，必须的，否则主线程卡死
        connectThread = new Thread(new ThreadStart(SocketReceive));
        connectThread.Start();
    }

    void SocketConnet()
    {
        if (serverSocket != null)
            serverSocket.Close();
        //定义套接字类型,必须在子线程中定义
        serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        print("ready to connect");
        //连接
        serverSocket.Connect(ipEnd);



        ////输出初次连接收到的字符串
        //recvLen = serverSocket.Receive(recvData);
        //recvStr = Encoding.ASCII.GetString(recvData, 0, recvLen);
        //recvStr = recvStr.Substring(0, recvStr.Length - 1);
        //print(recvStr);
    }

    void SocketSend(string sendStr)
    {
        //清空发送缓存
        sendData = new byte[1024];
        //数据类型转换
        sendData = Encoding.ASCII.GetBytes(sendStr);
        //发送
        serverSocket.Send(sendData, sendData.Length, SocketFlags.None);
    }

    void SocketReceive()
    {
        SocketConnet();
        //不断接收服务器发来的数据
        SocketSend("123");
        while (true)
        {
            recvData = new byte[1024];
            recvLen = serverSocket.Receive(recvData);
            if (recvLen == 0)
            {
                SocketConnet();
                continue;
            }
            string tmpStr = Encoding.ASCII.GetString(recvData, 0, recvLen);
            if (!tmpStr.StartsWith("{"))
            {
                return;
            }
            recvStr = tmpStr.Substring(0, tmpStr.Length - 1);
            print(recvStr);
            print(recvStr.Length);
        }
    }

    void SocketQuit()
    {
        //关闭线程
        if (connectThread != null)
        {
            connectThread.Interrupt();
            connectThread.Abort();
        }
        //最后关闭服务器
        if (serverSocket != null)
            serverSocket.Close();
        print("diconnect");
    }

    // Use this for initialization
    void Start()
    {
        hingeState = HingeState.closed;
        if (secondsToClose <= 0)
        {
            Debug.LogWarning("Seconds To Close must be > 0. Defaulting to 1 second.");
            secondsToClose = 1.0f;
        }
        if (secondsToOpen <= 0)
        {
            Debug.LogWarning("Seconds To Open must be > 0. Defaulting to 1 second.");
            secondsToOpen = 1.0f;
        }
        degreesClosed = goHinge.transform.eulerAngles.y;
        degreesOpened = degreesClosed + degreesRotate;
        start_time = Time.time;
        fanState = FanState.closed;
        str = File.ReadAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt");
        for (int i = 0; i < 4; i++)
        {
            StringBuilder builder = new StringBuilder(str[i]);
            builder.Remove(0, 1);
            builder.Insert(0, "0");
            str[i] = builder.ToString();
        }
        File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
        curtainState = CurtainState.closed;
        //jsonStr = "{\"window\": true, \"door\": true, \"temperature\": 28, \"light\": true, \"fire\": true, \"fan\": true, \"gas\": false, \"humidity\": 56}";
        InitSocket(); //在这里初始化server
    }


    bool InterpRotationY(Transform trans, float timeStarted, float secondsDuration, float degreesStart, float degreesEnd)
    {

        float timeElapsed = Time.time - timeStarted;
        float interp = timeElapsed / secondsDuration;
        if (interp < 1.0f)
        {
            float degreesInterp = degreesStart + (degreesEnd - degreesStart) * interp;
            trans.eulerAngles = new Vector3(0, degreesInterp, 0);
        }
        else
        {
            trans.eulerAngles = new Vector3(0, degreesEnd, 0);
            return true;
        }
        return false;
    }


    void switch_door(int switchflag)
    {
        if (hingeState == HingeState.closed || hingeState == HingeState.opened)
        {
            if (switchflag == 1)
            {
                if (hingeState == HingeState.closed)
                {
                    hingeState = HingeState.opening;
                    StringBuilder builder = new StringBuilder(str[1]);
                    builder.Remove(0, 1);
                    builder.Insert(0, "3");
                    str[1] = builder.ToString();
                    File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
                }
            }
            else
                if (hingeState == HingeState.opened)
            {
                hingeState = HingeState.closing;
                StringBuilder builder = new StringBuilder(str[1]);
                builder.Remove(0, 1);
                builder.Insert(0, "2");
                str[1] = builder.ToString();
                File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
            }
            timeStartedRotation = Time.time;

        }
        if (hingeState == HingeState.closing)
        {
            if (InterpRotationY(goHinge.transform, timeStartedRotation, secondsToClose, degreesOpened, degreesClosed))
            { // Done rotating
                hingeState = HingeState.closed;
                StringBuilder builder = new StringBuilder(str[1]);
                builder.Remove(0, 1);
                builder.Insert(0, "0");
                str[1] = builder.ToString();
                File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
                recvStr = "00";
            }
        }
        else if (hingeState == HingeState.opening)
        {
            if (InterpRotationY(goHinge.transform, timeStartedRotation, secondsToOpen, degreesClosed, degreesOpened))
            { // Done rotating
                hingeState = HingeState.opened;

                StringBuilder builder = new StringBuilder(str[1]);
                builder.Remove(0, 1);
                builder.Insert(0, "1");
                str[1] = builder.ToString();
                File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
                recvStr = "00";
            }
        }

    }

    void switch_dianshan(int switchflag)
    {

        if (fanState == FanState.closed || fanState == FanState.opened)
        {
            if (switchflag == 0)
            {
                if (fanState == FanState.opened)
                {

                    fanState = FanState.closing;
                    //flag = 0;
                    StringBuilder builder = new StringBuilder(str[2]);
                    builder.Remove(0, 1);
                    builder.Insert(0, "2");
                    builder.Remove(1, 1);
                    builder.Insert(1, "1");
                    str[2] = builder.ToString();
                    File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
                    recvStr = "00";
                }
            }
            else if (switchflag == 1)
            {
                if (fanState == FanState.closed)
                {
                    fanState = FanState.opening;
                    //flag = 1;
                    StringBuilder builder = new StringBuilder(str[2]);
                    builder.Remove(0, 1);
                    builder.Insert(0, "3");
                    builder.Remove(1, 1);
                    builder.Insert(1, "1");
                    str[2] = builder.ToString();
                    File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
                    recvStr = "00";
                }
            }
        }

        //if (flag == 2)                                                                                  // flag=2;  opened
        //    shanye.transform.Rotate(new Vector3(0, 30, 0) * 0.5f, Space.World);                         // flag=0;  closing
        //else
        //{
        //    shanye.transform.Rotate(new Vector3(0, speed, 0) * 0.5f, Space.World);
        //    if (flag == 0)                                                                                // flag=3;  closed
        //    {                                                                                               // flag=1;  opening
        //        if (speed < 0.1)
        //        {
        //            flag = 3;
        //            StringBuilder builder = new StringBuilder(str[2]);
        //            builder.Remove(0, 1);
        //            builder.Insert(0, "0");
        //            str[2] = builder.ToString();
        //            File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
        //            recvStr = "00";
        //            fanState = FanState.closed;
        //        }
        //        else if (Time.time - start_time >= 0.3)
        //        {
        //            speed -= 3;
        //            start_time = Time.time;
        //        }
        //    }
        //    else if (flag == 1)
        //    {
        //        if (speed > 30)
        //        {
        //            flag = 2;
        //            StringBuilder builder = new StringBuilder(str[2]);
        //            builder.Remove(0, 1);
        //            builder.Insert(0, "1");
        //            str[2] = builder.ToString();
        //            File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
        //            recvStr = "00";
        //            fanState = FanState.opened;
        //        }
        //        else if (Time.time - start_time >= 0.3)
        //        {
        //            speed += 3;
        //            start_time = Time.time;
        //        }
        //    }
        //}
    }

    private static int count = 0;
    void Update()
    {
        print(count++);
        print(recvStr);
        print(recvStr.Length);
        HomeStatus homeStatus = JsonUtility.FromJson<HomeStatus>(recvStr);
        Menuvalue.temperature = homeStatus.temperature;
        Menuvalue.fire = homeStatus.fire;
        Menuvalue.gas = homeStatus.gas;
        Menuvalue.humidity = homeStatus.humidity;
        str = File.ReadAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt");
        if (str[0][0] == '0')
        {
            lightState = LightState.closed;
        }
        else if (str[0][0] == '1')
        {
            lightState = LightState.opened;
        }
        if (str[1][0] == '0')
        {
            hingeState = HingeState.closed;
        }
        else if (str[1][0] == '1')
        {
            hingeState = HingeState.opened;
        }


        if (str[2][0] == '0')
        {
            fanState = FanState.closed;
        }
        else if (str[2][0] == '1')
        {
            fanState = FanState.opened;
        }






        if (homeStatus.light == true)//开灯
        {
            light.intensity = 3;
            StringBuilder builder = new StringBuilder(str[0]);
            builder.Remove(0, 1);
            builder.Insert(0, "1");
            str[0] = builder.ToString();
            File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
            recvStr = "00";
        }
        if (homeStatus.light == false)//关灯
        {
            light.intensity = 0;
            StringBuilder builder = new StringBuilder(str[0]);
            builder.Remove(0, 1);
            builder.Insert(0, "0");
            str[0] = builder.ToString();
            File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
            recvStr = "00";
        }

        if (homeStatus.door == true)//开门
        {
            switch_door(1);
            //recvStr = "00";
        }
        if (homeStatus.door == false)//关门
        {
            switch_door(0);
            //recvStr = "00";
        }
        if (homeStatus.fan == true)//开电扇
        {
            switch_dianshan(1);
            //recvStr = "00";
        }
        if (homeStatus.fan == true)//关电扇
        {
            switch_dianshan(0);
            //recvStr = "00";
        }
        if (homeStatus.window == true)//开窗帘
        {

            StringBuilder builder = new StringBuilder(str[3]);
            builder.Remove(0, 1);
            builder.Insert(0, "2");
            str[3] = builder.ToString();
            File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
            recvStr = "00";
        }
        if (homeStatus.window == false)//关窗帘
        {
            StringBuilder builder = new StringBuilder(str[3]);
            builder.Remove(0, 1);
            builder.Insert(0, "3");
            str[3] = builder.ToString();
            File.WriteAllLines(@"C:\Users\maoma\Desktop\zhinengjiajv2018\Assets\my\state.txt", str);
            recvStr = "00";
        }
    }
    //程序退出则关闭连接
    void OnApplicationQuit()
    {
        SocketQuit();
    }
}
