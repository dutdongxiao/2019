﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;
using HTC.UnityPlugin.Vive;
public class Curtain : MonoBehaviour
{
    public GameObject curtain1,curtain2;
    private float mount1,mount2;
    float start_time;
    public int flag;
    public GameObject window;
    public Text text;
    public Font m_Font;
    protected bool isPlayerNear1;
    protected enum CurtainState
    {
        closed,
        opened,
        closing,
        opening,
    }
    protected CurtainState curtainState;

    string editString = "dingyi"; //编辑框文字
    Socket serverSocket; //服务器端socket
    IPAddress ip; //主机ip
    IPEndPoint ipEnd;
    string ip11;
    string recvStr; //接收的字符串
    string sendStr; //发送的字符串
    byte[] recvData = new byte[1024]; //接收的数据，必须为字节
    byte[] sendData = new byte[1024]; //发送的数据，必须为字节
    int recvLen; //接收的数据长度

    // Use this for initialization


    void InitSocket()
    {
        while (true)
        {
            if (Global.ip111 != null)
            {
                ip11 = Global.ip111;
                break;
            }
        }
        //定义服务器的IP和端口，端口与服务器对应
        //ip11 = "192.168.199.103";
        ip = IPAddress.Parse(ip11); //可以是局域网或互联网ip，此处是本机
        ipEnd = new IPEndPoint(ip, 8081);
        SocketConnet();
    }
    void SocketSend(string sendStr)
    {
        //清空发送缓存
        sendData = new byte[1024];
        //数据类型转换
        sendData = Encoding.ASCII.GetBytes(sendStr);
        //发送
        serverSocket.Send(sendData, sendData.Length, SocketFlags.None);
    }
    void SocketConnet()
    {
        if (serverSocket != null)
            serverSocket.Close();
        //定义套接字类型,必须在子线程中定义
        serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        print("ready to connect");
        //连接
        serverSocket.Connect(ipEnd);


        ////////////////////////////////////////////////////////////////////////SocketSend(editString);

    }



    void SocketQuit()
    {

        //最后关闭服务器
        if (serverSocket != null)
            serverSocket.Close();
        print("diconnect");
    }









    void Start()
    {
        start_time = Time.time;
        text.font = m_Font;
        text.text = "[MENU] OPEN";
        window.gameObject.SetActive(false);
        mount1 = 0.992f;
        mount2 = 0.946f;
        curtainState = CurtainState.closed;
        //flag = 0;                                   //0 关       1开       2正在开      3正在关
        InitSocket();
    }

    // Update is called once per frame
    void Update()
    {
        if (isPlayerNear1)
            window.gameObject.SetActive(true);
        else
            window.gameObject.SetActive(false);
        string[] str = File.ReadAllLines(@"D:\state.txt");
        if (str[3][0] == '0')
        {
            text.text = "[MENU] OPEN";
            curtainState = CurtainState.closed;
        }
        else if (str[3][0] == '1')
        {
            text.text = "[MENU] CLOSE";
            curtainState = CurtainState.opened;
        }
        else if (str[3][0] == '2')
        {
            text.text = "[MENU] CLOSE";
            curtainState = CurtainState.opening;
        }
        else if (str[3][0] == '3')
        {
            text.text = "[MENU] OPEN";
            curtainState = CurtainState.closing;
        }
        if (isPlayerNear1)
        {
            if (Input.GetKeyDown(KeyCode.R) || ViveInput.GetPressUp(HandRole.RightHand, ControllerButton.Menu))
            {
                if (curtainState == CurtainState.opened || curtainState == CurtainState.opening)
                {
                    
                    curtainState = CurtainState.closing;
                    StringBuilder builder = new StringBuilder(str[3]);
                    builder.Remove(0, 1);
                    builder.Insert(0, "3");
                    str[3] = builder.ToString();
                    File.WriteAllLines(@"D:\state.txt", str);
                    SocketSend("CLOSE_WINDOW");

                }
                else
                {
                    curtainState = CurtainState.opening;
                    StringBuilder builder = new StringBuilder(str[3]);
                    builder.Remove(0, 1);
                    builder.Insert(0, "2");
                    str[3] = builder.ToString();
                    File.WriteAllLines(@"D:\state.txt", str);
                    SocketSend("OPEN_WINDOW");
                }
            }
        }
        if (curtainState == CurtainState.opening)
        {
            if ((Time.time - start_time >= 0.01) && mount2 >= 0.1)
            {
                curtain1.transform.localScale = new Vector3(mount1, 1.308656f, 2.542552f);
                curtain2.transform.localScale = new Vector3(mount2, 1.308656f, 2.542552f);
                start_time = Time.time;
                mount1 -= 0.005f;
                mount2 -= 0.005f;
            }
            else if(mount2<0.1)
            {
                curtainState = CurtainState.opened;
                StringBuilder builder = new StringBuilder(str[3]);
                builder.Remove(0, 1);
                builder.Insert(0, "1");
                str[3] = builder.ToString();
                File.WriteAllLines(@"D:\state.txt", str);
            }
        }
        else if (curtainState == CurtainState.closing)
        {
            if ((Time.time - start_time >= 0.01) && mount2 <= 0.946)
            {
                curtain1.transform.localScale = new Vector3(mount1, 1.308656f, 2.542552f);
                curtain2.transform.localScale = new Vector3(mount2, 1.308656f, 2.542552f);
                start_time = Time.time;
                mount1 += 0.005f;
                mount2 += 0.005f;
            }
            else if (mount2 > 0.946)
            {
                curtainState = CurtainState.closed;
                StringBuilder builder = new StringBuilder(str[3]);
                builder.Remove(0, 1);
                builder.Insert(0, "0");
                str[3] = builder.ToString();
                File.WriteAllLines(@"D:\state.txt", str);
            }
        }
    }

    void OnTriggerEnter(Collider other)
    {
        Debug.Log("Trigger Entered by: " + other.name);
        isPlayerNear1 = true;
        window.gameObject.SetActive(true);
    }
    void OnTriggerExit(Collider other)
    {
        Debug.Log("Trigger Exited by: " + other.name);
        isPlayerNear1 = false;
        window.gameObject.SetActive(false);
    }
}
