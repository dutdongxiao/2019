﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using HTC.UnityPlugin.Vive;
public class TV : MonoBehaviour
{
    public GameObject window;
    public Text text;
    public Font m_Font;
    public GameObject video;


    protected enum TVState
    {
        closed,
        opened,
    }
    protected TVState tvState;
    protected bool isPlayerNear1;

    // Use this for initialization
    void Start()
    {
        text.font = m_Font;
        text.text = "[MENU] OPEN";
        window.gameObject.SetActive(false);
        video.gameObject.SetActive(false);
        //Debug.Log("111");
        tvState = TVState.closed;
    }

    // Update is called once per frame
    void Update()
    {

        if (isPlayerNear1)
        {
            if (tvState == TVState.closed || tvState == TVState.opened)
            {
                if (Input.GetKeyDown(KeyCode.R) || ViveInput.GetPressUp(HandRole.RightHand, ControllerButton.Menu))
                {
                    if (tvState == TVState.opened)
                    {
                        tvState = TVState.closed;
                        text.text = "[MENU] OPEN";
                        video.gameObject.SetActive(false);
                    }
                    else
                    {
                        tvState = TVState.opened;
                        text.text = "[MENU] CLOSE";
                        video.gameObject.SetActive(true);
                    }
                }
            }
        }
        else
            window.gameObject.SetActive(false);
    }



    void OnTriggerEnter(Collider other)
    {
        Debug.Log("Trigger Entered by: " + other.name);
        isPlayerNear1 = true;
        window.gameObject.SetActive(true);
    }
    void OnTriggerExit(Collider other)
    {
        Debug.Log("Trigger Exited by: " + other.name);
        isPlayerNear1 = false;
        window.gameObject.SetActive(false);
    }
}
