﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;
using HTC.UnityPlugin.Vive;
public class LightOpenClose : MonoBehaviour {
    public GameObject window;
    public Text text;
    public Font m_Font;
    public Light light;


    string editString = "dingyi"; //编辑框文字
    Socket serverSocket; //服务器端socket
    IPAddress ip; //主机ip
    string ip11;
    IPEndPoint ipEnd;
    string recvStr; //接收的字符串
    string sendStr; //发送的字符串
    byte[] recvData = new byte[1024]; //接收的数据，必须为字节
    byte[] sendData = new byte[1024]; //发送的数据，必须为字节
    int recvLen; //接收的数据长度

    void InitSocket()
    {
        while (true)
        {
            if (Global.ip111 != null)
            {
                ip11 = Global.ip111;
                break;
            }
        }
        //定义服务器的IP和端口，端口与服务器对应
        //ip11 = "192.168.199.103";
        ip = IPAddress.Parse(ip11); //可以是局域网或互联网ip，此处是本机
        ipEnd = new IPEndPoint(ip, 8081);
        SocketConnet();
    }
    void SocketSend(string sendStr)
    {
        //清空发送缓存
        sendData = new byte[1024];
        //数据类型转换
        sendData = Encoding.ASCII.GetBytes(sendStr);
        //发送
        serverSocket.Send(sendData, sendData.Length, SocketFlags.None);
    }
    void SocketConnet()
    {
        if (serverSocket != null)
            serverSocket.Close();
        //定义套接字类型,必须在子线程中定义
        serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        print("ready to connect");
        //连接
        serverSocket.Connect(ipEnd);


        ////////////////////////////////////////////////////////////////////////SocketSend(editString);

    }



    void SocketQuit()
    {

        //最后关闭服务器
        if (serverSocket != null)
            serverSocket.Close();
        print("diconnect");
    }



    protected enum LightState
	{
		closed,
		opened,
	}
    protected LightState lightState;
    protected bool isPlayerNear1;


	void Start () {
        text.font = m_Font;
        window.gameObject.SetActive(false);
        //string[] str = File.ReadAllLines(@"D:\state.txt");
        //if (str[0][0] == '0')
        //{
        //    text.text = "[MENU] OPEN";
        //    lightState = LightState.closed;
        //    light.intensity = 0;
        //}
        //else if (str[0][0] == '1')
        //{
        //    text.text = "[MENU] CLOSE";
        //    lightState = LightState.opened;
        //    light.intensity = 3;
        //}
        InitSocket();



    }
	
	
	void Update () {

        string[] str = File.ReadAllLines(@"D:\state.txt");
        if (str[0][0] == '0')
        {
            text.text = "[MENU] OPEN";
            lightState = LightState.closed;
            light.intensity = 0;
        }
        else if (str[0][0] == '1')
        {
            text.text = "[MENU] CLOSE";
            lightState = LightState.opened;
            light.intensity = 3;
        }
        if (isPlayerNear1)
            window.gameObject.SetActive(true);
        else
            window.gameObject.SetActive(false);
        if (isPlayerNear1)
		{
			if (lightState == LightState.closed || lightState == LightState.opened)
			{
				if (Input.GetKeyDown(KeyCode.R) || ViveInput.GetPressUp(HandRole.RightHand, ControllerButton.Menu))
				{
                    if (lightState == LightState.opened)
                    {
                        StringBuilder builder = new StringBuilder(str[0]);
                        builder.Remove(0, 1);
                        builder.Insert(0, "0");
                        str[0] = builder.ToString();
                        File.WriteAllLines(@"D:\state.txt", str);
                        lightState = LightState.closed;
                        text.text = "[MENU] OPEN";
                        light.intensity = 0;
                        SocketSend("CLOSE_LIGHT");
                        
                    }
                    else 
                    {
                        StringBuilder builder = new StringBuilder(str[0]);
                        builder.Remove(0, 1);
                        builder.Insert(0, "1");
                        str[0] = builder.ToString();
                        File.WriteAllLines(@"D:\state.txt", str);
                        lightState = LightState.opened;
                        text.text = "[MENU] CLOSE";
                        light.intensity = 3;
                        SocketSend("OPEN_LIGHT");
                       
                    }
                }
			}
		}
	}

	

	void OnTriggerEnter(Collider other)
	{
		Debug.Log("Trigger Entered by: " + other.name);
		isPlayerNear1 = true;
       




        window.gameObject.SetActive(true);
	}
	void OnTriggerExit(Collider other)
	{
		Debug.Log("Trigger Exited by: " + other.name);
		isPlayerNear1 = false;
        window.gameObject.SetActive(false);
	}
}
