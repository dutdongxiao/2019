﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;
using HTC.UnityPlugin.Vive;
public class FengshanOpenClose : MonoBehaviour
{

    public GameObject shanye;
    public GameObject window;
    public Text text;
    public Font m_Font;
    int flag = 0;
    float speed = 0;
    float start_time ;




    string editString = "dingyi"; //编辑框文字
    Socket serverSocket; //服务器端socket
    IPAddress ip; //主机ip
    IPEndPoint ipEnd;
    string ip11;
    string recvStr; //接收的字符串
    string sendStr; //发送的字符串
    byte[] recvData = new byte[1024]; //接收的数据，必须为字节
    byte[] sendData = new byte[1024]; //发送的数据，必须为字节
    int recvLen; //接收的数据长度




    protected enum FanState
    {
        closed,
        closing,
        opening,
        opened,
    }
    protected FanState fanState;
    protected bool isPlayerNear1;

    // Use this for initialization







    void InitSocket()
    {
        while (true)
        {
            if (Global.ip111 != null)
            {
                ip11 = Global.ip111;
                break;
            }
        }
        //定义服务器的IP和端口，端口与服务器对应
        //ip11 = "192.168.199.103";
        ip = IPAddress.Parse(ip11); //可以是局域网或互联网ip，此处是本机
        ipEnd = new IPEndPoint(ip, 8081);
        SocketConnet();
    }
    void SocketSend(string sendStr)
    {
        //清空发送缓存
        sendData = new byte[1024];
        //数据类型转换
        sendData = Encoding.ASCII.GetBytes(sendStr);
        //发送
        serverSocket.Send(sendData, sendData.Length, SocketFlags.None);
    }
    void SocketConnet()
    {
        if (serverSocket != null)
            serverSocket.Close();
        //定义套接字类型,必须在子线程中定义
        serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        print("ready to connect");
        //连接
        serverSocket.Connect(ipEnd);


        ////////////////////////////////////////////////////////////////////////SocketSend(editString);

    }



    void SocketQuit()
    {

        //最后关闭服务器
        if (serverSocket != null)
            serverSocket.Close();
        print("diconnect");
    }














    void Start()
    {

        start_time = Time.time;
        text.font = m_Font;
        text.text = "[MENU] OPEN";
        window.gameObject.SetActive(false);
        fanState = FanState.closed;
        InitSocket();
        //string[] str = File.ReadAllLines(@"C:\Users\maoma\Desktop\智能家居2\Assets\my\Assets\Scripts\state.txt");
        //if (str[2][0] == '0')
        //{
        //    text.text = "[MENU] OPEN";
        //    fanState = FanState.closed;
        //}
        //else if (str[2][0] == '1')
        //{
        //    text.text = "[MENU] CLOSE";
        //    fanState = FanState.opened;
        //}





    }

    // Update is called once per frame
    void Update()
    {
        if (isPlayerNear1)
            window.gameObject.SetActive(true);
        else
            window.gameObject.SetActive(false);
        string[] str = File.ReadAllLines(@"D:\state.txt");
        if (str[2][0] == '0')
        {
            text.text = "[MENU] OPEN";
            fanState = FanState.closed;
        }
        else if (str[2][0] == '1')
        {
            text.text = "[MENU] CLOSE";
            fanState = FanState.opened;
            flag = 2;
        }
        else if (str[2][0] == '2')
        {
            if (str[2][1] == '1')
            {
                flag = 0;
                //fanState = FanState.closing;
                StringBuilder builder = new StringBuilder(str[2]);
                builder.Remove(1, 1);
                builder.Insert(1, "0");
                str[2] = builder.ToString();
                File.WriteAllLines(@"D:\state.txt", str);
            }
            window.gameObject.SetActive(false);
        }
        else if (str[2][0] == '3')
        {
            if (str[2][1] == '1')
            {
                flag = 1;
                StringBuilder builder = new StringBuilder(str[2]);
                builder.Remove(1, 1);
                builder.Insert(1, "0");
                str[2] = builder.ToString();
                File.WriteAllLines(@"D:\state.txt", str);
            }
            //fanState = FanState.opening;
            window.gameObject.SetActive(false);
        }
       
        if (isPlayerNear1)
        {
            if (fanState == FanState.closed || fanState == FanState.opened)
            {
                if (Input.GetKeyDown(KeyCode.R) || ViveInput.GetPressUp(HandRole.RightHand, ControllerButton.Menu))
                {
                    if (fanState == FanState.opened)
                    {
                        SocketSend("CLOSE_FAN");
                        fanState = FanState.closing;
                        flag = 0;
                        window.gameObject.SetActive(false);
                        text.text = "[MENU] OPEN";
                        StringBuilder builder = new StringBuilder(str[2]);
                        builder.Remove(0, 1);
                        builder.Insert(0, "2");
                        str[2] = builder.ToString();
                        File.WriteAllLines(@"D:\state.txt", str);
                    }
                    else if (fanState == FanState.closed)
                    {
                        SocketSend("OPEN_FAN");
                        fanState = FanState.opening;
                        flag = 1;
                        window.gameObject.SetActive(false);
                        text.text = "[MENU] CLOSE";
                        StringBuilder builder = new StringBuilder(str[2]);
                        builder.Remove(0, 1);
                        builder.Insert(0, "3");
                        str[2] = builder.ToString();
                        File.WriteAllLines(@"D:\state.txt", str);
                    }
                }
                    
            }
        }
        if (flag == 2)                                                                                  // flag=2;  opened
            shanye.transform.Rotate(new Vector3(0, 30, 0) * 0.5f, Space.World);                         // flag=0;  closing
        else
        {
            shanye.transform.Rotate(new Vector3(0, speed, 0) * 0.5f, Space.World);
            if (flag == 0)                                                                                // flag=3;  closed
            {                                                                                               // flag=1;  opening
                if (speed < 0.1)
                {
                    flag = 3;
                    StringBuilder builder = new StringBuilder(str[2]);
                    builder.Remove(0, 1);
                    builder.Insert(0, "0");
                    str[2] = builder.ToString();
                    File.WriteAllLines(@"D:\state.txt", str);
                    fanState = FanState.closed;
                    if (isPlayerNear1)
                        window.gameObject.SetActive(true);
                }
                else if (Time.time - start_time >= 0.3)
                {
                    speed -= 3;
                    start_time = Time.time;
                }
            }
            else if (flag == 1)
            {
                if (speed > 30)
                {
                    flag = 2;
                    StringBuilder builder = new StringBuilder(str[2]);
                    builder.Remove(0, 1);
                    builder.Insert(0, "1");
                    str[2] = builder.ToString();
                    File.WriteAllLines(@"D:\state.txt", str);
                    fanState = FanState.opened;
                    if (isPlayerNear1)
                        window.gameObject.SetActive(true);
                }
                else if (Time.time - start_time >= 0.3)
                {
                    speed += 3;
                    start_time = Time.time;
                }
            }
        }
    }



    void OnTriggerEnter(Collider other)
    {
        Debug.Log("Trigger Entered by: " + other.name);
        isPlayerNear1 = true;
        window.gameObject.SetActive(true);
    }
    void OnTriggerExit(Collider other)
    {
        Debug.Log("Trigger Exited by: " + other.name);
        isPlayerNear1 = false;
        window.gameObject.SetActive(false);
    }
}
