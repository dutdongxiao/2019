﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuList : MonoBehaviour
{
    public GameObject window;
    public Text text1;
    public Text text2;
    public Text text3;
    public Text text4;
    public Text text5;
    protected bool isPlayerNear1;
    protected DateTime dt;
    // Use this for initialization
    void Start()
    {
        
        window.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        dt = DateTime.Now;
        string time=dt.ToString("yyyy-MM-dd\nHH:mm:ss");

        text5.text = time;
        //string str2= Menuvalue.temperature.ToString()+"00000";
        //text1.text = str2.Substring(0,4)+ "°C";
        text1.text = String.Format("{0:0.0}", Menuvalue.temperature) + "°C";
        text2.text = String.Format("{0:0.0}", Menuvalue.humidity) + "%RH";
        text3.text = Menuvalue.fire ? "YES" : "NO";
        text4.text = Menuvalue.gas ? "YES" : "NO";
    }



    void OnTriggerEnter(Collider other)
    {
        Debug.Log("Trigger Entered by: " + other.name);
        isPlayerNear1 = true;
        window.gameObject.SetActive(true);
    }
    void OnTriggerExit(Collider other)
    {
        Debug.Log("Trigger Exited by: " + other.name);
        isPlayerNear1 = false;
        window.gameObject.SetActive(false);
    }
}
