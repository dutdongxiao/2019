#_*_ coding:UTF-8 _*_
import threading
import socket
from cmd import CMD
import json
import types
import serial
import ip_broadcast
import time
#import voice_all

import snowboydecoder
import sys
import signal
import pyaudio
import wave
import os
from aip import AipSpeech
import re
#import faceface


# 人脸识别
############################################

import cv2
import numpy as np
import base64
import urllib, urllib2, sys
import ssl


# fps = 0
# fcounter = 0    
# facefind = 0
# count = 0
# owner = 0
'''
targetPath = os.getcwd() + os.path.sep + 'getdata'
print (targetPath)
if not os.path.exists(targetPath):
    os.makedirs(targetPath)
    print('makdir getdata')
else:
    print('the path exit')
    
targetPath = os.getcwd() + os.path.sep + 'image'
print (targetPath)
if not os.path.exists(targetPath):
    os.makedirs(targetPath)
    print('makdir image')
else:
    print('the path exit')
    
    
t_start = time.time()
fps = 0




cam = cv2.VideoCapture(0)
cam.set(3, 320) # set video width
cam.set(4, 240) # set video height
 
face_detector = cv2.CascadeClassifier('./haarcascade_frontalface_default.xml')
 
# For each person, enter one numeric face id
#face_id = input('enter user id (int): ')
face_id = 1
#print("Initializing face capture. Look the camera and wait ...")
# Initialize individual sampling face count
count = 0
owner = 0
'''


ser = serial.Serial("/dev/ttyAMA0",115200)



def transimage(imagePath):
    f = open(imagePath,'rb')
    img = base64.b64encode(f.read())
    return img
    
    
def dict_get(dict, objkey, default):
    tmp = dict
    for k,v in tmp.items():
        if k == objkey:
            return v
        else:
            if type(v) is types.DictType:
                ret = dict_get(v, objkey, default)
                if ret is not default:
                    return ret
    return default

'''
user1ImageEncode = transimage('./image/Han.jpg')
user2ImageEncode = transimage('./image/Yue.jpg')
user3ImageEncode = transimage('./image/Mao.jpg')
'''


def face():
    
    
    # try:
        # os.system('../mjpg/.stopVideo.sh')
    # except:
        # print("can't stop the video,maybe the video is already close")
    fps = 0
    fcounter = 0    
    facefind = 0
    #count = 0
    #owner = 0

    
    targetPath = os.getcwd() + os.path.sep + 'getdata'
    print (targetPath)
    if not os.path.exists(targetPath):
        os.makedirs(targetPath)
        print('makdir getdata')
    else:
        print('the path exit')
        
    targetPath = os.getcwd() + os.path.sep + 'image'
    print (targetPath)
    if not os.path.exists(targetPath):
        os.makedirs(targetPath)
        print('makdir image')
    else:
        print('the path exit')
        
        
    t_start = time.time()
    #fps = 0




    cam = cv2.VideoCapture(0)
    cam.set(3, 320) # set video width
    cam.set(4, 240) # set video height
     
    face_detector = cv2.CascadeClassifier('./haarcascade_frontalface_default.xml')
     
    # For each person, enter one numeric face id
    #face_id = input('enter user id (int): ')
    face_id = 1
    #print("Initializing face capture. Look the camera and wait ...")
    # Initialize individual sampling face count
    count = 0
    owner = 0
    #global fps
    print("Initializing face capture. Look the camera and wait ...")
    
    
    user1ImageEncode = transimage('./image/Han.jpg')
    #user2ImageEncode = transimage('./image/Yue.jpg')
    user3ImageEncode = transimage('./image/Mao.jpg')




    while(True):
        ret, img = cam.read()
        #print('3333')
        #######帧数为 fcounter !!!
        if fcounter == 8: 
            fcounter = 0
            #img = cv2.flip(img, -1) # flip video image vertically
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            #print('eee')
            faces = face_detector.detectMultiScale(
                gray
                #scaleFactor=1.2,
                #minNeighbors=5,
                #minSize=(20, 20)
            )
            
            if str( len( faces ) ) != '0':
                facefind = 1
                facess = faces 
            else:
                facefind = 0
            
            
            #print('ffff')
            for (x,y,w,h) in faces:
                cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0), 2)
                count += 1
                # Save the captured image into the datasets folder
                cv2.imwrite("./getdata/User." + str(face_id) + '.' + str(count) + ".jpg", gray[y:y+h,x:x+w])
                print("User."+ str(face_id)+'.'+str(count)+'/15.jpg')
                nowImagePath = "./getdata/User." + str(face_id) + '.' + str(count) + ".jpg"
                
                nowImageEncode = transimage(nowImagePath)
                
                facess = faces
                
                request_url = "https://aip.baidubce.com/rest/2.0/face/v3/match"

                ####user1
                params = json.dumps(
                    [{"image": nowImageEncode, "image_type": "BASE64", "face_type": "LIVE", "quality_control": "LOW"},
                    {"image": user1ImageEncode, "image_type": "BASE64", "face_type": "IDCARD", "quality_control": "LOW"}])

                access_token = '24.0c3d44ff917beeaa71e88477b5a3d70c.2592000.1564299638.282335-16667678'
                
                #print(access_token)
                request_url = request_url + "?access_token=" + access_token
                request = urllib2.Request(url=request_url, data=params)
                request.add_header('Content-Type', 'application/json')
                response = urllib2.urlopen(request)
                content = response.read()
                if content:
                    #print(type(content))
                    contentToDictionary = json.loads(content) ##string To dictionary
                    #print(type(contentToDictionary))
                    score = dict_get(contentToDictionary, 'score', 0)
                    #print contentToDictionary
                    error_code = contentToDictionary.get('error_code')
                    stringScore = 'score: ' + str(score)
                    stringErr = 'error_code: ' + str(error_code)
                    print(stringErr)
                    print(stringScore)
                    if (error_code == 0) & (score >= 90):
                        owner = 1
                        print ('Welcome come back,Han')

                #####> 90 break         owner = 1
                
                '''
                ####user2
                params2 = json.dumps(
                    [{"image": nowImageEncode, "image_type": "BASE64", "face_type": "LIVE", "quality_control": "LOW"},
                    {"image": user2ImageEncode, "image_type": "BASE64", "face_type": "IDCARD", "quality_control": "LOW"}])
                request2 = urllib2.Request(url=request_url, data=params2)
                request2.add_header('Content-Type', 'application/json')
                response2 = urllib2.urlopen(request2)
                content2 = response2.read()
                if content2:
                    content2ToDictionary = json.loads(content2) ##string To dictionary
                    #print(content2ToDictionary)
                    score2 = dict_get(content2ToDictionary, 'score', 0)
                    error_code2 = content2ToDictionary.get('error_code')
                    stringScore2 = 'core2: ' + str(score2)
                    stringErr2 = 'error_code: ' + str(error_code2)
                    print(stringErr2)
                    print(stringScore2)
                    if (error_code2 == 0) & (score2 >= 90):
                        owner = 1
                        print ('Welcome come back,Yue!')
                    #print content2
                #####> 90 break         owner = 1
                '''
                
                params3 = json.dumps(
                    [{"image": nowImageEncode, "image_type": "BASE64", "face_type": "LIVE", "quality_control": "LOW"},
                    {"image": user3ImageEncode, "image_type": "BASE64", "face_type": "IDCARD", "quality_control": "LOW"}])
                request3 = urllib2.Request(url=request_url, data=params3)
                request3.add_header('Content-Type', 'application/json')
                response3 = urllib2.urlopen(request3)
                content3 = response3.read()
                if content3:
                    content3ToDictionary = json.loads(content3) ##string To dictionary
                    #print(content2ToDictionary)
                    score3 = dict_get(content3ToDictionary, 'score', 0)
                    error_code3 = content3ToDictionary.get('error_code')
                    stringScore3 = 'core3: ' + str(score3)
                    stringErr3 = 'error_code: ' + str(error_code3)
                    print(stringErr3)
                    print(stringScore3)
                    if (error_code3 == 0) & (score3 >= 90):
                        owner = 1
                        print ('Welcome come back,Mao!')
        else:
            if facefind == 1 and str( len( facess ) ) != '0':
                #print("Found " + str( len( faces ) ) + " face(s)")
                for (x,y,w,h) in facess:
                    cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
                    #roi_gray = gray[y:y+h, x:x+w]
                    #roi_color = image[y:y+h, x:x+w]
                    
        fcounter += 1
        # Calculate and show the FPS
        fps = fps + 1
        sfps = fps / ( time.time() - t_start )
        cv2.putText( img, "FPS : " + str( int( sfps ) ), ( 10, 10 ), cv2.FONT_HERSHEY_SIMPLEX, 0.5, ( 0, 0, 255 ), 2 )   
        
        
        cv2.imshow('image', img)
            
        k = cv2.waitKey(100) & 0xff # Press 'ESC' for exiting video
        
        if k == 27:
            break
            
        elif count >= 15: # Take 30 face sample and stop video
            os.system('mplayer %s' % './sound/shibieshibai.mp3')
            break
        elif owner == 1:
            home_status['door'] = True
            try:
                ser.write(b'g$')
            except:
                print("Can't write to stm32 in face")
            try:
                send_to_all()
            except:
                print("Can't send to all in face")
            finally:
                os.system('mplayer %s' % './sound/huanyinghuijia.mp3')
                break
    
    
    print("\n [INFO] Exiting Program and cleanup stuff")
    cam.release()
    cv2.destroyAllWindows()
    
    #os.system('../mjpg/startVideo.sh')
         
         
         
         
         
############################################



reload(sys)
sys.setdefaultencoding('utf-8')

os.close(sys.stderr.fileno())

APP_ID = '16644104'
API_KEY = 'Xkv8GDTPnPphP6j1AdPt6H9L'
SECRET_KEY = 'Gj8D8LNDDR7iqgHwZ0IiIbgQImoiBK7r'


interrupted = False



def signal_handler(signal, frame):
    global interrupted
    interrupted = True


def interrupt_callback():
    global interrupted
    return interrupted


def get_file_content(filePath):
    with open(filePath, 'rb') as fp:
        return fp.read()


def callbacks():
    
    global home_status
    
    global detector
    
    #snowboydecoder.play_audio_file()
    #snowboydecoder.play_audio_file()
    os.system('mplayer %s' % './sound/zaine.mp3')
    
    detector.terminate()
    
    
    
    CHUNK = 1024
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 16000
    RECORD_SECONDS = 3
    WAVE_OUTPUT_FILENAME = "./sound/output.pcm"


    targetPath = os.getcwd() + os.path.sep + 'sound'
    print (targetPath)
    if not os.path.exists(targetPath):
        os.makedirs(targetPath)
        print('makdir sound')
    else:
        print('the path exit')
    #print('p=pyaudio')
    p = pyaudio.PyAudio()
    #print('get pyaudio')
    
    
    time.sleep(0.1)


    
    stream = p.open(format=FORMAT,
                channels=CHANNELS,
                rate=RATE,
                input=True,
                frames_per_buffer=CHUNK)
    print('开门,开灯,打开窗帘,打开风扇,人脸识别,关闭警告')
    print("recording...")

    frames = []

    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
        data = stream.read(CHUNK)
        frames.append(data)
    print("over...")
    
    
    stream.stop_stream()
    stream.close()
    p.terminate()

    wf = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    wf.writeframes(b''.join(frames))
    wf.close()
    
    
    client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)
    
    
    
    
    print('upload...')
    content = client.asr(get_file_content(WAVE_OUTPUT_FILENAME), 'pcm', 16000, {
        'dev_pid': 1536,
    })

    if content:
        #print type(content)
        #print(content)
        result = content.get('result')
        #print type(result)
        resultStr = str(result)
        #print type(resultStr)
        resultUni = resultStr.decode("unicode-escape")
        #print type(resultUni)
        resultUtf = resultUni.encode('utf-8')
        print('识别结果：')
        print(type(resultUtf))
        print(resultUtf)
        #a = "[u'开灯']"
        #print(type(a))
        #print(a)
        
        if resultUtf == "[u'开灯']":
            #if home_status['light'] == True:
            #    os.system('mplayer %s' % './sound/open_light_already.mp3')
            #    print('the light is already open!')
            #else:
            #    #open_light()
                home_status['light'] = True
                try:
                    send_to_all()
                except:
                    print("!!!EXCEPT:can't send to all!")
                try:
                    ser.write(b'a$')
                except:
                    print("!!!EXCEPT:can't write to stm32!")
                finally:
                    #os.system('mplayer %s' % './sound/open_light.mp3')
                    os.system('mplayer %s' % './sound/open_light_already.mp3')
                    print('正在开灯')


        elif resultUtf == "[u'关灯']":
            #if home_status['light'] == False:
            #    os.system('mplayer %s' % './sound/close_light_already.mp3')
            #    print('the light is already close!')
            #else:
            #    #close_light()
                home_status['light'] = False
                try:
                    send_to_all()
                except:
                    print("!!!EXCEPT:can't send to all!")
                try:
                    ser.write(b'b$')
                except:
                    print("!!!EXCEPT:can't write to stm32!")
                finally:
                    #os.system('mplayer %s' % './sound/close_light.mp3')
                    os.system('mplayer %s' % './sound/close_light_already.mp3')
                    print('正在关灯')


        elif resultUtf == "[u'打开窗帘']":
            #if home_status['window'] == True:
            #    os.system('mplayer %s' % './sound/open_window_already.mp3')
            #    print('the window is already open!')
            #else:
            #    #open_window()
                home_status['window'] = True
                try:
                    send_to_all()
                except:
                    print("!!!EXCEPT:can't send to all!")
                try:
                    ser.write(b'e$')
                except:
                    print("!!!EXCEPT:can't write to stm32!")
                finally:
                    #os.system('mplayer %s' % './sound/open_window.mp3')
                    os.system('mplayer %s' % './sound/open_window_already.mp3')
                    print('正在打开窗帘')


        elif resultUtf == "[u'关闭窗帘']":
            #if home_status['window'] == False:
            #    os.system('mplayer %s' % './sound/close_window_already.mp3')
            #    print('the window is already close!')
            #else:
            #    #close_window()
                home_status['window'] = False
                try:
                    send_to_all()
                except:
                    print("!!!EXCEPT:can't send to all!")
                try:
                    ser.write(b'f$')
                except:
                    print("!!!EXCEPT:can't write to stm32!")
                finally:
                    #os.system('mplayer %s' % './sound/close_window.mp3')
                    os.system('mplayer %s' % './sound/close_window_already.mp3')
                    print('正在关闭窗帘')


        elif resultUtf == "[u'打开风扇']":
            #if home_status['fan'] == True:
            #    os.system('mplayer %s' % './sound/open_fan_already.mp3')
            #    print('the fan is already open!')
            #else:
                home_status['fan'] = True
                try:
                    send_to_all()
                except:
                    print("!!!EXCEPT:can't send to all!")
                try:
                    ser.write(b'c$')
                except:
                    print("!!!EXCEPT:can't write to stm32!")
                finally:
                    #os.system('mplayer %s' % './sound/open_fan.mp3')
                    os.system('mplayer %s' % './sound/open_fan_already.mp3')
                    print('正在打开风扇')


        elif resultUtf == "[u'关闭风扇']":
            #if home_status['fan'] == False:
            #    os.system('mplayer %s' % './sound/close_fan_already.mp3')
            #    print('the fan is already close!')
            #else:
            #    #close_fan()
                home_status['fan'] = False
                try:
                    send_to_all()
                except:
                    print("!!!EXCEPT:can't send to all!")
                try:
                    ser.write(b'd$')
                except:
                    print("!!!EXCEPT:can't write to stm32!")
                finally:
                    #os.system('mplayer %s' % './sound/close_fan.mp3')
                    os.system('mplayer %s' % './sound/close_fan_already.mp3')
                    print('正在关闭风扇')
                    
                    
        elif resultUtf == "[u'开门']":
            #if home_status['fan'] == True:
            #    os.system('mplayer %s' % './sound/open_door_already.mp3')
            #    print('the fan is already open!')
            #else:
                home_status['door'] = True
                try:
                    send_to_all()
                except:
                    print("!!!EXCEPT:can't send to all!")
                try:
                    ser.write(b'g$')
                except:
                    print("!!!EXCEPT:can't write to stm32!")
                finally:
                    #os.system('mplayer %s' % './sound/open_door.mp3')
                    os.system('mplayer %s' % './sound/open_door_already.mp3')
                    print('正在开门')     

        elif resultUtf == "[u'关门']":
            #if home_status['fan'] == True:
            #    os.system('mplayer %s' % './sound/close_door_already.mp3')
            #    print('the fan is already open!')
            #else:
                home_status['door'] = False
                try:
                    send_to_all()
                except:
                    print("!!!EXCEPT:can't send to all!")
                try:
                    ser.write(b'h$')
                except:
                    print("!!!EXCEPT:can't write to stm32!")
                finally:
                    #os.system('mplayer %s' % './sound/close_door.mp3')
                    os.system('mplayer %s' % './sound/close_door_already.mp3')
                    print('正在关门')
                    
                    
        elif resultUtf == "[u'人脸识别']":
            try:
                face()
            except:
                print('except in face()')
                
        elif resultUtf == "[u'关闭警告']":
            home_status['fire'] = False
            home_status['gas'] = False
            try:
                send_to_all()
            except:
                print("!!!EXCEPT:can't send to all!")
            try:
                ser.write(b'l$')
            except:
                print("!!!EXCEPT:can't write to stm32!")
            finally:
                os.system('mplayer %s' % './sound/close_warning.mp3')
                print('正在关闭警告')
        
        
    wake_up()    # wake_up —> monitor —> wake_up  递归调用










'''
if len(sys.argv) == 1:
    print("Error: need to specify model name")
    print("Usage: python demo.py your.model")
    sys.exit(-1)

model = sys.argv[1]

# capture SIGINT signal, e.g., Ctrl+C
signal.signal(signal.SIGINT, signal_handler)

detector = snowboydecoder.HotwordDetector(model, sensitivity=0.5)
print('Listening... Press Ctrl+C to exit')

# main loop
detector.start(detected_callback=detected2,
               interrupt_check=interrupt_callback,
               sleep_time=10)

detector.terminate()
'''



def wake_up():

    #if len(sys.argv) == 1:
     #   print("Error: need to specify model name")
      #  print("Usage: python demo.py your.model")
      #  sys.exit(-1)
    
    #print('wake up')
    global detector
    #model = sys.argv[1]
    
    model = 'xiaobaixiaobai.pmdl'
    #model = 'zhenyongzoukai.pmdl'  #  唤醒词为 SnowBoy
    # capture SIGINT signal, e.g., Ctrl+C

    
    
    #########  CTRL+c  ##########
    #signal.signal(signal.SIGINT, signal_handler)
    #########  CTRL+c  ##########
    
    


    # 唤醒词检测函数，调整sensitivity参数可修改唤醒词检测的准确性
    detector = snowboydecoder.HotwordDetector(model, sensitivity=0.5)
    print('Listening... please say wake-up word:SnowBoy')
    # main loop
    # 回调函数 detected_callback=snowboydecoder.play_audio_file 
    # 修改回调函数可实现我们想要的功能
    detector.start(detected_callback=callbacks,      # 自定义回调函数
                   interrupt_check=interrupt_callback,
                   sleep_time=0.03)
    # 释放资源
    detector.terminate()


'''
if __name__ == '__main__':

    wake_up()

    #  关闭snowboy功能
    #detector.terminate()
    #  开启语音识别
    #recordMonitor.monitor()
    # 打开snowboy功能
    #wake_up()    # wake_up —> monitor —> wake_up  递归调用
'''

def begin_voice():
    #print('begin voice')
    wake_up()

    #  关闭snowboy功能
    #detector.terminate()
    #  开启语音识别
    #recordMonitor.monitor()
    # 打开snowboy功能
    #wake_up()    # wake_up —> monitor —> wake_up  递归调用




def open_window():
    #print(CMD.OPEN_WINDOW)
    dataToStm32 = b'e$'
    print('write to stm32(OW): ' + dataToStm32)
    ser.write(dataToStm32)
    #pass
    


def close_window():
    #print(CMD.CLOSE_WINDOW)
    dataToStm32 = b'f$'
    print('write to stm32(CW): ' + dataToStm32)
    ser.write(dataToStm32)
    #pass


def open_fan():
    #print(CMD.OPEN_FAN)
    dataToStm32 = b'c$'
    print('write to stm32(OF): ' + dataToStm32)
    ser.write(dataToStm32)
    #pass


def close_fan():
    #print(CMD.CLOSE_FAN)
    dataToStm32 = b'd$'
    print('write to stm32(CF): ' + dataToStm32)
    ser.write(dataToStm32)
    #pass


def open_light():
    #print(CMD.OPEN_LIGHT)
    dataToStm32 = 'a$'
    print('write to stm32(OL): ' + dataToStm32)
    ser.write(dataToStm32)
    #pass


def close_light():
    #print(CMD.CLOSE_LIGHT)
    dataToStm32 = b'b$'
    print('write to stm32(CL): ' + dataToStm32)
    ser.write(dataToStm32)
    #pass


def open_door():
    #print(CMD.OPEN_DOOR)
    dataToStm32 = b'g$'
    print('write to stm32(OD): ' + dataToStm32)
    ser.write(dataToStm32)


def close_door():
    #print(CMD.CLOSE_DOOR)
    dataToStm32 = b'h$'
    print('write to stm32(CD): ' + dataToStm32)
    ser.write(dataToStm32)


home_status = {
    'temperature': 28,
    'humidity': 56,
    'gas': False, #no gas 
    'fire': False, #no fire
    'door': False, #open
    'window': False, #close
    'fan': False, #close
    'light': False #open
}

socket_set = set()

def send(sock, data):
    print(data)
    sock.send(data.encode())

def tcpLink(sock, addr):
    print("connected...")
    global socket_set
    global home_status
    socket_set.add(sock)
    try:
        send(sock, json.dumps(home_status) + '|')
        while True:
            data = sock.recv(1024)
            print(data)
            if data == CMD.CLOSE or not data:
                break
                
            elif data == CMD.OPEN_WINDOW:
                if home_status['window'] == True:
                    print('the window is already open!')
                else:
                    try:
                        open_window()
                    except:
                        print("can't write to stm32")
                    finally:
                        home_status['window'] = True
                        send_to_all()
                    
            elif data == CMD.CLOSE_WINDOW:
                if home_status['window'] == False:
                    print('the window is already close!')
                else:
                    try:
                        close_window()
                    except:
                        print("can't write to stm32")
                    finally:
                        home_status['window'] = False
                        send_to_all()
                    
            elif data == CMD.OPEN_FAN:
                if home_status['fan'] == True:
                    print('the fan is already open!')
                else:
                    try:
                        open_fan()
                    except:
                        print("can't write to stm32")
                    finally:
                        home_status['fan'] = True
                        send_to_all()
                    
            elif data == CMD.CLOSE_FAN:
                if home_status['fan'] == False:
                    print('the fan is already close!')
                else:
                    try:
                        close_fan()
                    except:
                        print("can't write to stm32")
                    finally:
                        home_status['fan'] = False
                        send_to_all()
                    
            elif data == CMD.OPEN_LIGHT:
                if home_status['light'] == True:
                    print('the light is already open!')
                else:
                    try:
                        open_light()
                    except:
                        print("can't write to stm32")
                    finally:
                        home_status['light'] = True
                        send_to_all()
                    
            elif data == CMD.CLOSE_LIGHT:
                if home_status['light'] == False:
                    print('the light is already close!')
                else:
                    try:
                        close_light()
                    except:
                        print("can't write to stm32")
                    finally:
                        home_status['light'] = False
                        send_to_all()
                    
            elif data == CMD.OPEN_DOOR:
                if home_status['door'] == True:
                    print('the Door is already open!')
                else:
                    try:
                        open_door()
                    except:
                        print("can't write to stm32")
                    finally:
                        home_status['door'] = True
                        send_to_all()
                    
            elif data == CMD.CLOSE_DOOR:
                if home_status['door'] == False:
                    print('the Door is already close!')
                else:
                    try:
                        close_door()
                    except:
                        print("can't write to stm32")
                    finally:
                        home_status['door'] = False
                        send_to_all()
    finally:
        print('close socket')
        socket_set.discard(sock)
        sock.close()
        
        
def startTcp():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('', 8081))
    s.listen(100)

    print('waiting for connection...')

    while True:
        sock, addr = s.accept()
        t = threading.Thread(target=tcpLink, args=(sock, addr))
        t.start() 
    s.close()
    
    
def send_to_all():
    global socket_set
    global home_status
    for sock in socket_set:
        send(sock, json.dumps(home_status) + '|')
    

def listen_stm32():
    print('listen stm32...')
    global home_status
    while True:
        #print('ser.inWaiting...')
        count = ser.inWaiting()
        if count != 0:
            print('count != 0')
            recv = ser.read(count)
            print('get: ')
            print (type(recv))
            print(recv)

            if recv == b'a':
                if home_status['light'] == True:
                    print('the light is already open!')
                else:
                    home_status['light'] = True
                    try:
                        send_to_all()
                    except:
                        print("Can't send to all in listen_stm32!")

            elif recv == b'b':
                if home_status['light'] == False:
                    print('the light is already close!')
                else:
                    home_status['light'] = False
                    try:
                        send_to_all()
                    except:
                        print("Can't send to all in listen_stm32!")
                        
            elif recv == b'c':
                if home_status['fan'] == True:
                    print('the fan is already open!')
                else:
                    home_status['fan'] = True
                    try:
                        send_to_all()
                    except:
                        print("Can't send to all in listen_stm32!")
                       
            elif recv == b'd':
                if home_status['fan'] == False:
                    print('the fan is already close!')
                else:
                    home_status['fan'] = False
                    try:
                        send_to_all()
                    except:
                        print("Can't send to all in listen_stm32!")
                        
            elif recv == b'e':
                if home_status['window'] == True:
                    print('the window is already open')
                else:
                    home_status['window'] = True
                    try:
                        send_to_all()
                    except:
                        print("Can't send to all in listen_stm32!")
                        
            elif recv == b'f':
                if home_status['window'] == False:
                    print('the window is already close')
                else:
                    home_status['window'] = False
                    try:
                        send_to_all()
                    except:
                        print("Can't send to all in listen_stm32!")
                        
            elif recv == b'i':
                home_status['gas'] == True
                home_status['fire'] == True
                try:
                    send_to_all()
                except:
                    print("Can't send to all in listen_stm32!")
                #finally:
                    #time.sleep(3)
                    #try:
                    #    send_to_all()
                    #except:
                    #    print("Can't send to all in listen_stm32!")
                        
            else:
                #print('in temperature')
                #pattern = recv.compile(r'\d+')
                try:
                    res = re.findall(r"\d+\.?\d*",recv)
                    #print(type(res[0]))
                    home_status['temperature'] = res[0]
                    home_status['humidity'] = res[1]
                    print('temperature: ' + res[0])
                    #print(res[0])
                    print('humidity: ' + res[1])
                    #home_status['temperature'] = unicode(res[0], 'utf-8', 'ignore')
                    #print ('temperature: ' + unicode(res[0], 'utf-8', 'ignore'))
                    #home_status['humidity'] = unicode(res[1], 'utf-8', 'ignore')
                    #print ('humidity: ' + unicode(res[1], 'utf-8', 'ignore'))
                    try:
                        send_to_all()
                    except:
                        print("Can't send to all in listen_stm32!")
                except:
                    print('recv is not completed')
        ser.flushInput()
        time.sleep(0.1)



'''
import re

string="A1.45，b5，6.45，8.82"
print re.findall(r"\d+\.?\d*",string)

# ['1.45', '5', '6.45', '8.82']  门已打开 门已关闭 警告已关闭
门已打开
'''

'''


if __name__ == '__main__':
    ip_broadcast_thread = threading.Thread(target=ip_broadcast.broadcast_ip)
    ip_broadcast_thread.start()
    tcp_thread = threading.Thread(target=startTcp)
    tcp_thread.start()
    # listen_stm32_thread = threading.Thread(target=listen_stm32)
    # listen_stm32_thread.start()
    
    voice_thread = threading.Thread(target=begin_voice)
    voice_thread.start()
'''



if __name__ == '__main__':
    ip_broadcast_thread = threading.Thread(target=ip_broadcast.broadcast_ip)
    ip_broadcast_thread.start()
    tcp_thread = threading.Thread(target=startTcp)
    tcp_thread.start()
    listen_stm32_thread = threading.Thread(target=listen_stm32)
    listen_stm32_thread.start()
    
    voice_thread = threading.Thread(target=begin_voice)
    voice_thread.start()




