#include "stm32f10x.h"
#include "delay.h"
#include "Sensor_human.h"
#include "usart1.h"
#include "dht11.h"
#include "pbdata.h"
#include "door.h"
#include "tim.h"

int main(void)
{
	u8 i;
  uint8_t j; //�������
  SysTick_Init();//��ʱ��ʼ��
	Sensor_Init();
	uart1_init(115200);
	DHT11_Init();
	DOOR();
	
	GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOE,&GPIO_InitStructure);
	
//	GPIO_SetBits(GPIOE,GPIO_Pin_3);
//	GPIO_ResetBits(GPIOB,GPIO_Pin_7);
	
  while (1)
  {
		i='1';
		GPIO_ResetBits(GPIOB,GPIO_Pin_7);
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7))
		{
			RS232_1_Send_Data(&i,1);
			Delay_ms(1000);
		}
		if(GPIO_ReadOutputDataBit(GPIOE,GPIO_Pin_3))
		{
			send();
			GPIO_ResetBits(GPIOE,GPIO_Pin_3);
		}
		j=Sensor_Iden();
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) == 0)
		{
			GPIO_ResetBits(GPIOA,GPIO_Pin_2);
		}
		else{
			if(j){
				GPIO_SetBits(GPIOA,GPIO_Pin_2);
			}
			else{
				GPIO_ResetBits(GPIOA,GPIO_Pin_2);
			}
		}
		if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_4) == 1)
		{
		  TIM_Init();
	    TIM_PWM_Init();
			uint8_t cnt;
	    for(cnt=0;cnt<100;cnt+=5)//ÿ��70MS�ı�һ��ռ�ձ�
	    {
				BufferPwmCtrl(cnt);
		    Delay_ms(70);
	    }
	    for(cnt=100;cnt>0;cnt-=5)//ÿ��70MS�ı�һ��ռ�ձ�
	    {
		    BufferPwmCtrl(cnt);
		    Delay_ms(70);
		  }
    }
		else{
			TIM_SetCompare3(TIM3,0);
		}
	}
}

/*----------------------�·��� ������̳��www.doflye.net--------------------------*/
