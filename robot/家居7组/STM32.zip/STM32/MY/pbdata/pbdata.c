#include "pbdata.h" 
#include "delay.h"
#include "dht11.h"
u8 dt = 0;
u8 wd = 0;      
u8 sd = 0;
u8 buf[7];
void SendOut(u8 *buf,u8 len)
{
	u8 t;
  for(t=0;t<len;t++)		//ѭ����������
	{		   
		while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);	//�������  
		USART_SendData(USART1,buf[t]);
	}	
	while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);		  
}

void send(){

	  DHT11_Read_Data(&wd,&sd);//��ȡ��ʪ��ֵ
	u8 a,b;
	if(wd/16<=9)
	{
		if(wd%16<=9)
		{
			a=wd/16*16+wd%16;
		}
		else{
			a=wd/16*16+9+wd%16-9;
		}
	}
	else{
		if(wd%16<=9)
		{
			a=9*16+(wd/16-9)*16+wd%16;
		}
		else{
			a=9*16+(wd/16-9)*16+9+wd%16-9;
		}
	}
	if(sd/16<=9)
	{
		if(sd%16<=9)
		{
			b=sd/16*16+sd%16;
		}
		else{
			b=sd/16*16+9+sd%16-9;
		}
	}
	else{
		if(sd%16<=9)
		{
			b=9*16+(sd/16-9)*16+sd%16;
		}
		else{
			b=9*16+(sd/16-9)*16+9+sd%16-9;
		}
	}
	  buf[0] = '2';
		buf[0] = a/10+48;
		buf[1] = a%10+48;
	  buf[2] = 'C';
	  buf[3] = ' ';
	  buf[4] = b/10+48;
	  buf[5] = b%10+48;
	  buf[6] = '%';
		SendOut(buf,7);
		//Delay_ms(1000);

}
