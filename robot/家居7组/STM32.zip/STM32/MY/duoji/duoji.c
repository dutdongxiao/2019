#include "stm32f10x.h"
#include "delay.h"

void DOOR(){
	SysTick_Init();
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure3;
  GPIO_InitStructure3.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure3.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure3.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure3);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure3;
	TIM_OCInitTypeDef TIM_OCInitStructure3;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	TIM_TimeBaseStructure3.TIM_Period=1999;
	TIM_TimeBaseStructure3.TIM_Prescaler=719;
	TIM_TimeBaseStructure3.TIM_ClockDivision=0;
	TIM_TimeBaseStructure3.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseStructure3);
	
	TIM_OCInitStructure3.TIM_OCMode=TIM_OCMode_PWM2;
	TIM_OCInitStructure3.TIM_Pulse=0;
	TIM_OCInitStructure3.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OCInitStructure3.TIM_OCPolarity=TIM_OCPolarity_Low;
	TIM_OC4Init(TIM2,&TIM_OCInitStructure3);
	TIM_Cmd(TIM2,ENABLE);
	//while(1){
		//TIM_SetCompare4(TIM2,60);
		//Delay_ms(3000);
		//TIM_SetCompare4(TIM2,150);
		//Delay_ms(3000);
	//}
}