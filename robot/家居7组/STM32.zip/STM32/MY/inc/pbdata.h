#ifndef __PBDATA_H
#define __PBDATA_H

#include "stm32f10x.h"

#include "misc.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_usart.h"
#include "stdio.h"
#include "DHT11.h"

extern u8 dt;
void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);
void USART_Configuration(void);
void RCC_HSE_Configuration(void);
void SendOut(u8 *buf,u8 len);
void INIT(void);
void send(void);
#endif 

