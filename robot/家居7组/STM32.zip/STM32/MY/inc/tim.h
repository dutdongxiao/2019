#ifndef __TIM_H
#define __TIM_H

#include "stm32f10x.h"	 

void TIM_Init(void);
void BufferPwmCtrl(uint8_t PWM);
void TIM_PWM_Init(void);

#endif
