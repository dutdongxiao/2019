#ifndef _SENSOR_HUMAN_H

#define _SENSOR_HUMAN_H

#include "stm32f10x.h"

void Sensor_Init(void);
uint8_t Sensor_Iden(void);

#endif
