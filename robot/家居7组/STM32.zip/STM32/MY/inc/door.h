#ifndef __DOOR_H
#define __DOOR_H

#include "stm32f10x.h"

void DOOR(void);

#endif
