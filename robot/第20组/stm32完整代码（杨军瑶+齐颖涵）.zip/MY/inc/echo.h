#include "stm32f10x.h"
 
void iniTim(void); 
double get_length(void); 
void TIM2_IRQHandler(void); 
