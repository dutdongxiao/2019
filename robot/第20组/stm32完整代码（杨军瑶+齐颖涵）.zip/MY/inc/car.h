#include "stm32f10x.h"


void car_init(int i); 
void turnx(int);
void gogogo(int direction);
void turn(int direction);
void changeSpeed(int i); 

