#ifndef __B_H
#define __B_H
#include "stm32f10x.h"

void bluetooth_init(void); 

#endif /* __MISC_H */
