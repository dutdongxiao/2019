#include "stm32f10x.h"
#include "car.h"
#include "delay.h"
#include "bluetooth.h"
#include "echo.h"
#include "duoji.h"

int flag=0;
int flag_shun=0;
int flag_ni=0;
int order ;	
extern int toofar;
extern double length;


int main(void)
{
	bluetooth_init();
	uart2_init(1000000);	
  SysTick_Init();//��ʱ��ʼ��
	iniTim();
	while(1)
	{
		while(flag==1)
		{
			Delay_ms(70);
			while(1)
						{
							Delay_ms(70);
							if (get_length()<0.3) //������빻��len< 0.3
							{
								turnx(1);	
								Delay_ms(1500);
								gogogo(1);
								//GPIO_SetBits(GPIOB,GPIO_Pin_7);//�����������led
							}
							//else
								//GPIO_ResetBits(GPIOB,GPIO_Pin_7);
								if (flag_shun==1)
								{	
									shunshizhen();
									flag_shun=0;
								}
								if (flag_ni==1)
			          {
									nishizhen();
									flag_ni=0;
								}
				
						}
		}
	
	}
}

//ÿ��timer֮�� 
void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	}
}

void USART1_IRQHandler(void)
{
	
	if(USART_GetITStatus(USART1,USART_IT_RXNE)!=RESET)
	{
		u8 order = 0;
		order =USART_ReceiveData(USART1);
		USART_ClearITPendingBit(USART1,USART_IT_RXNE);
		USART_ClearFlag(USART1,USART_IT_RXNE);
			switch(order)
			{
				case 1:case'1'://ǰ��
					gogogo(1);
					break;
				case 2:case '2'://���� 
					gogogo(-1);
					break;
				case 3:case'3'://���� 
					changeSpeed(-1);
					break;
				case 4:case '4'://���� 
					changeSpeed(1);
					break;
				case 5:case '5'://��ת
					turnx(1);
					break;
				case 6:case'6'://��ת
					turnx(2);
					break;
				case 7:case'7'://ͣ��
					gogogo(0);
					break;
				case 9:case'9'://���˳ʱ��Ѳ��
					flag_shun=1;
					break;
				case 0:case'0'://�����ʱ��Ѳ��
					flag_ni=1;
					break;
			}
		flag=1;
	}

}
