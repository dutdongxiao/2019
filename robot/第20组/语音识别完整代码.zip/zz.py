﻿#!/usr/bin/env python
# -*- encoding: utf-8


import cv2
##import os
import numpy as np
##import time
import json
import base64
import urllib, urllib2, sys
import ssl
reload(sys)

sys.setdefaultencoding('utf8')
##import types
from socket import *
##import serial
##import time
import pyaudio
import wave
from aip import AipSpeech
import os
import sys
import types
import time
import serial
import string
import RPi.GPIO as GPIO                     
    


# encoding:utf-8

#print('ddd')
targetPath = os.getcwd() + os.path.sep + 'getdata'
print (targetPath)
if not os.path.exists(targetPath):
    os.makedirs(targetPath)
    print('makdir getdata')
else:
    print('the path exit')
    
targetPath = os.getcwd() + os.path.sep + 'image'
print (targetPath)
if not os.path.exists(targetPath):
    os.makedirs(targetPath)
    print('makdir image')
else:
    print('the path exit')
    
    
t_start = time.time()
fps = 0




def transimage(imagePath):
    f = open(imagePath,'rb')
    img = base64.b64encode(f.read())
    return img
    
    
def dict_get(dict, objkey, default):
    tmp = dict
    for k,v in tmp.items():
        if k == objkey:
            return v
        else:
            if type(v) is types.DictType:
                ret = dict_get(v, objkey, default)
                if ret is not default:
                    return ret
    return default






cam = cv2.VideoCapture(0)
cam.set(3, 320) # set video width
cam.set(4, 240) # set video height
 
face_detector = cv2.CascadeClassifier('./lbpcascade_frontalface.xml')
 
# For each person, enter one numeric face id
#face_id = input('enter user id (int): ')
face_id = 1
print("Initializing face capture. Look the camera and wait ...")
# Initialize individual sampling face count
count = 0
owner = 0


user1ImageEncode = transimage('./image/Deng.jpg')
user2ImageEncode = transimage('./image/Yue.jpg')



while(True):
 
    ret, img = cam.read()
    #img = cv2.flip(img, -1) # flip video image vertically
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(
        gray
        #scaleFactor=1.2,
        #minNeighbors=5,
        #minSize=(20, 20)
    )
    
    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0), 2)
        count += 1
        # Save the captured image into the datasets folder
        cv2.imwrite("./getdata/User." + str(face_id) + '.' + str(count) + ".jpg", gray[y:y+h,x:x+w])
        print("User."+ str(face_id)+'.'+str(count)+'/15.jpg')
        nowImagePath = "./getdata/User." + str(face_id) + '.' + str(count) + ".jpg"
        
        nowImageEncode = transimage(nowImagePath)
        
        request_url = "https://aip.baidubce.com/rest/2.0/face/v3/match"

        ####user1
        params = json.dumps(
            [{"image": nowImageEncode, "image_type": "BASE64", "face_type": "LIVE", "quality_control": "LOW"},
            {"image": user1ImageEncode, "image_type": "BASE64", "face_type": "IDCARD", "quality_control": "LOW"}])

        access_token = '24.0c3d44ff917beeaa71e88477b5a3d70c.2592000.1564299638.282335-16667678'
        
        #print(access_token)
        request_url = request_url + "?access_token=" + access_token
        request = urllib2.Request(url=request_url, data=params)
        request.add_header('Content-Type', 'application/json')
        response = urllib2.urlopen(request)
        content = response.read()
        if content:
            #print(type(content))
            contentToDictionary = json.loads(content) ##string To dictionary
            #print(type(contentToDictionary))
            score = dict_get(contentToDictionary, 'score', 0)
            #print contentToDictionary
            error_code = contentToDictionary.get('error_code')
            stringScore = 'score: ' + str(score)
            stringErr = 'error_code: ' + str(error_code)
            print(stringErr)
            print(stringScore)
            if (error_code == 0) & (score >= 90):
                owner = 1
                print ('Hello,Dengyaxin')
            #print(contentToDictionary.get('result'.'score'))
            #print(contentToDictionary['result'])
            #getsult = contentToDictionary.get('result')
            #stringsult = str(getsult)
            #dictiosult = json.loads(stringsult)
            #print(dictiosult.get('score'))
            #print(contentToDictionary['result'].get('score'))
            #print(contentToDictionary['result']['score'])
            #print(contentToDictionary['result'][0]['score'])
            #print(contentToDictionary.get('log_id'))
            #print(contentToDictionary[log_id])
            #print content
            #print contentToDictionary
        #####> 90 break         owner = 1
        
        ####user2
        params2 = json.dumps(
            [{"image": nowImageEncode, "image_type": "BASE64", "face_type": "LIVE", "quality_control": "LOW"},
            {"image": user2ImageEncode, "image_type": "BASE64", "face_type": "IDCARD", "quality_control": "LOW"}])
        request2 = urllib2.Request(url=request_url, data=params2)
        request2.add_header('Content-Type', 'application/json')
        response2 = urllib2.urlopen(request2)
        content2 = response2.read()
        if content2:
            content2ToDictionary = json.loads(content2) ##string To dictionary
            #print(content2ToDictionary)
            score2 = dict_get(content2ToDictionary, 'score', 0)
            error_code2 = content2ToDictionary.get('error_code')
            stringScore2 = 'core2: ' + str(score2)
            stringErr2 = 'error_code: ' + str(error_code2)
            print(stringErr2)
            print(stringScore2)
            if (error_code2 == 0) & (score2 >= 90):
                owner = 1
                print ('Hello,Yuebeiping!')
            #print content2
        #####> 90 break         owner = 1
        # Calculate and show the FPS
    fps = fps + 1
    sfps = fps / ( time.time() - t_start )
    cv2.putText( img, "FPS : " + str( int( sfps ) ), ( 10, 10 ), cv2.FONT_HERSHEY_SIMPLEX, 0.5, ( 0, 0, 255 ), 2 )   
    
    
    cv2.imshow('image', img)
        
    k = cv2.waitKey(100) & 0xff # Press 'ESC' for exiting video
    if k == 27:
        break
    elif count >= 15: # Take 30 face sample and stop video
         break
    elif owner == 1:
         break
 
# Do a bit of cleanup
print("\n [INFO] Exiting Program and cleanup stuff")
cam.release()
cv2.destroyAllWindows()

'''
{"error_code":0,
"error_msg":"SUCCESS",
"log_id":304569217137406151,
"timestamp":1561713740,
"cached":0,
"result":{"score":96.41821289,"face_list":[{"face_token":"abfbd7b02fb2c0f3a78c15f0ad1c3580"},{"face_token":"f84985a53020266d2d6911a2a5340b08"}]}}
{u'log_id': 304569217137406151L,
 u'timestamp': 1561713740,
 u'cached': 0,
 u'result': 
 {u'score': 96.41821289,
 u'face_list': [{u'face_token': u'abfbd7b02fb2c0f3a78c15f0ad1c3580'}, {u'face_token': u'f84985a53020266d2d6911a2a5340b08'}]},
 u'error_code': 0, u'error_msg': u'SUCCESS'}
None

'''

'''

/home/pi/face/getdata
the path exit
/home/pi/face/image
the path exit
Initializing face capture. Look the camera and wait ...
User.1.1/15.jpg
{u'log_id': 304592817207800961L, u'timestamp': 1561720780, u'cached': 0, u'result': None, u'error_code': 222202, u'error_msg': u'pic not has face'}
no score2
Welcome come back,han
{u'log_id': 304592817207803091L, u'timestamp': 1561720780, u'cached': 0, u'result': None, u'error_code': 222202, u'error_msg': u'pic not has face'}
no score2
Welcome come back,yue!

'''
HOST = '192.168.1.175'
POST = 8081
BUFSIZ = 1024
ADDR = (HOST, POST)

tcpCliSock = socket(AF_INET, SOCK_STREAM)
tcpCliSock.connect(ADDR)
ser = serial.Serial("/dev/ttyAMA0", 9600)
ser.write(b"Raspberry pi is ready")
while True:
    data = tcpCliSock.recv(BUFSIZ)
    if not data:
        break
    ##print("[%s]: %s" % (ctime(), data.decode()))
    print("%s" % (data.decode()))
    if data!='L':
        msg = 0
        msg = data
        ser.write(msg)
        ser.flushInput()
        time.sleep(0.1)
    if data=='L':
        print(123)
        ser = serial.Serial("/dev/ttyAMA0", 9600)

        CHUNK = 1024
        FORMAT = pyaudio.paInt16
        CHANNELS =1
        RATE = 16000
        RECORD_SECONDS =3
        WAVE_OUTPUT_FILENAME = "out.wav"


        def rec(file_name):
            p = pyaudio.PyAudio()

            stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK)
            print("1")
            pin=13
            GPIO.setmode(GPIO.BOARD)                    
            GPIO.setup(13, GPIO.OUT)                                     
            GPIO.output(pin,True)      

            frames = []

            for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
                data = stream.read(CHUNK)
                frames.append(data)

            stream.stop_stream()
            stream.close()
            p.terminate()

            wf = wave.open(file_name, 'wb')
            wf.setnchannels(CHANNELS)
            wf.setsampwidth(p.get_sample_size(FORMAT))
            wf.setframerate(RATE)
            wf.writeframes(b''.join(frames))
            wf.close()
            print("2")            
            pin=13
            GPIO.setmode(GPIO.BOARD)                    
            GPIO.setup(13, GPIO.OUT)                                     
            GPIO.output(pin,False)



        APP_ID = '16639647'
        API_KEY = '1KMaF4Gf8zXzxOpb9PxmGa8B'
        SECRET_KEY = 'o6ZkzSSrwKMcNS5XXem5QLj8gCxiqrWN'
        client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)

        def get_file_content(filePath):
            with open(filePath, 'rb') as fp:
                return fp.read()

        print("listening")

        while True:
                rec(WAVE_OUTPUT_FILENAME) 
                result=client.asr(get_file_content(WAVE_OUTPUT_FILENAME),'wav', 16000, {
                'dev_pid': 1536,})    
                if result["err_no"]==0:
                    tmp=result["result"][0]
        
        #print(type(tmp))
        #tmp.encode("utf-8")
        #print(tmp)
        #tmp=tmp.encode('unicode-escape').decode('string_escape')
        #tmp=tmp.encode('utf-8').decode('unicode_escape')
        #str=tmp.encode('gbk')
        #print(type(tmp))
                    if tmp.find("你好")!=-1:
                        print("程序开始")
                        ser.write(b"Raspberry pi is ready")
                        print("connected")

                        result  = client.synthesis('你好啊', 'zh', 1, {
                        'vol': 5,
                        })
 
             # 识别正确返回语音二进制 错误则返回dict 参照下面错误码
                        if not isinstance(result, dict):
                            with open('audio.mp3', 'wb') as f:
                                f.write(result)

                        music_path = 'audio.mp3'
                        os.system('mplayer %s' % music_path)
                        time.sleep(3)

                        while(True):
                            rec(WAVE_OUTPUT_FILENAME)
                            result=client.asr(get_file_content(WAVE_OUTPUT_FILENAME),'wav', 16000, {
                                    'dev_pid': 1536,})
                            if result["err_no"]==0:
                                tmp=result["result"][0]
                    
                                if tmp.find("停止")!=-1:
                                    sign=7
                                    print(tmp)
                                    ser = serial.Serial("/dev/ttyAMA0", 9600)

                                    ser.write(b'7')
                                    ser.flushInput()
                                    break

                                else:
                                    print(tmp)
                                    if tmp.find("前进")!=-1 or tmp.find("陈静")!=-1:
                                        result = client.synthesis('我正在前进', 'zh', 1, {
                                            'vol': 5,
                                        })
                            # 识别正确返回语音二进制 错误则返回dict 参照下面错误码
                                        if not isinstance(result, dict):
                                            with open('audio.mp3', 'wb') as f:
                                                f.write(result)
                                        sign=1
                                        print(sign)
                                        ser = serial.Serial("/dev/ttyAMA0", 9600)
                                        ser.write(b"Raspberry pi is ready")
                                        print("connected")
                                        ser.write(b'1')
                                        ser.flushInput()
                            
                            
                            
                                        music_path = 'audio.mp3'
                                        os.system('mplayer %s' % music_path)
                                        time.sleep(3)
                            

                                    elif    tmp.find("后退")!=-1:
                                        result = client.synthesis('我正在后退', 'zh', 1, {
                                            'vol': 5,
                                            })
                            # 识别正确返回语音二进制 错误则返回dict 参照下面错误码
                                        if not isinstance(result, dict):
                                            with open('audio.mp3', 'wb') as f:
                                                f.write(result)
                                        sign=2
                                        print(sign)
                                        ser = serial.Serial("/dev/ttyAMA0", 9600)

                                        ser.write(b'2')
                                        ser.flushInput()
                            
                            
                                        music_path = 'audio.mp3'
                                        os.system('mplayer %s' % music_path)
                                        time.sleep(3)
                            

                                    elif    tmp.find("左转")!=-1:
                                        result = client.synthesis('我正在左转', 'zh', 1, {
                                            'vol': 5,
                                        })
                            # 识别正确返回语音二进制 错误则返回dict 参照下面错误码
                                        if not isinstance(result, dict):
                                            with open('audio.mp3', 'wb') as f:
                                                f.write(result)
                                        sign=3
                                        print(sign)
                                        ser = serial.Serial("/dev/ttyAMA0", 9600)

                                        ser.write(b'5')
                                        ser.flushInput()
                            
                            
                                        music_path = 'audio.mp3'
                                        os.system('mplayer %s' % music_path)
                                        time.sleep(3)
                            

                                    elif    tmp.find("右转")!=-1:
                                        result = client.synthesis('我正在右转', 'zh', 1, {
                                            'vol': 5,
                                        })
                            # 识别正确返回语音二进制 错误则返回dict 参照下面错误码
                                        if not isinstance(result, dict):
                                            with open('audio.mp3', 'wb') as f:
                                                f.write(result)
                                        sign=4
                                        print(sign)
                                        ser = serial.Serial("/dev/ttyAMA0", 9600)

                                        ser.write(b'6')
                                        ser.flushInput()
                            
                            
                                        music_path = 'audio.mp3'
                                        os.system('mplayer %s' % music_path)
                                        time.sleep(3)
                            

                                    elif    tmp.find("加速")!=-1:
                                        result = client.synthesis('我正在加速', 'zh', 1, {
                                            'vol': 5,
                                        })
                            # 识别正确返回语音二进制 错误则返回dict 参照下面错误码
                                        if not isinstance(result, dict):
                                            with open('audio.mp3', 'wb') as f:
                                                f.write(result)
                                        sign=5
                                        print(sign)
                                        ser = serial.Serial("/dev/ttyAMA0", 9600)

                                        ser.write(b'3')
                                        ser.flushInput()
                            
                            
                                        music_path = 'audio.mp3'
                                        os.system('mplayer %s' % music_path)
                                        time.sleep(3)
                        
                                    elif    tmp.find("减速")!=-1 or tmp.find("简述")!=-1:
                                        result = client.synthesis('我正在减速', 'zh', 1, {
                                            'vol': 5,
                                            })
                            # 识别正确返回语音二进制 错误则返回dict 参照下面错误码
                                        if not isinstance(result, dict):
                                            with open('audio.mp3', 'wb') as f:
                                                f.write(result)
                                        sign=6
                                        print(sign)
                                        ser = serial.Serial("/dev/ttyAMA0", 9600)

                                        ser.write(b'4')
                                        ser.flushInput()
                            


                                        music_path = 'audio.mp3'
                                        os.system('mplayerz %s' % music_path)
                                        time.sleep(3)

                    elif tmp.find("结束")!=-1:
                        break
