import numpy as np
import cv2
import time
import os 
 
 
targetPath = os.getcwd() + os.path.sep + 'image'
print (targetPath)
if not os.path.exists(targetPath):
    os.makedirs(targetPath)
    print('makdir image')
else:
    print('the path exit')
t_start = time.time()
fps = 0
count = 1
fcounter = 0    
facefind = 0    
print('int:(1-6) ')
a = input()
if a == 1:
    faceCascade = cv2.CascadeClassifier('./lbpcascade_frontalface_improved.xml')
    print('11')
else: 
    if a == 2:
        faceCascade = cv2.CascadeClassifier('./lbpcascade_frontalface_improved.xml')
        print('22')
    else:
        if a == 3:
            faceCascade = cv2.CascadeClassifier('./lbpcascade_frontalface_improved.xml')
            print('33')
        else:
            if a == 4:
                faceCascade = cv2.CascadeClassifier('./lbpcascade_frontalface_improved.xml')
                print('44')
            else:
                if a == 5:
                    faceCascade = cv2.CascadeClassifier('./lbpcascade_frontalface.xml')
                    print('55')
                else:
                    if a == 6:
                        faceCascade = cv2.CascadeClassifier('./lbpcascade_frontalface.xml')
                        print('66')
                        
cap = cv2.VideoCapture(0)
cap.set(3,320) # set Width
cap.set(4,240) # set Height
 
 
 
while True:
    ret, image = cap.read()
    #image = cv2.flip(image, -1)
    
    if fcounter == 3:
    
        fcounter =0
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        faces = faceCascade.detectMultiScale(
            gray,     
            scaleFactor=1.2,
            minNeighbors=5,     
            minSize=(20, 20)
        )
    
        if str( len( faces ) ) != '0':
            facefind = 1
            facess = faces
            print("Found " + str( len( faces ) ) + " face(s)")
        else: 
            facefind = 0
        
        for (x,y,w,h) in faces:
            cv2.rectangle(image,(x,y),(x+w,y+h),(255,0,0),2)
            roi_gray = gray[y:y+h, x:x+w]
            roi_color = image[y:y+h, x:x+w]
            facess = faces
            cv2.imwrite("%s/%d.jpg" % (targetPath,count),cv2.resize(image, (224, 224),interpolation=cv2.INTER_AREA))
            print(u"%s: %d image(s)" % (targetPath,count))
            count+=1
    else:
        if facefind ==1 and str( len( facess ) ) != '0':
            print("Found " + str( len( faces ) ) + " face(s)")
            for (x,y,w,h) in facess:
                cv2.rectangle(image,(x,y),(x+w,y+h),(255,0,0),2)
                roi_gray = gray[y:y+h, x:x+w]
                roi_color = image[y:y+h, x:x+w]
    
    fcounter += 1
    
    
    # Calculate and show the FPS
    fps = fps + 1
    sfps = fps / ( time.time() - t_start )
    cv2.putText( image, "FPS : " + str( int( sfps ) ), ( 10, 10 ), cv2.FONT_HERSHEY_SIMPLEX, 0.5, ( 0, 0, 255 ), 2 )   
    
    
    cv2.imshow('video',image)
 
    k = cv2.waitKey(30) & 0xff
    if k == 27: # press 'ESC' to quit
        break
 
cap.release()
cv2.destroyAllWindows()
