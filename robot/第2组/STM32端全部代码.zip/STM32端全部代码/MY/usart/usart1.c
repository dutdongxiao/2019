#include "usart1.h"
#include "delay-B.h"
#include "string.h"
#include "stdio.h"
#include "UltrasonicWave.h"
#include "timer.h"
extern float Hcsr04GetLength(void );
u8 uDirect=0xFF;
int flag=0;
int Changespeed1=200;
int Changespeed2=200;
int Changespeed3=200;
int Changespeed4=200;
void uart1_init(u32 bound)
{  	 
	  //GPIO�˿�����
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	//ʹ��UGPIOBʱ��
  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);	//ʹ��USART1ʱ��

	//UART3_TX  
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; //PA9
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	//�����������
	GPIO_Init(GPIOA, &GPIO_InitStructure);
  	//UART3_RX	  
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;//PA10
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//��������
  	GPIO_Init(GPIOA, &GPIO_InitStructure);

  	//Usart1 NVIC ����
  	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0 ;//��ռ���ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		//�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���
    
	//USART ��ʼ������
	USART_InitStructure.USART_BaudRate = bound;//���ڲ�����
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//�ֳ�Ϊ8λ���ݸ�ʽ
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//һ��ֹͣλ
	USART_InitStructure.USART_Parity = USART_Parity_No;//����żУ��λ
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//��Ӳ������������
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//�շ�ģʽ
  	USART_Init(USART1, &USART_InitStructure);     //��ʼ������3
  	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);//�������ڽ����ж�
  	USART_Cmd(USART1, ENABLE);                    //ʹ�ܴ���3 
}

int fputc(int c, FILE *stream)
{
    USART1->DR = c;//?c????1?DR???,???????,?????????
    while(!(USART1->SR & (1 << 7))){};//????????
    return c;
}

/**************************************************************************
�������ܣ�����3�����ж�
��ڲ�������
����  ֵ����
**************************************************************************/
u8 USART1_RX_BUF[USART1_REC_LEN];     //���ջ���,���USART_REC_LEN���ֽ�.
u16 USART1_RX_STA=0;       //����״̬���	  
time_t timecount;      
void USART1_IRQHandler(void)
{	
	u8 Res;
	char mes[40]="���յ���������";
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)  //�����ж�(�Զ�����m6ͨ�� ���յ������ݱ�����0x0d 0x0a��β���س�����)
	{
		Res =USART_ReceiveData(USART1);	//��ȡ���յ�������
		if((USART1_RX_STA&0x8000)==0)//����δ���
		{
			if(Res==0x24)
			{ 
				USART1_RX_STA|=0x8000;	//��������� 
				USART1_RX_BUF[USART1_RX_STA&0X3FFF]='\0' ;
			}
			else //��û�յ�0X0D
			{	
				USART1_RX_BUF[USART1_RX_STA&0X3FFF]=Res ;
				USART1_RX_STA++;
				if(USART1_RX_STA>(USART1_REC_LEN-1))
				USART1_RX_STA=0;//�������ݴ���,���¿�ʼ����	  		 
			}
		}
		if((USART1_RX_STA&0x8000)!=0)//�������
		{
			//�������յ�
			RS232_1_Send_Data((u8*)mes,14);
			RS232_1_Send_Data(USART1_RX_BUF,USART1_RX_STA&0x00FF);
			RS232_1_Send_Data((u8*)"\n",1);
			if(strcmp((char*)USART1_RX_BUF,"#DUO10#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 195);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO19#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 194);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO118#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 193);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO127#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 192);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO136#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 191);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO145#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 190);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO154#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 189);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO163#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 188);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO172#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 187);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO181#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 186);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO190#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 185);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO199#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 184);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO1108#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 183);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO1117#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 182);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO1126#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 181);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO1135#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 180);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO1144#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 179);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO1153#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 178);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO1162#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 177);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO1171#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 176);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO1180#")==0){
				delay_ms(500);
				TIM_SetCompare1(TIM2, 175);
			}
			
			
			
			if(strcmp((char*)USART1_RX_BUF,"#DUO20#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 195);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO29#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 194);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO218#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 193);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO227#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 192);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO236#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 191);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO245#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 190);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO254#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 189);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO263#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 188);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO272#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 187);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO281#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 186);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO290#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 185);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO299#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 184);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO2108#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 183);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO2117#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 182);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO2126#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 181);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO2135#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 180);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO2144#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 179);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO2153#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 178);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO2162#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 177);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO2171#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 176);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO2180#")==0){
				delay_ms(500);
				TIM_SetCompare2(TIM2, 175);
			}
			
			
			if(strcmp((char*)USART1_RX_BUF,"#DUO30#")==0){
				delay_ms(500);
				TIM_SetCompare3(TIM2, 195);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO318#")==0){
				delay_ms(500);
				TIM_SetCompare3(TIM2, 193);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO345#")==0){
				delay_ms(500);
				TIM_SetCompare3(TIM2, 190);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO363#")==0){
				delay_ms(500);
				TIM_SetCompare3(TIM2, 188);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO390#")==0){
				delay_ms(500);
				TIM_SetCompare3(TIM2, 185);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO3135#")==0){
				delay_ms(500);
				TIM_SetCompare3(TIM2, 180);
			}
			if(strcmp((char*)USART1_RX_BUF,"#DUO3180#")==0){
				delay_ms(500);
				TIM_SetCompare3(TIM2, 177);
			}
			
			
			
			if(strcmp((char*)USART1_RX_BUF,"#FORWARD#")==0){
				Changespeed1=200;
				Changespeed2=200;
				Changespeed3=200;
				Changespeed4=200;
				delay_ms(500);
				uDirect=0xEF;
			}
			if(strcmp((char*)USART1_RX_BUF,"#BACK#")==0){
				delay_ms(500);
				Changespeed1=200;
				Changespeed2=200;
				Changespeed3=200;
				Changespeed4=200;
				uDirect=0xBF;
			}
			if(strcmp((char*)USART1_RX_BUF,"#ZUOXUAN#")==0){
				delay_ms(500);
				uDirect=0x7F;
			}
			if(strcmp((char*)USART1_RX_BUF,"#YOUXUAN#")==0){
				delay_ms(500);
				uDirect=0xDF;
			}
			if(strcmp((char*)USART1_RX_BUF,"#STOP#")==0){
				delay_ms(500);
				uDirect=0xFF;
			}
			if(strcmp((char*)USART1_RX_BUF,"#FASTER#")==0){
				delay_ms(500);
				Changespeed1=100;
				Changespeed2=100;
				Changespeed3=100;
				Changespeed4=100;
			}
			if(strcmp((char*)USART1_RX_BUF,"#OLDSPEED#")==0){
				delay_ms(500);
				Changespeed1=200;
				Changespeed2=200;
				Changespeed3=200;
				Changespeed4=200;
			}
			if(strcmp((char*)USART1_RX_BUF,"#SLOWER#")==0){
				delay_ms(500);
				Changespeed1=250;
				Changespeed2=250;
				Changespeed3=250;
				Changespeed4=250;
			}
			if(strcmp((char*)USART1_RX_BUF,"#LEFT#")==0){
				delay_ms(500);
				Changespeed1=120;
				Changespeed2=200;
				Changespeed3=200;
				Changespeed4=120;
			}
			if(strcmp((char*)USART1_RX_BUF,"#RIGHT#")==0){
				delay_ms(500);
				Changespeed1=200;
				Changespeed2=120;
				Changespeed3=120;
				Changespeed4=200;
			}
			if(strcmp((char*)USART1_RX_BUF,"#DISTANCE#")==0){
				flag=1;
			}
			if(strcmp((char*)USART1_RX_BUF,"#STOPXUNDAO#")==0){
				flag=0;
			}
			if(strcmp((char*)USART1_RX_BUF,"#XUNJI#")==0){
				flag=2;
			}
			USART1_RX_STA=0;//����������ɣ���ʼ��������
		}
	}
}
/**********************************************************
*	���ܣ���������
*	������buf ���ͻ������׵�ַ
*		  len �����͵��ֽ���
**********************************************************/
void RS232_1_Send_Data(u8 *buf,u8 len)
{
	u8 t;
  	for(t=0;t<len;t++)		//ѭ����������
	{		   
		while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);	//�������  
		USART_SendData(USART1,buf[t]);
	}	 
 
	while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);		
//	RS232_RX_CNT=0;	  
}
