#include "stm32f10x.h"
#include "stdio.h"

#define SEARCH_M_PIN         GPIO_Pin_6
#define SEARCH_M_GPIO        GPIOC
#define SEARCH_M_IO          GPIO_ReadInputDataBit(SEARCH_M_GPIO, SEARCH_M_PIN)

#define SEARCH_R_PIN         GPIO_Pin_8
#define SEARCH_R_GPIO        GPIOC
#define SEARCH_R_IO          GPIO_ReadInputDataBit(SEARCH_R_GPIO, SEARCH_R_PIN)

#define SEARCH_L_PIN         GPIO_Pin_8
#define SEARCH_L_GPIO        GPIOA
#define SEARCH_L_IO          GPIO_ReadInputDataBit(SEARCH_L_GPIO, SEARCH_L_PIN)
#define BLACK_AREA 1
#define WHITE_AREA 0 
extern u8 uDirect;
extern int Changespeed1;
extern int Changespeed2;
extern int Changespeed3;
extern int Changespeed4;
extern int fputc(int c, FILE *stream);
void RedRayInit(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = SEARCH_M_PIN;//????��1?��GPIO1��??
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//????GPIO?�꨺?,��?��?��?��-
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//????GPIO???��?��?��
	GPIO_Init(SEARCH_M_GPIO , &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin = SEARCH_R_PIN;//????��1?��GPIO1��??
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//????GPIO?�꨺?,��?��?��?��-
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//????GPIO???��?��?��
	GPIO_Init(SEARCH_R_GPIO , &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin = SEARCH_L_PIN;//????��1?��GPIO1��??
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//????GPIO?�꨺?,��?��?��?��-
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//????GPIO???��?��?��
	GPIO_Init(SEARCH_L_GPIO , &GPIO_InitStructure); 
}
void SearchRun(void)
{
	//��y?��???��2a��?
	int i;
	i=SEARCH_M_IO;
	printf("f=%d\n",i);
	i=SEARCH_R_IO;
	printf("r=%d\n",i);
	i=SEARCH_L_IO;
	printf("l=%d\n",i);
	if(SEARCH_M_IO == BLACK_AREA)
	{
				Changespeed1=250;
				Changespeed2=250;
				Changespeed3=250;
				Changespeed4=250;
					uDirect=0xEF;
		printf("forward\n");
	}
	
	else if(SEARCH_R_IO == BLACK_AREA)//����
	{
				Changespeed1=250;
				Changespeed2=250;
				Changespeed3=250;
				Changespeed4=250;
					uDirect=0xDF;
		printf("right\n");
	}
	else if(SEARCH_L_IO == BLACK_AREA)//����
	{
				Changespeed1=250;
				Changespeed2=250;
				Changespeed3=250;
				Changespeed4=250;
					uDirect=0x7F;
		printf("left\n");
	}
	else printf("No Black!\n");
	
}
