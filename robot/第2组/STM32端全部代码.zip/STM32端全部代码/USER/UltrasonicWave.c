/******************** (C) 1209 Lab **************************
 * �ļ���  : UltrasonicWave.c
 * ����    �����������ģ�飬UltrasonicWave_Configuration��������
             ��ʼ������ģ�飬UltrasonicWave_StartMeasure��������
			 ������࣬������õ�����ͨ������1��ӡ����         
 * ʵ��ƽ̨��Mini STM32������  STM32F103RBT6
 * Ӳ�����ӣ�------------------
 *          | PC0  - TRIG      |
 *          | PC1  - ECHO      |
 *           ------------------
 * ��汾  ��ST3.5.0
 *
 * ����    ��Lee 
*********************************************************************************/

#include "delay-B.h"


#define HCSR04_PORT     GPIOC		//TRIG       
#define HCSR04_CLK     RCC_APB2Periph_GPIOC	//ECHO 
#define	HCSR04_TRIG       GPIO_Pin_0   //TRIG       
#define	HCSR04_ECHO       GPIO_Pin_1	//ECHO   
#define TRIG_Send  PCout(0) 
#define ECHO_Reci  PCin(1)         
u16 msHcCount = 0;
/*
 * ��������UltrasonicWave_Configuration
 * ����  ��������ģ��ĳ�ʼ��
 * ����  ����
 * ���  ����	
 */
 void hcsr04_NVIC()
{
            NVIC_InitTypeDef NVIC_InitStructure;
            NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    
            NVIC_InitStructure.NVIC_IRQChannel = TIM6_IRQn;             //????1??
            NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;  //???????????1
            NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;         //???????????1
            NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;        //????
            NVIC_Init(&NVIC_InitStructure);
}


void Hcsr04Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;	
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    
    GPIO_InitStructure.GPIO_Pin =HCSR04_TRIG;       //??????
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//????
    GPIO_Init(HCSR04_PORT, &GPIO_InitStructure);
    GPIO_ResetBits(HCSR04_PORT,HCSR04_TRIG);
     
    GPIO_InitStructure.GPIO_Pin =   HCSR04_ECHO;     //??????
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//????
    GPIO_Init(HCSR04_PORT, &GPIO_InitStructure);  
        GPIO_ResetBits(HCSR04_PORT,HCSR04_ECHO);  
     
            //?????? ???????TIM6
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);   //????RCC??
        //??????????
        TIM_DeInit(TIM6);
        TIM_TimeBaseStructure.TIM_Period = (1000-1); //???????????????????????????         ???1000?1ms
        TIM_TimeBaseStructure.TIM_Prescaler =(72-1); //??????TIMx???????????  1M????? 1US??
        TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;//???
        TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //TIM??????
        TIM_TimeBaseInit(TIM6, &TIM_TimeBaseStructure); //??TIM_TimeBaseInitStruct?????????TIMx???????         
        
        TIM_ClearFlag(TIM6, TIM_FLAG_Update);   //??????,?????????????
        TIM_ITConfig(TIM6,TIM_IT_Update,ENABLE);    //?????????
        hcsr04_NVIC();
    TIM_Cmd(TIM6,DISABLE);     
}
//------------------------ͨ��1�жϺ���---------------------------------------------
void TIM6_IRQHandler(void)   //TIM3??
{
        if (TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET)  //??TIM3????????
        {
                TIM_ClearITPendingBit(TIM6, TIM_IT_Update  );  //??TIMx?????? 
                msHcCount++;
        }
}
void Delay_Ms(uint16_t time)  //????
{ 
    uint16_t i,j;
    for(i=0;i<time;i++)
          for(j=0;j<10260;j++);
}
/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
** ????: Delay_Ms_Us
** ????: ??1us (?????????????)
** ????:time (us) ??time<65535                 
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
void Delay_Us(uint16_t time)  //????
{ 
    uint16_t i,j;
    for(i=0;i<time;i++)
          for(j=0;j<9;j++);
}
//tips:static?????????????????,????????????
 void OpenTimerForHc()        //?????
{
        TIM_SetCounter(TIM6,0);//????
        msHcCount = 0;
        TIM_Cmd(TIM6, ENABLE);  //??TIMx??
}
 
void CloseTimerForHc()        //?????
{
        TIM_Cmd(TIM6, DISABLE);  //??TIMx??
}
u32 GetEchoTimer(void)
{
        u32 t = 0;
        t = msHcCount*1000;//??MS
        t += TIM_GetCounter(TIM6);//??US
          TIM6->CNT = 0;  //?TIM2???????????
                Delay_Ms(50);
        return t;
}
 

//??????????? ??????????????,??????
//?????????,????????????????
float Hcsr04GetLength(void )
{
        u32 t = 0;
        float lengthTemp = 0;
        TRIG_Send = 1;      //????????
        Delay_Us(20);
        TRIG_Send = 0;
        while(ECHO_Reci == 0) {;}    //??????????
            OpenTimerForHc();        //?????
            while(ECHO_Reci == 1);
            CloseTimerForHc();        //?????
            t = GetEchoTimer();        //????,????1US
            lengthTemp = ((float)t/58.0);//cm
        return lengthTemp;
}


/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
** ????: Delay_Ms_Ms
** ????: ??1MS (?????????????)            
** ????:time (ms) ??time<65535
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
/******************* (C) 1209 Lab *****END OF FILE************/
