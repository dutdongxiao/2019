#include "stm32f10x.h"
#include "led.h"
#include "delay.h"
#include "delay-B.h"
#include "key.h"
#include "usart1.h"
#include "motor.h"
#include "UltrasonicWave.h"
#include "timer.h"
#include "stdio.h"

extern int flag;
extern u8 uDirect;
extern int Changespeed1;
extern int Changespeed2;
extern int Changespeed3;
extern int Changespeed4;
extern int fputc(int c, FILE *stream);
extern void Hcsr04Init(void);
extern float Hcsr04GetLength(void );
extern void SearchRun(void);
extern void RedRayInit(void);
void RCC_Config(void)
{
        //ʹ��GPIOA��TIM2
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB , ENABLE);//ʹ��GPIOBʱ��
	      RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC , ENABLE);//ʹ��GPIOCʱ��
	      RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOD , ENABLE);//ʹ��GPIOCʱ��
	      RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOE , ENABLE);//ʹ��GPIOEʱ��
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2|RCC_APB1Periph_TIM6,ENABLE);
}
void GPIO_Config(void)
{
        GPIO_InitTypeDef GPIO_InitStructure;
        GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1|GPIO_Pin_0|GPIO_Pin_2|GPIO_Pin_3;
        GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
        GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
        GPIO_Init(GPIOA,&GPIO_InitStructure);	
}


void TIM_Config()
{
        TIM_TimeBaseInitTypeDef TIM_TImeBaseStructure;
        TIM_OCInitTypeDef  TIM_OCInitStructure;
				
    //����TIM2��ʱ�����Ƶ�ʣ��Լ�������ز�����ʼ��
        TIM_TImeBaseStructure.TIM_Prescaler=7199;//����PWM��Ƶ��
        TIM_TImeBaseStructure.TIM_CounterMode=0;
        TIM_TImeBaseStructure.TIM_Period=199;
        TIM_TimeBaseInit(TIM2,&TIM_TImeBaseStructure);

    //����PWM�������ʽ
        TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
        TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
        TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
   
    //����ռ�ձ�
	      TIM_OCInitStructure.TIM_Pulse=185;
        TIM_OC1Init(TIM2,&TIM_OCInitStructure);
        TIM_OCInitStructure.TIM_Pulse=185;
        TIM_OC2Init(TIM2,&TIM_OCInitStructure);
	      TIM_OCInitStructure.TIM_Pulse=188;
        TIM_OC3Init(TIM2,&TIM_OCInitStructure);
				TIM_OCInitStructure.TIM_Pulse=185;
        TIM_OC4Init(TIM2,&TIM_OCInitStructure);
        TIM_Cmd(TIM2,ENABLE);
        TIM_CtrlPWMOutputs(TIM2,ENABLE);  
}


int main(void)
{
	float length;
 /* uint8_t j; //�������*/
  /*SysTick_Init();//��ʱ��ʼ��  */
	int delay_time;
	RCC_Config();
  GPIO_Config();
	delay_init();
	RedRayInit();
	TIM_Config();
	Hcsr04Init();
	uart1_init(115200);
	motor_init();
	delay_time=500;
  while (1)
  {
		if(flag==1){
				length= Hcsr04GetLength();
				printf("juliwei :%.3f\n",length);
				if(length>20){
				Changespeed1=200;
				Changespeed2=200;
				Changespeed3=200;
				Changespeed4=200;
					uDirect=0xEF;
				}
				else if(length<=20&&length>0){
				Changespeed1=200;
				Changespeed2=200;
				Changespeed3=200;
				Changespeed4=200;
					uDirect=0x7F;
				}
			}
		if(flag==2){
				SearchRun();
		}
				//printf("uDirect:%d\n",uDirect);
		/*delay_ms(delay_time);
		TIM_SetCompare1(TIM2, 175);
		delay_ms(delay_time);
		TIM_SetCompare1(TIM2, 180);
		delay_ms(delay_time);
		TIM_SetCompare1(TIM2, 185);
		delay_ms(delay_time);
		TIM_SetCompare1(TIM2, 190);
		delay_ms(delay_time);
		TIM_SetCompare1(TIM2, 195);*/
  }
}

/*int main()
{
        RCC_Config();
        GPIO_Config();
				while(1){
								if(!GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4)){
									TIM_Config();
								}
        }
}*/
/*int main()
{
        RCC_Config();
        GPIO_Config();
        TIM_Config();
        while(1)
        {
         delay_ms(delay_time);
				 TIM_SetCompare1(ADVANCE_TIM, 175);
				 delay_ms(delay_time);
				 TIM_SetCompare1(ADVANCE_TIM, 180);
		delay_ms(delay_time);
		TIM_SetCompare1(ADVANCE_TIM, 185);
		delay_ms(delay_time);
		TIM_SetCompare1(ADVANCE_TIM, 190);
		delay_ms(delay_time);
		TIM_SetCompare1(ADVANCE_TIM, 170);
        }
}*/
