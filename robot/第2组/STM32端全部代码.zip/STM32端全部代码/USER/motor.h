#ifndef __MOTOR_H
#define __MOTOR_H 
#include "sys.h"	
#define motor_st_enable GPIO_SetBits(GPIOE, GPIO_Pin_1);
#define motor_st_disable GPIO_ResetBits(GPIOE, GPIO_Pin_1);
#define motor_rb_forword GPIO_SetBits(GPIOE, GPIO_Pin_0); //�Һ�ǰ��
#define motor_rb_back GPIO_ResetBits(GPIOE, GPIO_Pin_0); //�Һ����
#define motor_lf_forword GPIO_ResetBits(GPIOD, GPIO_Pin_6); //��ǰǰ�� 
#define motor_lf_back GPIO_SetBits(GPIOD, GPIO_Pin_6); //��ǰ����

#define motor_lb_forword GPIO_ResetBits(GPIOD, GPIO_Pin_3); //���ǰ��
#define motor_lb_back GPIO_SetBits(GPIOD, GPIO_Pin_3); // ������

#define motor_rf_forword GPIO_SetBits(GPIOB, GPIO_Pin_5);//��ǰ
#define motor_rf_back GPIO_ResetBits(GPIOB, GPIO_Pin_5);//��ǰ
void motor_init(void);
void TIM4_IRQHandler(void);
#endif
