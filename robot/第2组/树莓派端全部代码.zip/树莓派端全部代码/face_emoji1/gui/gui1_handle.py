# -*- coding: utf-8 -*-
"""
Created on Sat Dec  1 15:36:44 2018

@author: lina
"""

import sys
from PyQt5 import QtWidgets 
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from gui2 import Ui_Form

class MyWindow(QtWidgets.QWidget,Ui_Form): 
    def __init__(self): 
        super(MyWindow,self).__init__() 
        self.setupUi(self)
        layout = QVBoxLayout()
        self.setLayout(layout)
        
    def loadFile1(self):
        print("load--file1")
        #fname是要抠脸的图片地址
        fname, _ = QFileDialog.getOpenFileName(self, '选择图片', 'd:\\', 'Image files(*.jpg *.gif *.png)')      
        self.pic_addr.setText(fname)
    
    def radio_button(self):
        
        if self.choose_panda1.isChecked():
            self.pic_addr.setText("you choose 1")
        elif self.choose_panda2.isChecked():
            self.pic_addr.setText("you choose 2")
            
        

if __name__=="__main__": 
    import sys 
    app=QtWidgets.QApplication(sys.argv) 
    myshow=MyWindow() 
    myshow.show() 
    sys.exit(app.exec_())