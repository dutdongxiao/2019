# -*- coding: utf-8 -*-
"""
Created on Sat Dec  1 17:42:16 2018

@author: lina
"""

import sys
from PyQt5 import QtWidgets 
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from gui.show import Ui_Form2
from gui.gui import Ui_Form

class MyWindow2(QtWidgets.QWidget,Ui_Form2): 
    
    def __init__(self): 
        super(MyWindow2,self).__init__() 
        self.setupUi(self)
        layout = QVBoxLayout()
        self.setLayout(layout)
        self.showbox.setPixmap(QPixmap(".\panda.jpg"))
        
    def btn_save(self):
        filename=QFileDialog.getSaveFileName(self,'save file','/home/jm/study')
        with open(filename[0],'w') as f:
            my_text=self.textEdit.toPlainText()
            f.write(my_text)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    MyWindow= MyWindow2()
    sys.exit(app.exec_())