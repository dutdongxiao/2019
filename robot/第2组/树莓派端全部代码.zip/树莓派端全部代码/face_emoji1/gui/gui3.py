# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'picture2.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(605, 594)
        self.panda1 = QtWidgets.QLabel(Form)
        self.panda1.setGeometry(QtCore.QRect(40, 80, 161, 141))
        self.panda1.setText("")
        self.panda1.setPixmap(QtGui.QPixmap("gui/panda1.png"))
        self.panda1.setScaledContents(True)
        self.panda1.setObjectName("panda1")
        self.choose_pic = QtWidgets.QPushButton(Form)
        self.choose_pic.setGeometry(QtCore.QRect(20, 20, 112, 31))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.choose_pic.sizePolicy().hasHeightForWidth())
        self.choose_pic.setSizePolicy(sizePolicy)
        self.choose_pic.setObjectName("choose_pic")
        self.next1 = QtWidgets.QPushButton(Form)
        self.next1.setGeometry(QtCore.QRect(444, 542, 111, 31))
        self.next1.setObjectName("next1")
        self.pic_addr = QtWidgets.QTextEdit(Form)
        self.pic_addr.setGeometry(QtCore.QRect(140, 20, 431, 31))
        self.pic_addr.setObjectName("pic_addr")
        self.choose_panda1 = QtWidgets.QRadioButton(Form)
        self.choose_panda1.setGeometry(QtCore.QRect(90, 230, 89, 16))
        self.choose_panda1.setObjectName("choose_panda1")
        self.panda2 = QtWidgets.QLabel(Form)
        self.panda2.setGeometry(QtCore.QRect(230, 80, 161, 141))
        self.panda2.setText("")
        self.panda2.setPixmap(QtGui.QPixmap("gui/panda2.png"))
        self.panda2.setScaledContents(True)
        self.panda2.setObjectName("panda2")
        self.choose_panda2 = QtWidgets.QRadioButton(Form)
        self.choose_panda2.setGeometry(QtCore.QRect(270, 230, 89, 16))
        self.choose_panda2.setObjectName("choose_panda2")

        self.retranslateUi(Form)
        self.choose_pic.clicked.connect(Form.loadFile1)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.choose_pic.setText(_translate("Form", "选择图片"))
        self.next1.setText(_translate("Form", "已选好，下一步"))
        self.choose_panda1.setText(_translate("Form", "熊猫1"))
        self.choose_panda2.setText(_translate("Form", "熊猫2"))

