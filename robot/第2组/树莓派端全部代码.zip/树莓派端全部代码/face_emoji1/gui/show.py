# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'show.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Form2(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(585, 548)
        self.showbox = QtWidgets.QLabel(Form)
        self.showbox.setGeometry(QtCore.QRect(30, 20, 541, 461))
        self.showbox.setText("")
        self.showbox.setObjectName("showbox")
        self.showbox.setScaledContents(True)
        self.showbox.setPixmap(QtGui.QPixmap("./panda.jpg"))
        self.save = QtWidgets.QPushButton(Form)
        self.save.setGeometry(QtCore.QRect(254, 502, 81, 31))
        self.save.setObjectName("save")

        self.retranslateUi(Form)
        self.save.clicked.connect(Form.btn_save)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "表情包生成成功！"))
        self.save.setText(_translate("Form", "另存为"))

