﻿# -*- coding: utf-8 -*-
"""

"""
from aip import AipFace
import base64
import cv2
import numpy as np
import sys
from PyQt5 import QtWidgets 
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
#from gui.gui import Ui_Form
#from gui.show import Ui_Form2
import sys
sys.path.append('/home/pi/face_emoji1/gui')
from gui import Ui_Form
from show import Ui_Form2

#--------------------后台操作部分:---------------------

def face_rec(imagepath,panda_num):

    # -------------------人脸识别部分:lina!----------------------   
    # 我的百度云接口帐号密码
    APP_ID = '16615395'
    API_KEY = 'UtaHvucob2pMDjDPsvvq7XEG'
    SECRET_KEY = 'BG2Bh5b52g7vMus1hyBml4dS9L0PsyKh'
    client = AipFace(APP_ID,API_KEY,SECRET_KEY)
    # 因为本地图片要用base64编码
    f = open(imagepath, 'rb') # 二进制方式打开图文件
    imageB64 = base64.b64encode(f.read()) # 读取文件内容，转换为base64编码
    #image = str(imageB64, 'utf-8')
    image = str(imageB64)
    #image=base64.encodebytes(f.read())
    f.close()
    # -------------------旋转图片------------------利用
    #result是字典类型
    #对于头歪了的照片把头摆正
    result = client.detect(image,'BASE64', None)
    temp1 = result['result']['face_list'][0]
    location=temp1['location']
    #等会要用rotation
    rotation=location['rotation']#利用百度云api能够获得图像中头的旋转角度
    image_st=cv2.imread(imagepath)#把像素点存入imagin_st
    #得到像素点的列数和行数
    rows,cols = image_st.shape[:2]
    M = cv2.getRotationMatrix2D((cols/2,rows/2),int(rotation),1)#根据旋转角度Rotation 获得获得旋转矩阵
    #输出的图片，矩阵点，像素数量
    new_image = cv2.warpAffine(image_st ,M,(cols,rows))#对图片做仿射变换，类似旋转变换（仿射映射,是指在几何中,一个向量空间进行一次线性变换并接上一个平移,变换为另一个向量空间。）
    cv2.imwrite('temp.jpg',new_image,[int( cv2.IMWRITE_JPEG_QUALITY), 95])

    # -------------------图像处理部分------------------
    f = open(r'./temp.jpg', 'rb') # 二进制方式打开图文件
    imageB64 = base64.b64encode(f.read()) # 读取文件内容，转换为base64编码
    image = str(imageB64)
    #image=base64.encodebytes(f.read())
    f.close()

    #选择参数
    options = {}
    options["face_field"] = "age,beauty,landmark"
    options["max_face_num"] = 1
    options["face_type"] = "LIVE"

    #result是字典类型
    result = client.detect(image,'BASE64', options)
    temp1 = result['result']['face_list'][0]


    # 包含面部的72个特征点，具体参考文档
    landmark72 = temp1['landmark72']


    class AABB: # axis aligned bounding box
        max_x = int(0)
        max_y = int(0)
        min_x = int(100000)
        min_y = int(100000)

    class Point:
        x = float(0)
        y = float(0)

        def __init__(self, px, py):
            self.x = px
            self.y = py

        def subtract(self, other):
            ret = Point
            ret.x = self.x - other.x
            ret.y = self.y - other.y
            return ret

    # 三角形类，可用index对顶点初始化
    class Triangle:
        v1 = Point
        v2 = Point
        v3 = Point

        def __init__(self, p1, p2, p3):
            self.v1 = Point((landmark72[p1]['x']),landmark72[p1]['y'])
            self.v2 = Point((landmark72[p2]['x']), landmark72[p2]['y'])
            self.v3 = Point((landmark72[p3]['x']), landmark72[p3]['y'])


    def is_in_triangle( p , t ):
        AB = Point(t.v2.x-t.v1.x, t.v2.y-t.v1.y)  # t.v2.subtract(t.v1)
        AC = Point(t.v3.x-t.v1.x, t.v3.y-t.v1.y)  # t.v3.subtract(t.v1)
        AP = Point(p.x-t.v1.x, p.y-t.v1.y)  # p.subtract(t.v1)
        # print(t.v1.x, t.v1.y, t.v2.x, t.v2.y, t.v3.x, t.v3.y)
        # print(AB.x, AB.y, AC.x, AC.y)
        s = float(AP.x * AC.y - AC.x * AP.y) / float(AB.x * AC.y - AC.x * AB.y)
        t = float(AP.y * AB.x - AB.y * AP.x) / float(AB.x * AC.y - AC.x * AB.y)
        if s >= 0.0 and t >= 0.0 and s + t <= 1.0:
            return True
        else:
            return False


    # 重新用opencv处理图像
    image = cv2.imread(r'./temp.jpg')

    # 图像尺寸
    imageHeight, imageWidth = image.shape[0:2]

    # 转灰度
    grayImage = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 用来抠图的遮罩(mask)
    grayMask = np.zeros((imageHeight,imageWidth,3), np.uint8)

    # 初始化遮罩为0
    grayMask.fill(0)

    grayMask = cv2.cvtColor(grayMask, cv2.COLOR_BGR2GRAY)


    # 用三角形网格覆盖图片，抠出眉毛、眼、鼻、嘴
    TriangleList = [
            Triangle(13,14,20),Triangle(14,15,20), Triangle(15,19,20),Triangle(15,16,19),Triangle(16,18,19),Triangle(16,17,18), #eye1
            Triangle(29,14,13),Triangle(29,28,14),Triangle(28,15,14),Triangle(28,27,15),Triangle(27,16,15),
            Triangle(27,26,16),Triangle(29,28,14),Triangle(26,17,16),Triangle(26,47,17),
            Triangle(17,47,48),Triangle(17,48,18),

        Triangle(30,31,37),Triangle(31,32,37),Triangle(32,36,37),Triangle(32,33,36),Triangle(33,35,36),Triangle(33,34,35), #eye2
        Triangle(44,34,33),Triangle(45,44,33),Triangle(45,33,32),Triangle(46,45,32),Triangle(46,32,31),
        Triangle(39,46,31),Triangle(39,31,30),Triangle(56,30,55),
    
        Triangle(26,56,47),Triangle(26,39,56),Triangle(25,39,26),Triangle(40,39,26),
    
        Triangle(50,51,49),Triangle(48,49,51),Triangle(48,49,52), Triangle(49,51,52),Triangle(52,53,54),
        Triangle(48,52,54),Triangle(48,54,55), Triangle(47,48,55),Triangle(47,55,56), # nose

        Triangle(58,59,65),Triangle(59,60,65),Triangle(60,64,65),Triangle(60,61,64),Triangle(61,63,64),Triangle(61,62,63),# mouth

        Triangle(22,23,29),Triangle(23,24,29),Triangle(24,28,29),Triangle(24,25,28),Triangle(25,27,28),Triangle(25,26,28),# eye-brow1

        Triangle(39,40,46),Triangle(40,41,46),Triangle(41,45,46),Triangle(41,42,45),Triangle(42,45,44),Triangle(42,43,44) # eye-brow2
        ]

    # 先在原图上"抠图"，用人肉三角化过的72顶点轮廓覆盖住想要的像素区域
    # 不在给定三角形内部的像素统统变成白色底色
    for triIndex in range(len(TriangleList)):
        tri = TriangleList[triIndex]
        for y in range(int(min(tri.v1.y, tri.v2.y, tri.v3.y)), int(max(tri.v1.y, tri.v2.y, tri.v3.y)+1)):
            #for y in range(imageHeight):
            for x in range(int(min(tri.v1.x, tri.v2.x, tri.v3.x)), int(max(tri.v1.x, tri.v2.x, tri.v3.x)+1)):
                # for x in range(imageWidth):
                # 对于三角形附近的像素，都看看在不在三角形内部。不在就clear as white
                if is_in_triangle(Point(x, y), TriangleList[triIndex]):
                    grayMask[int(y), int(x)] = 255



    # 找到landmarks72（除去0~11的脸部轮廓点）的包围盒
    for i in range(13,71):
        if landmark72[i]['x'] > AABB.max_x:
            AABB.max_x = int(landmark72[i]['x'])
        if landmark72[i]['x'] < AABB.min_x:
            AABB.min_x = int(landmark72[i]['x'])
        if landmark72[i]['y'] > AABB.max_y:
            AABB.max_y = int(landmark72[i]['y'])
        if landmark72[i]['y'] < AABB.min_y:
            AABB.min_y = int(landmark72[i]['y'])

    # 裁剪图片以及图片遮罩
    clippedGrayImage = grayImage[AABB.min_y:AABB.max_y, AABB.min_x:AABB.max_x]
    clippedGrayMask = grayMask[AABB.min_y:AABB.max_y, AABB.min_x:AABB.max_x]
    clippedWidth = int(AABB.max_x - AABB.min_x)
    clippedHeight = int(AABB.max_y - AABB.min_y)

    # 对mask执行膨胀操作

    inflatedGrayMask = clippedGrayMask
    halfKernelWidth = int(9)
    # for i in range(halfKernelWidth, clippedHeight-halfKernelWidth):
    #    for j in range(halfKernelWidth, clippedWidth-halfKernelWidth):
    for i in range(0, clippedHeight):
        for j in range(0, clippedWidth):
            # 对于非0的mask位置，按inflateKernel按个印章下去
            #currentMaskVal = clippedGrayMask[i, j]
            newVal = 0
            # if currentMaskVal > 10:
            for m in range(-min(i, halfKernelWidth), min(clippedHeight-i, halfKernelWidth), 3):
                for n in range(-min(j, halfKernelWidth), min(clippedWidth-j, halfKernelWidth), 3):
                     newVal += int(clippedGrayMask[i+m, j+n])  # int(clippedGrayMask[i+m, j+n] + inflateKernel[m+2][n+2])
            newVal /= (halfKernelWidth * halfKernelWidth)
            newVal = newVal * 9 / 4
            # if newVal >= 255:
            #    newVal = 255
            # print(newVal)
            inflatedGrayMask[i, j] = newVal

    # 手动调整色阶（线性映射亮度）
    for i in range(clippedHeight):
        for j in range(clippedWidth):
            lowerBound = 100
            upperBound = 180
            ratio = float(clippedGrayImage[i, j] - lowerBound)/float(upperBound - lowerBound)
            ratio = 1.0 if ratio > 1.0 else (ratio if ratio >= 0.0 else 0.0)
            if inflatedGrayMask[i, j] == 0:
                clippedGrayImage[i, j] = 255
            else:
                clippedGrayImage[i, j] = ratio * inflatedGrayMask[i, j] + (255 - inflatedGrayMask[i, j])


    #cv2.imshow("Mask!", inflatedGrayMask)
    #cv2.waitKey(0)
    cv2.imwrite('face.jpg',clippedGrayImage,[int( cv2.IMWRITE_JPEG_QUALITY), 95])

    #----------------------------图片贴到熊猫头上！----------------------------

    image3 = cv2.imread(r'face.jpg',cv2.IMREAD_GRAYSCALE)
    rows3,cols3 = image3.shape[:2]

    #熊猫头参数
    class panda_para:
        x=int(0)
        y=int(0)
        width=int(0)
        def __init__(self,x1,y1,w1):
            self.x=x1
            self.y=y1
            self.width=w1

    #熊猫头参数
    panda_p=[panda_para(220,100,143),panda_para(161,78,179),panda_para(154,78,200),
             panda_para(214,131,108),panda_para(182,164,67),panda_para(235,70,142)]

    #panda_num=input("请输入想要的熊猫头编号：")
    panda_path="./panda%s.jpg"%(panda_num)
    panda=cv2.imread(panda_path,cv2.IMREAD_GRAYSCALE)
    width=float(panda_p[int(panda_num)-1].width)

    #scale=cols3/width

    r=width/image3.shape[1]
    dim = (int(width), int(image3.shape[0]*r))
    resized_img = cv2.resize(image3, dim, interpolation=cv2.INTER_AREA)

    rows4,cols4 = resized_img.shape[:2]
    print(rows4)
    for num in range(0,rows4):
        for i in range(0,cols4):
            if panda[num+int(panda_p[int(panda_num)-1].y)][i+int(panda_p[int(panda_num)-1].x)]==255:
                panda[num+int(panda_p[int(panda_num)-1].y)][i+int(panda_p[int(panda_num)-1].x)]=resized_img[num][i]
      
        
        
    cv2.imwrite('panda.jpg',panda,[int( cv2.IMWRITE_JPEG_QUALITY), 95])
    #cv2.imshow("Face!", panda)
    #cv2.waitKey(0)        
    
#------------------------------------------------------------------------------
    
#-----------------------GUI部分：lina&wangyu!----------------------------------

class MyWindow2(QtWidgets.QWidget,Ui_Form2):
    
    def __init__(self): 
        super(MyWindow2,self).__init__() 
        self.setupUi(self)
       # print("弹窗在打开")
        self.mainlayout = QGridLayout(self)
        self.labelText = QLabel()
        self.show()
        self.setWindowIcon(QIcon("./gui/show_icon.ico"))
        # self.accepted.connect(self.accept)  # 确定
        # self.rejected.connect(self.reject)  # 取消
        # self.exec_()
       
        
    def btn_save(self):
        filename=QFileDialog.getSaveFileName(self,"保存文件",'/home/pi/face_emoji1',"Image files(*.jpg *.gif *.png)")
        #print(filename)
        ppd=cv2.imread("./panda.jpg") 
        cv2.imwrite(filename[0],ppd,[int( cv2.IMWRITE_JPEG_QUALITY), 95])
        #with open(filename[0],'w') as f:
         #   my_text=self.textEdit.toPlainText()
          #  f.write(my_text)

        
        

class MyWindow(QtWidgets.QWidget,Ui_Form):
    fn='/home/pi/face_emoji1/temp.jpg'
    def __init__(self): 
        super(MyWindow,self).__init__() 
        self.setupUi(self)
        layout = QVBoxLayout()
        self.setLayout(layout)
        self.setWindowIcon(QIcon("./gui/main_icon.ico"))
        
    def loadFile1(self):
        #print("load--file1")
        #fname是要抠脸的图片地址
        fname, _ = QFileDialog.getOpenFileName(self, '选择图片', 'C:\\', 'Image files(*.jpg *.gif *.png)')
        self.pic_addr.setText(fname)
        self.fn=fname
        print(self.fn)
    
    def radio_button(self):
        #print("已点成功，不要再点了")
        num=0
        if self.choose_panda1.isChecked():
            num=1
        else:
            if self.choose_panda2.isChecked():
                num=2
            else:
                if self.choose_panda3.isChecked(): 
                    num=3
                else:
                    if self.choose_panda4.isChecked(): 
                        num=4
                    else:
                        if self.choose_panda5.isChecked(): 
                            num=5
                        else:
                            if self.choose_panda6.isChecked(): 
                                num=6

        face_rec(self.fn,num)
        show_box=MyWindow2()
      


if __name__=="__main__": 
    
    app=QtWidgets.QApplication(sys.argv) 
    myshow=MyWindow() 
    myshow.show() 
    app.exec_()
    #sys.exit(app.exec_())
#---------------------------------------------------------

