# emotion
根据音频声纹判定情绪
## 一、API列表
API名称 | 认证方式 |描述 
-------|------|--------
情绪识别获取API权限|OpenID Connect  & 阿里云APP| 使用阿里云分配的AppKey 和AppSecret通过 API网关以及后台服务验证获取接口访问权限
情绪识别上传音频|OpenID Connect  & 阿里云APP| 上传wav文件,将返回文件id，将用于情绪识别
情绪识别|OpenID Connect  & 阿里云APP|根据音频声纹判定情绪


## 二、 API调用
### 1)公共入参
公共请求参数是指每个接口都需要使用到的请求参数。
参数名称 | 位置 |必须 | 描述
-------|------|--------|----
X-Ca-Key |Header| 是  | Appkey，调用API的身份标识，可以到阿里云[API网关控制台](https://apigateway.console.aliyun.com/#/apps/list)申请
X-Ca-Signature | Header| 是  | 通过签名计算规则计算的请求签名串，参照：<a href="#Signature">签名计算规则</a>
X-Ca-Timestamp | Header| 否  | API 调用者传递时间戳，值为当前时间的毫秒数，也就是从1970年1月1日起至今的时间转换为毫秒，时间戳有效时间为15分钟
X-Ca-Nonce|Header| 否  |API请求的唯一标识符，15分钟内同一X-Ca-Nonce不能重复使用，建议使用 UUID，结合时间戳防重放
Content-MD5|Header| 否  |当请求 Body 非 Form 表单时，需要计算 Body 的 MD5 值传递给云网关进行 Body MD5 校验
X-Ca-Signature-Headers|Header|否|指定哪些Header参与签名，支持多值以","分割，默认只有X-Ca-Key参与签名，为安全需要也请将X-Ca-Timestamp、X-Ca-Nonce进行签名，例如：X-X-Ca-Signature-Headers:Ca-Timestamp,X-Ca-Nonce

### 2)签名计算规则
请求签名，是基于请求内容计算的数字签名，用于API识别用户身份。客户端调用API时，需要在请求中添加计算的签名（X-Ca-Signature）。
#### 签名计算流程
_________________________________________________________
准备APPkey → 构造待签名字符串stringToSign → 使用Secret计算签名
_________________________________________________________

##### 1.准备APPKey
Appkey，调用API的身份标识，可以到阿里云[API网关控制台](https://apigateway.console.aliyun.com/#/apps/list)申请

##### 2.构造待签名字符串stringToSign

````
String stringToSign=
HTTPMethod + "\n" +
Accept + "\n" +                //建议显示设置 Accept Header。当 Accept 为空时，部分 Http 客户端会给 Accept 设置默认值为 */*，导致签名校验失败。
Content-MD5 + "\n"
Content-Type + "\n" +
Date + "\n" +
Headers +
Url
````

###### HTTPMethod
为全大写，如 POST。

````
Accept、Content-MD5、Content-Type、Date 如果为空也需要添加换行符”\n”，Headers如果为空不需要添加”\n”。
````

###### Content-MD5

Content-MD5 是指 Body 的 MD5 值，只有当 Body 非 Form 表单时才计算 MD5，计算方式为：

String content-MD5 = Base64.encodeBase64(MD5(bodyStream.getbytes("UTF-8")));
bodyStream 为字节数组。

###### Headers

Headers 是指参与 Headers 签名计算的 Header 的 Key、Value 拼接的字符串，建议对 X-Ca 开头以及自定义 Header 计算签名，注意如下参数不参与 Headers 签名计算：X-Ca-Signature、X-Ca-Signature-Headers、Accept、Content-MD5、Content-Type、Date。

###### Headers 组织方法：
先对参与 Headers 签名计算的 Header的Key 按照字典排序后使用如下方式拼接，如果某个 Header 的 Value 为空，则使用 HeaderKey + “:” + “\n”参与签名，需要保留 Key 和英文冒号。

````
String headers =
HeaderKey1 + ":" + HeaderValue1 + "\n"\+
HeaderKey2 + ":" + HeaderValue2 + "\n"\+
...
HeaderKeyN + ":" + HeaderValueN + "\n"
````

将 Headers 签名中 Header 的 Key 使用英文逗号分割放到 Request 的 Header 中，Key为：X-Ca-Signature-Headers。

###### Url

Url 指 Path + Query + Body 中 Form 参数，组织方法：对 Query+Form 参数按照字典对 Key 进行排序后按照如下方法拼接，如果 Query 或 Form 参数为空，则 Url = Path，不需要添加 ？，如果某个参数的 Value 为空只保留 Key 参与签名，等号不需要再加入签名。

````
String url =
Path +
"?" +
Key1 + "=" + Value1 +
"&" + Key2 + "=" + Value2 +
...
"&" + KeyN + "=" + ValueN
````

注意这里 Query 或 Form 参数的 Value 可能有多个，多个的时候只取第一个 Value 参与签名计算。

##### 3.使用Secret计算签名

````
Mac hmacSha256 = Mac.getInstance("HmacSHA256");
byte[] keyBytes = secret.getBytes("UTF-8");
hmacSha256.init(new SecretKeySpec(keyBytes, 0, keyBytes.length, "HmacSHA256"));
String sign = new String(Base64.encodeBase64(Sha256.doFinal(stringToSign.getBytes("UTF-8")),"UTF-8"));
````

Secret 为 APP 的密钥，请在[应用管理](https://apigateway.console.aliyun.com/#/apps/list)中获取。
## 三、 API详细信息
### 1、API名称：情绪识别获取API权限
#### *描述*
使用阿里云分配的AppKey 和AppSecret通过 API网关以及后台服务验证获取接口访问权限
####*流程图*
```mermaid
graph LR
    A((客户端))--key和secret签名密钥 --> B((阿里云api网关))
    B((阿里云api网关))-.返回userID和accessToken.-> A((客户端))
    B((阿里云api网关)) --网关验证通过提供AppID-->C((后端获取API权限接口服务))
    C((后端服务))-.服务验证通过提供accessToken.->B((阿里云api网关))
```
```mermaid
graph LR
D((客户端))--key和secret签名密钥 -->E((阿里云api网关))
E((阿里云api网关))-.返回业务数据.-> D((客户端))
E((阿里云api网关)) --网关验证通过提供userID和accessToken-->F((后端获业务接口服务))
F((后端获业务接口服务))-.服务验证通过提供业务数据.->E((阿里云api网关))
```
####* 请求信息*

HTTP协议：HTTP
调用地址：emotio.market.alicloudapi.com/aliyun/vpr/api/v1/user/login
方法：GET

####*返回信息*
参数名称 | 参数类型|必须 | 描述
-------|-------|--------|----------------
data |json结构体| 是  | json结构体
has_error |布尔类型| 是  | 标记HTTP请求是否成功
error_message |string| 是  | 错误信息
error_code |int| 是  | 错误信息
request_id |string| 是  |  HTTP请求唯一ID
data结构体
参数名称 | 参数类型|必须 | 描述
-------|-------|--------|----------------
user_id |string| 是  | 用户唯一性信息
access_token |string| 是  | 访问token

####返回参数类型

JSON

####返回结果示例

````
{
    "data": {
        "user_id": "5cbe70eaaada796153f31a2d",
        "access_token": "eyJhbGciOiJSUzI1NiIsImtpZCI6IjFjZGMyZmFjLTI1NmUtNGZkYy05Mzk3LTAxZjEwZjhhZDQ5MiIsInR5cCI6IkpXVCJ9.eyJ1c2VySUQiOiI1Y2JlNzBlYWFhZGE3OTYxNTNmMzFhMmQiLCJleHAiOjE1NTg2Nzg3MjMsImlzcyI6IlNQRUFLSU4iLCJzdWIiOiJzcGVha2luIn0.czXVZDped2Xpdd9Wlk92h1ILWx5IMbAMMDIiFbdrKXmosr2-zfAPUhmUmidutrk9jVugPq5eJzY9mGgHGaDyXHxdr-REyrqeHJQe5KBdHpWEWltnoKZ7Hx9oHUBBznfJOVhXyQGa90t6K3TH4CwIQOJacKFE2v6UkAoj1pmCKPE38XLEFjKl_2z3T7q1h53f_ZFoj_wjp2QwTJPAotDlUQhSKr-Nt1nOzrup69OMJaP_FYW-qrhmFnMiyJgkGPKc8nsXw8bXSQ9cm6xcZlAcrCeVfJ63JPMPFhMsDwAHheNLzvMCIz0mxI3Kuea8HcQKt-kHta15dQZOaozYynuVzw"
    },
    "has_error": false,
    "error_message": "Login success",
    "error_code": 0,
    "request_id": "cf4ee346-6658-11e9-b94b-00e04c97532f"
}
````

####异常返回示例

````
{
   "data":{},
   "has_error":true,"error_message":"参数校验错误",
   "error_code":40002,
   "request_id":"c9f8cb90-6f02-11e9-a5f2-00163e02dfac"
}
````
####*错误码*
错误码 | 错误信息|描述
-------|-------|--------
40002 |参数校验错误|   | 
40004 |密码输入错误|   | 
40101 |access_token已过期|   | 
40102 |access_token不可用|   | 
40103 |access_token不能为空|   | 
40104 |Token解析错误|   | 
40301 |资源已存在|   | 
50000 |系统内部错误|   | 
公共错误码 |--| 所有API公用的错误码，请参照《 公共错误码 》  | 
### 2、 API名称：情绪识别上传音频
####*描述*

上传wav文件,将返回文件id，将用于情绪识别

####*请求信息*

HTTP协议：HTTP
调用地址：emotio.market.alicloudapi.com/aliyun/vpr/api/v1/users/[user_id]/bucket/[bucket_name]/file/[file_name]/ttl/[ttl]/upload
方法：POST
####*请求参数*
参数名称 | 位置| 参数类型|必须 | 描述 
-------|-------|-------|--------|------------
user_id| PATH|string| 是 | 用户唯一性信息
accessToken| HEAD|string| 是 | 访问权限Token
file_name| PATH|string| 是 | 文件名
bucket_name| PATH|string| 是 | 存储空间名
ttl| PATH|int| 是 | 文件存储有效时长
###  *请求Body描述(非 Form 表单数据)比如 JSON 字符串、文件二进制数据等*
wav 文件字节流 (支持大小为0~5M的wav音频文件)

####*返回信息*
参数名称 | 参数类型|必须 | 描述
-------|-------|--------|----------------
data |json结构体| 是  | json结构体
has_error |布尔类型| 是  | 标记HTTP请求是否成功
error_message |string| 是  | 错误信息
error_code |int| 是  | 错误信息
request_id |string| 是  |  HTTP请求唯一ID
data结构体
参数名称 | 参数类型|必须 | 描述
-------|-------|--------|----------------
bucket |string| 是  | 存储空间名
file_id |string| 是  | 文件唯一ID
####返回参数类型
JSON
####返回结果示例

````
{
    "data": {
        "bucket": "voiceprint",
        "file_id": "1556072512228_ojgKXSedrv_voiceprint"
    },
    "has_error": false,
    "error_message": "Upload success",
    "error_code": 0,
    "request_id": "b8dda15b-6637-11e9-b94b-00e04c97532f"
}
````

####异常返回示例

````
{
    "data": {},
    "has_error": true,
    "error_message": "参数校验错误",
    "error_code": 40002,
    "request_id": "f1a9d8e0-6637-11e9-b94b-00e04c97532f"
}
````
####*错误码*
错误码 | 错误信息|描述
-------|-------|--------
40002 |参数校验错误|   | 
40003 |上传文件格式不支持|   | 
40101 |access_token已过期|   | 
40102 |access_token不可用|   | 
40103 |access_token不能为空|   | 
40104 |Token解析错误|   |  
50000 |系统内部错误|   | 
50001 |文件上传失败|   |
40008 |音频文件大小不支持(支持0~5 M)  |
公共错误码 |--| 所有API公用的错误码，请参照《公共错误码》  | 


###3、API名称：情绪识别
####*描述*
根据音频文件判断说话人的情绪，有【SAD, NORMAL, HAPPY】三种可能的值， 【注：音频文件采样率为16k】
####*请求信息*
HTTP协议：HTTP
调用地址：emotio.market.alicloudapi.com/aliyun/vpr/api/v1/users/[user_id]/voiceprint/emotion
方法：POST
####*请求参数*
参数名称 | 位置| 参数类型|必须 | 描述
-------|-------|-------|--------|------------
user_id| PATH|string| 是 | 用户唯一性信息
accessToken| HEAD|string| 是 | 访问权限Token
####*请求Body描述(非 Form 表单数据)比如 JSON字符串、文件二进制数据等*
````
{
  "file_id": file_id,   // 文件id，（通过上传文件返回）
}
````
####*返回信息*
参数名称 | 参数类型|必须 | 描述
-------|-------|--------|----------------
data |json结构体| 是  | json结构体
has_error |布尔类型| 是  | 标记HTTP请求是否成功
error_message |string| 是  | 错误信息
error_code |int| 是  | 错误信息
request_id |string| 是  |  HTTP请求唯一ID
data结构体
参数名称 | 参数类型|必须 | 描述
-------|-------|--------|-----------
emotion |string| 是  | 情绪信息，例如SAD
####返回参数类型

JSON

####返回结果示例

````
{
   "data":{"emotion":"SAD"},
   "has_error":false,
   "error_message":"Emotion success",
   "error_code":0,
   "request_id":"45a7185f-72fa-11e9-876e-00163e02dfac"
}
````

####异常返回示例

````
{
    "data": {},
    "has_error": true,
    "error_message": "参数校验错误",
    "error_code": 40002,
    "request_id": "f1a9d8e0-6637-11e9-b94b-00e04c97532f"
}
````
####*错误码*
错误码 | 错误信息|描述
-------|-------|--------
40002 |参数校验错误|   | 
40101 |access_token已过期|   | 
40102 |access_token不可用|   | 
40103 |access_token不能为空|   | 
40104 |Token解析错误|   |  
50000 |系统内部错误|   | 
50002 |声纹算法失败|   | 
40009 | 文件id不存在或者过期| |
公共错误码 |--| 所有API公用的错误码，请参照《公共错误码》  | 
##四、公共错误码
###如何获取公共错误
所有的 API 请求只要到达了网关，网关就会返回请求结果信息。

用户需要查看返回结果的头部，即 Header 部分。返回参数如示例：

	//请求唯一ID，请求一旦进入API网关应用后，API网关就会生成请求ID并通过响应头返回给客户端，建议客户端与后端服务都记录此请求ID，可用于问题排查与跟踪
	X-Ca-Request-Id: 7AD052CB-EE8B-4DFD-BBAF-EFB340E0A5AF
	
	//API网关返回的错误消息，当请求出现错误时API网关会通过响应头将错误消息返回给客户端
	X-Ca-Error-Message: Invalid Url
	
	//当打开Debug模式后会返回Debug信息，此信息后期可能会有变更，仅用做联调阶段参考
	X-Ca-Debug-Info: {"ServiceLatency":0,"TotalLatency":2}

在 Header 中获得 X-Ca-Error-Message 可以基本明确报错原因，而 X-Ca-Request-Id 可以用于提供给这边的支持人员，供支持人员搜索日志。
### 公共错误码
#### 客户端错误

| 错误代码                                  | Http 状态码 | 语义                 | 解决方案                                                     |
| ----------------------------------------- | ----------- | -------------------- | ------------------------------------------------------------ |
| Throttled by USER Flow Control            | 403         | 因用户流控被限制     | 调用频率过高导致被流控，可以联系 API 服务商协商放宽限制。    |
| Throttled by APP Flow Control             | 403         | 因APP流控被限制      | 调用频率过高导致被流控，可以联系 API 服务商协商放宽限制。    |
| Throttled by API Flow Control             | 403         | 因 API 流控被限制    | 调用频率过高导致被流控，可以联系 API 服务商协商放宽限制。    |
| Throttled by DOMAIN Flow Control          | 403         | 因二级域名流控被限制 | 直接访问二级域名调用 API，每天被访问次数上限1000次。         |
| TThrottled by GROUP Flow Control          | 403         | 因分组流控被限制     | 调用频率过高导致被流控，可以联系 API 服务商协商放宽限制。    |
| Quota Exhausted                           | 403         | 调用次数已用完       | 购买的次数已用完。                                           |
| Quota Expired                             | 403         | 购买次数已过期       | 购买的次数已经过期。                                         |
| User Arrears                              | 403         | 用户已欠费           | 请尽快充值续费。                                             |
| Empty Request Body                        | 400         | body 为空            | 请检查请求 Body 内容。                                       |
| Invalid Request Body                      | 400         | body 无效            | 请检查请求 Body。                                            |
| Invalid Param Location                    | 400         | 参数位置错误         | 请求参数位置错误。                                           |
| Unsupported Multipart                     | 400         | 不支持上传           | 不支持上传文件。                                             |
| Invalid Url                               | 400         | Url 无效             | 请求的 Method、Path 或者环境不对。请参照错误说明 Invalid Url。 |
| Invalid Domain                            | 400         | 域名无效             | 请求域名无效，根据域名找不到 API。请联系 API 服务商。        |
| Invalid HttpMethod                        | 400         | HttpMethod 无效      | 输入的 Method 不合法。                                       |
| Invalid AppKey                            | 400         | AppKey 无效或不存在  | 请检查传入的 AppKey。注意左右空格的影响。                    |
| Invalid AppSecret                         | 400         | APP 的Secret 错误    | 检查传入的 AppSecret。注意左右空格的影响。                   |
| Timestamp Expired                         | 400         | 时间戳过时           | 请核对请求系统时间是否为标准时间。                           |
| Invalid Timestamp                         | 400         | 时间戳不合法         | 请参照 请求签名说明文档。                                    |
| Empty Signature                           | 404         | 签名为空             | 请传入签名字符串，请参照 请求签名说明文档。                  |
| Invalid Signature, Server StringToSign:%s | 400         | 签名无效             | 签名无效，参照 Invalid Signature 错误说明                    |
| Invalid Content-MD5                       | 400         | Content-MD5 值不合法 | 请求 Body 为空，但传入了 MD5 值，或 MD5 值计算错误。请参照 请求签名说明文档。 |
| Unauthorized                              | 403         | 未被授权             | APP 未获得要调用的 API 的授权。请参照错误说明 Unauthorized。 |
| Nonce Used                                | 400         | SignatureNonce       | 已被使用                                                     |
| API Not Found                             | 400         | 找不到 API           | 传入的APIdi地址或者HttpMethod不正确，或已下线。              |

#### 服务器端错误（调用 API）
以下为API服务端错误，如果频繁错误，可联系服务商。

| 错误代码                         | Http状态码 | 语义         | 解决方案                                                     |
| -------------------------------- | ---------- | ------------ | ------------------------------------------------------------ |
| Internal Error                   | 500        | 内部错误     | 建议重试,或者联系服务商                                      |
| Failed To Invoke Backend Service | 500        | 底层服务错误 | API 提供者底层服务错误，建议重试，如果重试多次仍然不可用，可联系 API 服务商解决 |
| Service Unavailable              | 503        | 服务不可用   | 建议重试,或者联系服务商                                      |
| Async Service                    | 504        | 后端服务超时 | 建议重试,或者联系服务商                                      |