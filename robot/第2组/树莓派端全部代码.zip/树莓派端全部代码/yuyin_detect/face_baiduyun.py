﻿#-*-coding:utf-8-*
import sys
reload(sys)
sys.setdefaultencoding('utf8')
from aip import AipFace
from picamera import PiCamera
import cv2
import urllib
import RPi.GPIO as GPIO
import base64
import time
#百度API需要的信息
APP_ID = '16615395'
API_KEY = 'UtaHvucob2pMDjDPsvvq7XEG'
SECRET_KEY ='BG2Bh5b52g7vMus1hyBml4dS9L0PsyKh'
client = AipFace(APP_ID, API_KEY, SECRET_KEY)#client
#image
IMAGE_TYPE='BASE64'
#user
GROUP = '8848'
#从摄像头读取图片并保存
def getpicture():
	cap = cv2.VideoCapture(0)#打开摄像头
	cap.set(3,320)
	cap.set(4,160)
	cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")#这里是是自己的人脸识别xml路径
	while True:
		# get a frame
		ret, frame = cap.read()#捕获图片
		# show a frame
		gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)#转为灰度图
		rect = cascade.detectMultiScale(gray, scaleFactor=1.15, minNeighbors=5, minSize=(5, 5),flags=cv2.CASCADE_SCALE_IMAGE)  # 使用模板匹配图形
		cv2.imshow("capture", frame)
		if(len(rect)>0):
			for x, y, z, w in rect:
			    cv2.rectangle(frame, (x, y), (x + z, y + w), (0, 0, 255), 2)# 函数的参数分别为：图像，左上角坐标，右下角坐标，颜色，宽度
			cv2.imwrite("faceimage.jpg", frame)#相对路径
			cv2.waitKey(1000)
			break
	cap.release()
	cv2.destroyAllWindows()
#更改图片的编码方式
def transimage():
	f = open('faceimage.jpg','rb')
	img = base64.b64encode(f.read())
	return img
#写入文件
def write_file(f_name):
    f=open('hello.txt','w')
    f.write('你好,'+f_name)
    f.close()
#识别失败的写入文件
def write_file_fail():
    f = open('hello.txt', 'w')
    f.write('对不起，我不认识你')
    f.close()
#上传到百度云
def go_api(image):
	result = client.search(str(image), IMAGE_TYPE, GROUP)
	#result = client.search(str(image, 'utf-8'), IMAGE_TYPE, GROUP)
	if result['error_msg'] == 'SUCCESS':#if success
		name = result['result']['user_list'][0]['user_id']
		score = result['result']['user_list'][0]['score']
		print(score)
		if score > 80:#simility>80
			if name == '001':
				name='马琰'
				print("欢迎%s !" % name)
				write_file(name)
				#time.sleep(3)
			elif name == '002':
				name='廖澎'
				print("欢迎%s !" % name)
				write_file(name)
				#time.sleep(3)
			elif name == "003":
				name='董老师'
				print("欢迎%s !" % name)
				write_file(name)
			elif name == "004":
				name='陈序航'
				print("欢迎%s !" % name)
				write_file(name)
			else:
				print("对不起，我不认识你！")
				name = 'Unknow'
				return 0
			curren_time = time.asctime(time.localtime(time.time()))#获取当前时间
			#Log.txt中
			f = open('Log.txt','a')
			f.write("Person: " + name + "     " + "Time:" + str(curren_time)+'\n')
			f.close()
			return 1
		if result['error_msg'] == 'pic not has face':
			print('检测不到人脸')
			time.sleep(2)
			return 0
		else:
			print(str(result['error_code'])+' ' + str(result['error_code']))
			return 0
def main():
	while True:
		print('准备')
		if True:
			getpicture()#take
			img = transimage()
			res = go_api(img)
			if(res == 1):
				print("刷脸成功")
			else:
				print("刷脸失败")
			print('稍等三秒进入下一个')
			time.sleep(3)
#main
if __name__ == '__main__':
    # while True:
    print('准备')
    if True:
        getpicture()  # take
        img = transimage()
        res = go_api(img)
        if (res == 1):
            print("刷脸成功")
        else:
            print("刷脸失败")
            write_file_fail()
        create_video()
        play_video()





