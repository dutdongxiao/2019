#-*-coding:utf-8-*
import cv2
import imutils
import numpy as np
import time
from uart import *
from gpio import *
#from uart import *

def color_main():
    cap = cv2.VideoCapture(0)
    cap.set(3,320)
    cap.set(4,240)
    boundaries = [ ( [170, 43, 46 ],[180, 255, 255] ) ]  
    GPIO.setmode(GPIO.BCM)
    servo1 = 5
    GPIO.setup(servo1, GPIO.OUT)
    servo2 = 6
    GPIO.setup(servo2, GPIO.OUT)

    anglex=90
    angley=90
    #chip=STM()
    #chip.TurnOn()
    t=time.time()
    cnt=0
    shoot=0
    while True:
        ret, frame = cap.read()
        frame=cv2.flip(frame,1)
        hsv = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV) #RGBתHSV
        cv2.imshow("capture", frame)
        cv2.waitKey(80)
        #if(shoot==1):
            #chip=STM()
            #chip.TurnOn()
            #chip.Send("#DUO30#$")
            #break 
        for (lower, upper) in boundaries:
            lower = np.array(lower, dtype = "uint8")
            upper = np.array(upper, dtype = "uint8")
            mask = cv2.inRange(hsv, lower, upper)           
            cnts = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL,  cv2.CHAIN_APPROX_SIMPLE)
            cnts = cnts[0] if imutils.is_cv2() else cnts[1]
            center = None
            if len(cnts) > 4:
                c = max(cnts, key=cv2.contourArea)
                ((x,y), radius) = cv2.minEnclosingCircle(c) 
                print (int(x),int(y))
                print anglex
                if radius > 2: 
                    if (x > 140) and (x < 180):
                        t=1
                    elif (x <= 140):
                        anglex = anglex + 2
                        if (anglex > 180): anglex = 180
                    elif (x >= 180):
                        anglex = anglex - 2
                        if (anglex < 0): anglex = 0   
                    setServoAngle(servo1,anglex)
                    #chip.Send("#DUO1"+str(anglex)+"#$")
                    #if (y > 70) and (y < 170):
                     #   t=1
                    #elif (y <=70):
                     #   angley = angley - 5
                     #   if (angley < 0):  angley = 0
                    #elif (y >= 170):
                      #  angley = angley + 5
                     #   if (angley > 180): angley = 180
                    #setServoAngle(servo2,angley)
                    #chip.Send("#DUO2"+str(anglex)+"#$")
                    #if(x > 110) and (x < 210) and (y > 70) and (y < 170):
                    if(x > 140) and (x < 180):
                        cnt=cnt+1
                        if(cnt==5):
                            cnt=0
                            time.sleep(3)
                            print "Shoot"
                            shoot=1
                            chip=STM()
                            chip.TurnOn()
                            chip.Send("#DUO30#$")
                            break 
                            
                    else:
                        cnt=0
            else:
                continue
        if(shoot==1):
            break
    #print "123213123123123"
    cap.release()
    cv2.destroyAllWindows()
if __name__ == '__main__':
    color_main()
