from com.aliyun.api.gateway.sdk import client
from com.aliyun.api.gateway.sdk.http import request
from com.aliyun.api.gateway.sdk.common import constant
import json

HOST = "http://emotio.market.alicloudapi.com"
BASE_PATH = "/aliyun/vpr/api/v1"
ACCESS_TOKEN = "accessToken"

class ApiVoicePrint(object):

	# create api instance, please pass the values of you appKey,
	# appSecret and timeout, you can also not to indicate 'timeout' and use it's default
	def __init__(self, appKey=None, appSecret=None, timeout=1000):
		self.__timeout = timeout
		self.__client = client.DefaultClient(app_key=appKey, app_secret=appSecret)
		self.__userid = None
		self.__token = None

	def gen_request(self, url, http_method):
		return request.Request(host=HOST, protocol=constant.HTTP, url=(BASE_PATH+url),
		                       method=http_method, time_out=self.__timeout)

	def get_access(self):
		if self.__userid != None:
			return True

		url = "/user/login"
		req = self.gen_request(url, constant.GET)
		status, _, response = self.__client.execute(req)
		if status != 200:
			return False

		data = json.loads(response, encoding="utf8")["data"]
		self.__userid = data["user_id"]
		self.__token = data["access_token"]

		return True

	# upload file
	def upload_file(self, bucket, file_path, ttl):
		import os.path

		if len(bucket.strip()) == 0:
			raise TypeError("arguments invaild")

		filename = os.path.split(file_path)[1]
		if filename.split('.')[-1] != 'wav':
			raise TypeError("file type error: file type must be wav")

		url = "/users/%s/bucket/%s/file/%s/ttl/%d/upload"%(self.__userid, bucket, filename, ttl)
		req = self.gen_request(url, constant.POST)

		fd = open(file_path, "rb")
		body = fd.read()
		fd.close()

		header = {
			ACCESS_TOKEN: self.__token
		}

		req.set_headers(header)
		req.set_body(body)
		req.set_content_type(constant.CONTENT_TYPE_STREAM)

		return self.__client.execute(req)


	def emotion_identify(self, file_id):
		url = "/users/%s/voiceprint/emotion" % (self.__userid)
		req = self.gen_request(url, constant.POST)

		body = {
			"file_id": file_id,
		}

		header = {
			ACCESS_TOKEN: self.__token
		}
		req.set_headers(header)
		req.set_body(bytearray(source=json.dumps(body), encoding="utf8"))
		req.set_content_type(constant.CONTENT_TYPE_STREAM)

		return self.__client.execute(req)
