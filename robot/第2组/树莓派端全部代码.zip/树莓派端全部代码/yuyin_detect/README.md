# 一、 概述

- 本示例为python3.x版本,该sdk将所有http请求封装到"ApiVoicePrint"类中, 每一个http请求对应该类中的一个方法
- 所有接口除了 get_access (获取访问权限)返回bool类型以外, 其他均返回一个元组, 元组包含3个元素(http返回码, http响应头, http响应体),你可以根据你的需求从响应体中提取想要的信息
- 具体请求字段和返回字段请查看 [API接口文档](API接口文档.md)
- 请参考本目录下 [client_demo.py](client_demo.py), 该文件演示了如何调用api

# 二、 接口列表
Method | HTTP request | Description
------------- | ------------- | -------------
[**get_access**]| **GET** /aliyun/vpr/api/v1/user/login | 获取访问权限
[**upload_file**]| **POST** /aliyun/vpr/api/v1/users/{user_id}/bucket/{bucket_name}/file/{file_name}/ttl/{ttl}/upload | 上传wav文件
[**emotion_identify**]| **POST** /aliyun/vpr/api/v1/users/{user_id}/voiceprint/emotion | 情绪识别

# 三、如何调用接口
```
from com.aliyun.api.gateway.sdk import api

# 使用你的appKey和appSecret去创建一个api实例，后面所有操作通过调用api实例的方法
# 创建实例后必须先调用get_access方法获取访问权限
# timeout 为请求超时(单位ms)，如果不带该参数则默认为1000ms
api_instance = api.ApiVoicePrint("app_key", "app_secret", timeout)
if api_instance.get_access():
    print(api_instance.upload_file("bucket", "file_path", ttl))  # 上传wav文件
    print(api_instance.emotion_identify("file_id"))     # 情绪识别
```

# 四、接口详情
## 1、获取访问权限 get_access()
### *描述*
    必须调用该方法返回True后才能调用其他方法，否则会失败
### *参数*
    无
### *返回*
    bool值, True 为获取权限成功，则可以继续调用该实例其他方法（接口），False 为失败

## 2、 上传wav文件(支持0~5M wav音频文件) upload_file(bucket, file_path, ttl)
### *描述*
    将wav文件上传到储存空间，并返回一个key(file_id)来标识该文件, 后面注册声纹，
    声纹比对都会用到该key
   【注： 1、只支持wav格式的音频文件  2、 同一个文件每次上传都会返回不同的key】
### *参数*
参数名称 | 参数类型|必须 | 来源 | 描述 | 限制条件
-------|-------|--------|----------- |----- |-------
bucket      | string | 是  | 用户自定义       | 储存空间名     | 最大长度30
file_path   | string | 是  | 用户wav文件路径   | wav文件路径   | 文件名最大长度30，例: file_path = /home/xxx/file.wav, 则"file.wav"字符长度不能超过30
ttl         | number | 是  | 用户自定义       | 文件存储时间（单位：秒）  | 取值范围 0～9223372036854775807, 低于30s按30s算

### *返回*
    元组, (http返回码， http响应头， http响应体)
  
## 3、 情绪识别 emotion_identify(file_id)
### *描述*
    情绪识别,根据上传的音频文件返回【"HAPPY", "NORMAL", "SAD"】三个值之一
### *参数*
参数名称 | 参数类型|必须 | 来源 | 描述 
-------|-------|--------|----------- |----- 
file_id      | string | 是  | 通过上传文件返回的file_id       | 文件id     |
### *返回*
    元组, (http返回码， http响应头， http响应体)
 

