﻿# coding: utf-8
from aip import AipSpeech
from pygame import mixer
import time

def play_video():#这个是用来
    mixer.init()
    mixer.music.load('aui.mp3')
    mixer.music.play()
    time.sleep(3)
    mixer.music.stop()

def create_video():
    APP_ID = '16642285'  # 引号之间填写之前在ai平台上获得的参数
    API_KEY = 'ZFn8pnHKCtOMr6AtcoVNN8gI'  # 如上
    SECRET_KEY = 'aNLMGRvO25BOFa3W8jtSosNm1br5rA7B'  # 如上
    client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)
    f1 = open('hello.txt', 'r')
    lan = f1.read()
    print(lan)
    result = client.synthesis(lan, 'zh', 1, {'vol': 5, 'per': 4, 'spd': 5})
    f1.close()
    # 固定值zh。语言选择,目前只有中英文混合模式，填写固定值zh
    # 客户端类型选择，web端填写固定值1
    # spd语速，取值0-15，默认为5中语速(选填)
    # pit音调，取值0-15，默认为5中语调（选填）
    # vol音量，取值0-15，默认为5中音量（选填）
    # per发音人选择, 0为普通女声，1为普通男生，3为情感合成-度逍遥，4为情感合成-度丫丫，默认为普通女声
    if not isinstance(result, dict):
        with open('aui.mp3', 'wb+') as f:
            f.write(result)
if __name__ == '__main__':
    create_video()
    play_video()

