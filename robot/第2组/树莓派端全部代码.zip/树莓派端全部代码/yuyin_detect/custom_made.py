# -*- coding: utf-8 -*-
"""
Created on Wed Jul  3 18:57:55 2019

@author: 廖澎
"""

from aip import AipSpeech
from playsound import playsound

def create_video():
    APP_ID = '16642285'  
    API_KEY = 'ZFn8pnHKCtOMr6AtcoVNN8gI' 
    SECRET_KEY = 'aNLMGRvO25BOFa3W8jtSosNm1br5rA7B'  
    client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)
    f1 = open('custom_made.txt', 'r')
    lan = f1.read()
    print(lan)
    result = client.synthesis(lan, 'zh', 1, {'vol': 5, 'per': 4, 'spd': 5})
#    f1.close()
    if not isinstance(result, dict):
        with open('test.mp3', 'wb+') as f:
            f.write(result)
if __name__ == '__main__':
    create_video()
    playsound('test.mp3')
