# -*- coding: utf-8 -*-
"""
Created on Sat Jul  6 10:27:04 2019

@author: 廖澎
"""
from playsound import playsound

playsound('Jam.mp3')

