# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 18:50:50 2019

@author: 廖澎
"""
#语音识别
import wave
import requests
import time
import base64
from pyaudio import PyAudio, paInt16
from color_detect import color_main
#语音聊天
import json
import urllib2

#语音合成
from aip import AipSpeech

#语音播报
import pygame

#32通信
from uart import *

#情绪识别
#from client_demo import emotion_recognition

#语音唤醒
import snowboydecoder
import signal

#遥控
from tcpsocket import socket_fun

interrupted = False


def signal_handler(signal, frame):
    global interrupted
    interrupted = True


def interrupt_callback():
    global interrupted
    return interrupted


#录音提示
import pyaudio
def play_audio_files(filename):
    ding_wav = wave.open(filename, 'rb')
    ding_data = ding_wav.readframes(ding_wav.getnframes())
    audio = pyaudio.PyAudio()
    stream_out = audio.open(
        format=audio.get_format_from_width(ding_wav.getsampwidth()),
        channels=ding_wav.getnchannels(),
        rate=ding_wav.getframerate(), input=False, output=True)
    stream_out.start_stream()
    stream_out.write(ding_data)
    time.sleep(0.2)
    stream_out.stop_stream()
    stream_out.close()
    audio.terminate()

#语音识别
framerate = 16000  # 采样率
num_samples = 2000  # 采样点
channels = 1  # 声道
sampwidth = 2  # 采样宽度2bytes
FILEPATH = 'speech.wav'
global result


base_url = "https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=%s&client_secret=%s"
APIKey = 'kVcnfD9iW2XVZSMaLMrtLYIz'
SecretKey = 'O9o1O213UgG5LFn0bDGNtoRN3VWl2du6'

HOST = base_url % (APIKey, SecretKey)


def getToken(host):
    res = requests.post(host,verify=False)
    return res.json()['access_token']
  
      
def save_wave_file(filepath, data):
    wf = wave.open(filepath, 'wb')
    wf.setnchannels(channels)
    wf.setsampwidth(sampwidth)
    wf.setframerate(framerate)
    wf.writeframes(b''.join(data))
    wf.close()


def my_record(captrue_time):
    play_audio_files('ding.wav')
    pa = PyAudio()
    stream = pa.open(format=paInt16, channels=channels,
                     rate=framerate, input=True, frames_per_buffer=num_samples)
    my_buf = []
    # count = 0
    t = time.time()
    print('正在录音...')
  
    while time.time() < t + captrue_time:  # 秒
        string_audio_data = stream.read(num_samples)
        my_buf.append(string_audio_data)
    print('录音结束.')
#    play_audio_files('dong.wav')
    save_wave_file(FILEPATH, my_buf)
    stream.close()


def get_audio(file):
    with open(file, 'rb') as f:
        data = f.read()
    return data


def speech2text(speech_data, token, dev_pid=1537):
    FORMAT = 'wav'
    RATE = '16000'
    CHANNEL = 1
    CUID = 'b8:27:eb:e2:93:da'
    SPEECH = base64.b64encode(speech_data).decode('utf-8')

    data = {
        'format': FORMAT,
        'rate': RATE,
        'channel': CHANNEL,
        'cuid': CUID,
        'len': len(speech_data),
        'speech': SPEECH,
        'token': token,
        'dev_pid':dev_pid
    }
    url = 'https://vop.baidu.com/server_api'
    headers = {'Content-Type': 'application/json'}
    # r=requests.post(url,data=json.dumps(data),headers=headers)
    print('正在识别...')
    r = requests.post(url, json=data, headers=headers,verify=False)
    Result = r.json()
    if 'result' in Result:
        return Result['result'][0]
    else:
        return Result

#语音合成
def create_video():
    APP_ID = '16642285'  
    API_KEY = 'ZFn8pnHKCtOMr6AtcoVNN8gI' 
    SECRET_KEY = 'aNLMGRvO25BOFa3W8jtSosNm1br5rA7B'  
    client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)
    f1 = open('answer.txt', 'r')
    lan = f1.read()
    print(lan)
    result = client.synthesis(lan, 'zh', 1, {'vol': 5, 'per': 4, 'spd': 5})
    f1.close()
    if not isinstance(result, dict):
        with open('chat_robot.mp3', 'wb+') as f:
            f.write(result)


#语音播报
def play(filename):
    pygame.mixer.init()
    pygame.mixer.music.load(filename)
    pygame.mixer.music.play(loops=0)
    while True:
        if not pygame.mixer.music.get_busy():
            break
            
            
#语音聊天
def chat():
    try:
        api_url = "http://openapi.tuling123.com/openapi/api/v2"
        global result
        text_input =result
        req = {
            "reqType": 0,  # 输入类型 0-文本, 1-图片, 2-音频
            "perception":  # 信息参数
            {
                "inputText":  # 文本信息
                {
                    "text": text_input
                },

                "selfInfo":  # 用户参数
                {
                    "location":
                    {
                        "city": "大连",  # 所在城市
                        "province": "辽宁",  # 省份
                        "street": "凌工路2号"  # 街道
                    }
                }
            },
            "userInfo":
            {
                "apiKey": "ab790e4d7a3e4cfbaadfbf7a7329c79c",  # 改为自己申请的key
                "userId": "0001"  # 用户唯一标识(随便填, 非密钥)
            }
        }
        # print(req)
        # 将字典格式的req编码为utf8
        req = json.dumps(req).encode('utf8')
        # print(req)
        http_post = urllib2.Request(api_url, data=req, headers={'content-type': 'application/json'})
        response = urllib2.urlopen(http_post)
        response_str = response.read().decode('utf8')
        # print(response_str)
        response_dic = json.loads(response_str)
        # print(response_dic)
        #intent_code = response_dic['intent']['code']
        global results_text
        results_text = response_dic['results'][0]['values']['text']
        print('机器人1号：', results_text)
        f=open('answer.txt','w')
        f.write(results_text)
        f.close()
        # print('code：' + str(intent_code))
        create_video()
        play('chat_robot.mp3')
        
    except KeyError:
        print('出错啦~~, 下次别问这样的问题了')
        

# 热词唤醒    
def wake_up():
    global detector
    model = 'xm.pmdl'  #  唤醒词为 SnowBoy
    # capture SIGINT signal, e.g., Ctrl+C
    signal.signal(signal.SIGINT, signal_handler)
    # 唤醒词检测函数，调整sensitivity参数可修改唤醒词检测的准确性
    detector = snowboydecoder.HotwordDetector(model, sensitivity=0.5)
    print('Listening... please say wake-up word:SnowBoy')
    # main loop
    # 回调函数 detected_callback=snowboydecoder.play_audio_file 
    # 修改回调函数可实现我们想要的功能
    detector.start(detected_callback=core,      # 自定义回调函数
                   interrupt_check=interrupt_callback,
                   sleep_time=0.03)
    # 释放资源
    detector.terminate() 
  
def core():    
    global result
    global detector
    play('i\'am_here.mp3')
    #  关闭snowboy功能
    detector.terminate()
    my_record(4)
        #os.close(sys.stderr.fileno())
    TOKEN = getToken(HOST)
    speech = get_audio(FILEPATH)
    result = speech2text(speech, TOKEN, 1536)
    print(result)     
#    f=open('res.txt','w')
#    f.write(result)
#    f.close()
    if "小车" in result:
        time.sleep(2)
        while True:           
            my_record(2)
            #os.close(sys.stderr.fileno())
            TOKEN = getToken(HOST)
            speech = get_audio(FILEPATH)
            result = speech2text(speech, TOKEN, 1536)
            print(result)
            if "前进" in result: #在返回的文本里寻找“开”                
                chip=STM()
                chip.TurnOn()
                chip.Send("#FORWARD#$")
                play('FORWARD.mp3')
            elif "左转" in result:
                chip=STM()
                chip.TurnOn()
                chip.Send("#LEFT#$")
                play('LEFT.mp3')
            elif "右转" in result: #在返回的文本里寻找“开”
                chip=STM()
                chip.TurnOn()
                chip.Send("#RIGHT#$")
                play('RIGHT.mp3')
            elif "后退" in result: #在返回的文本里寻找“开”                
                chip=STM()
                chip.TurnOn()
                chip.Send("#BACK#$")
                play('BACK.mp3')
            elif "加速" in result: #在返回的文本里寻找“开”
                chip=STM()
                chip.TurnOn()
                chip.Send("#FLASTER#$")
                play('FLASTER.mp3')
            elif "减速" in result: #在返回的文本里寻找“开”
                chip=STM()
                chip.TurnOn()
                chip.Send("#SLOWER#$")
                play('SLOWER.mp3')
            elif "停止" in result: #在返回的文本里寻找“开”
                chip=STM()
                chip.TurnOn()
                chip.Send("#STOP#$")
            elif "避障" in result: #在返回的文本里寻找“开”
                chip=STM()
                chip.TurnOn()
                chip.Send("#DISTANCE#$")
            elif "结束" in result: #在返回的文本里寻找“开”
                chip=STM()
                chip.TurnOn()
                chip.Send("#STOPXUNDAO#$")
            elif "退出" in result:
                play('exit.mp3')
                break
            else:
                play('cmd.mp3')
    elif "问答" in result:
        time.sleep(2)
        while True:           
            my_record(4)
            #os.close(sys.stderr.fileno())
            TOKEN = getToken(HOST)
            speech = get_audio(FILEPATH)
            result = speech2text(speech, TOKEN, 1536)
            print(result)
            if  "退出" in result:
                play('exit.mp3')
                break
            elif "u盘" in result:
                play('u.mp3')
            elif "读卡器" in result:
                play('card.mp3')
            else:
                play('cmd.mp3')
    elif "投篮" in result:
        time.sleep(2)
        while True: 
            my_record(4)
            #os.close(sys.stderr.fileno())
            TOKEN = getToken(HOST)
            speech = get_audio(FILEPATH)
            result = speech2text(speech, TOKEN, 1536)
            if "投篮" in result:
                color_main()
            elif "复位" in result:
                chip=STM()
                chip.TurnOn()
                chip.Send("#DUO390#$")
                time.sleep(5)
            elif "退出" in result:
                play('exit.mp3')
                break
            else:
                play('cmd.mp3') 
    
#    elif "情绪" in result:
#        time.sleep(2)
#        while True:           
#            my_record(4)
#            TOKEN = getToken(HOST)
#            speech = get_audio(FILEPATH)
#            result = speech2text(speech, TOKEN, 1536)
#            if "退出" in result:
#                play('exit.mp3')
#                break
#           else:
#                emotion_recognition()

    elif "遥控" in result:
        time.sleep(2)
        while True:           
            my_record(4)
            TOKEN = getToken(HOST)
            speech = get_audio(FILEPATH)
            result = speech2text(speech, TOKEN, 1536)
            if "退出" in result:
                play('exit.mp3')
                break
            elif "连接" in result:
                socket_fun()
            else:
                play('cmd.mp3')                
    elif "退出监听" in result:
        detector.terminate()
        play('exit_monitor.mp3')
    else:
        time.sleep(2)
        while True:           
            my_record(4)
            #os.close(sys.stderr.fileno())
            TOKEN = getToken(HOST)
            speech = get_audio(FILEPATH)
            result = speech2text(speech, TOKEN, 1536)
            if "退出" in result:
                play('exit.mp3')
                break
            else:
                chat()
    # 打开snowboy功能
    wake_up()

if __name__ == '__main__':
    wake_up()
