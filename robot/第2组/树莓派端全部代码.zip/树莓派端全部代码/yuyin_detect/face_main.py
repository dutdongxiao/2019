# coding: utf-8
from face_baiduyun import *
from voice_baiduyun import *
#from uart import *
import sys
#sys.path.append('/home/pi/face_emoji1')
#from faceExtraction import *
#sys.path.append('/home/pi/face_emoji1/gui')
#from gui import Ui_Form
#from show import Ui_Form2
sys.path.append('/home/pi/yuyin_detect')
from speech_recognition import wake_up
from picture import bd_rec_face
print('准备')
getpicture()  # take
print 111
img = transimage()
res = go_api(img)
if (res == 1):
    print("刷脸成功")
    client_id = 'uQQCAK3c4QXo1SFL6sy5yFre'  # ak
    client_secret = 'kpjmTVI9bYUc1kVMUCOWQKLUytyBnwFn'  # sk
    bd_rec_face(client_id, client_secret)
    wake_up()
else:
    print("刷脸失败")
    write_file_fail()
create_video()
play_video()
#chip=STM()
#chip.TurnOn()
#chip.Send("#FORWARD#$")
