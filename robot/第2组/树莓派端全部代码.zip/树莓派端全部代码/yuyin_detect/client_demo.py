# -*- coding: utf-8 -*-
#! /usr/bin/python

############################################################################
# this is a demo to show you how to call the api
# you should create a ApiVoicePrint instance with your appKey, appSecret and
# a timeout parameter(default 1000 if you didn't indicate)
######################################################################
from com.aliyun.api.gateway.sdk import api
from aip import AipSpeech
import pygame

file_id = "1562506158336_mujCMXuafo_bucket"

# 这里将你的appKey和appSecret替换成真实配置
app_key = "203724143"
app_secret = "enw7di0oilcmqcj87mnz8cz9j6gwjtvk"
def create_video():
    APP_ID = '16642285'
    API_KEY = 'ZFn8pnHKCtOMr6AtcoVNN8gI'
    SECRET_KEY = 'aNLMGRvO25BOFa3W8jtSosNm1br5rA7B'
    client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)
    f1 = open('answer.txt', 'r')
    lan = f1.read()
    print(lan)
    result = client.synthesis(lan, 'zh', 1, {'vol': 5, 'per': 4, 'spd': 5})
    f1.close()
    if not isinstance(result, dict):
        with open('chat_robot.mp3', 'wb+') as f:
            f.write(result)
def play(filename):
    pygame.mixer.init()
    pygame.mixer.music.load(filename)
    pygame.mixer.music.play(loops=0)
    while True:
        if not pygame.mixer.music.get_busy():
            break


def emotion_recognition():    
    api_instance = api.ApiVoicePrint(app_key, app_secret, 1000)
    if api_instance.get_access():
        d=api_instance.upload_file("bucket", "speech.wav", 3000)[-1][38:69]
        api_instance.emotion_identify(file_id)
        f=open('answer.txt','w')
        f.write(api_instance.emotion_identify(file_id)[-1][20:-122])
        f.close()
        create_video()
        play('chat_robot.mp3')
