#-*-coding:utf-8-*
import sys
reload(sys)
sys.setdefaultencoding('utf8')
from aip import AipFace
from picamera import PiCamera
import cv2
import urllib
import RPi.GPIO as GPIO
import base64
import time
#百度API需要的信息
APP_ID = '16615395'
API_KEY = 'UtaHvucob2pMDjDPsvvq7XEG'
SECRET_KEY ='BG2Bh5b52g7vMus1hyBml4dS9L0PsyKh'
client = AipFace(APP_ID, API_KEY, SECRET_KEY)#client
#image
IMAGE_TYPE='BASE64'
#user
GROUP = '8848'
#从摄像头读取图片并保存

while True:
	cap = cv2.VideoCapture(0)#打开摄像头
	cap.set(3,320)
	cap.set(4,160)
	cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")#这里是是自己的人脸识别xml路径
	# get a frame
	ret, frame = cap.read()#捕获图片
	# show a frame
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)#转为灰度图
	rect = cascade.detectMultiScale(gray, scaleFactor=1.15, minNeighbors=5, minSize=(5, 5),flags=cv2.CASCADE_SCALE_IMAGE)  # 使用模板匹配图形
	cv2.imshow("capture", frame)
cap.release()
cv2.destroyAllWindows()
