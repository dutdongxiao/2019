from time import sleep
import RPi.GPIO as GPIO

#GPIO.setmode(GPIO.BCM)
#servo = 5
#GPIO.setup(servo, GPIO.OUT)
#servo2 = 5
#GPIO.setup(servo2, GPIO.OUT)

def setServoAngle(servo, angle):
    pwm = GPIO.PWM(servo, 50) #channel,frequence=50Hz
    pwm.start(7.5) #start pwm
    dutyCycle = angle / 18. + 2.5 #PWM 2.5%~12.5%
    pwm.ChangeDutyCycle(dutyCycle) #change pwm
    sleep(0.1)
    pwm.stop()

if __name__ == '__main__':
    setServoAngle(servo,90) #set angle
    GPIO.cleanup()
