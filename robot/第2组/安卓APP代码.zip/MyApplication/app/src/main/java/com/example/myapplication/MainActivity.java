package com.example.myapplication;

import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.view.MenuItem;
import android.widget.TextView;
import android.os.StrictMode;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {
    private EditText et_send;
    private Button bt_send;
    private TextView tv_recv;
    private Button bt_forward;
    private Button bt_back;
    private Button bt_right;
    private Button bt_left;
    private Button bt_faster;
    private Button bt_slower;
    private Button bt_oldspeed;
    private Button bt_duankai;
    private Button bt_stop;
    private Button bt_launch;
    private Button bt_reset;
    private Button bt_zuoxuan;
    private Button bt_youxuan;
    private Button bt_distance;
    private Button bt_xunji;
    private Button bt_stopxundao;

    private String send_buff=null;
    private String recv_buff=null;
    private String host_ip=null;
    private Handler handler = null;
    private int flag=0;
    Socket socket = null;

    View.OnClickListener yourListener= new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.bt_forward:
                    send_buff = "#FORWARD#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_back:
                    send_buff = "#BACK#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_right:
                    send_buff = "#RIGHT#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_left:
                    send_buff = "#LEFT#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_faster:
                    send_buff = "#FASTER#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_slower:
                    send_buff = "#SLOWER#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_oldspeed:
                    send_buff = "#OLDSPEED#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_stop:
                    send_buff = "#STOP#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_launch:
                    send_buff = "#DUO30#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_reset:
                    send_buff = "#DUO363#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_zuoxuan:
                    send_buff = "#ZUOXUAN#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_youxuan:
                    send_buff = "#YOUXUAN#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_distance:
                    send_buff = "#DISTANCE#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_xunji:
                    send_buff = "#XUNJI#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_stopxundao:
                    send_buff = "#STOPXUNDAO#$";
                    System.out.println(send_buff);
                    break;
                case R.id.bt_duankai:
                    send_buff = "close";
                    System.out.println(send_buff);
                    /*if(socket!=null) {
                        try {
                            if (socket != null) {
                                System.out.println("###################");
                                socket.close();
                            } else
                                System.out.println("socket is null");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }*/
                    break;
                default:
                    break;

            }
            new Thread(new Runnable() {
                @Override
                public void run() {
                        if (socket!=null) {
                            System.out.println("###################");
                                if (send_buff != null){
                                    //向服务器端发送消息
                                    System.out.println(send_buff);
                                    OutputStream outputStream = null;
                                    try {
                                        outputStream = socket.getOutputStream();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }

                                    if (outputStream != null) {
                                        try {
                                            outputStream.write(send_buff.getBytes());
                                            System.out.println("1111111111111111111111");
                                            outputStream.flush();
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }//循环进行收发
                            if(send_buff=="close"){
                                try {
                                    if (socket != null) {
                                        System.out.println("###################");
                                        socket.close();
                                    } else
                                        System.out.println("socket is null");
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                socket=null;
                            }
                        }
                        else
                            System.out.println("socket is null");
                }
            }).start();
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();

        handler = new Handler();
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                .detectDiskReads().detectDiskWrites().detectNetwork()
                .penaltyLog().build());
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                .detectLeakedSqlLiteObjects().penaltyLog().penaltyDeath()
                .build());
        //连接按钮监听
        bt_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String strip=et_send.getText().toString().trim();

                    //开始启动连接线程
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            System.out.println(strip);
                            socket = new Socket(strip, 7654);
                            if (socket!=null) {
                                System.out.println("###################");
                                while (true) {      //循环进行收发
                                    recv();
                                }
                            }
                            else
                                System.out.println("socket is null");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();


            }
        });
        //单开一个线程来进行socket通信
    }


    private void recv() {

        //单开一个线程循环接收来自服务器端的消息
        InputStream inputStream = null;
        try {
            inputStream = socket.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (inputStream!=null){
            try {
                byte[] buffer = new byte[1024];
                int count = inputStream.read(buffer);//count是传输的字节数
                recv_buff = new String(buffer);//socket通信传输的是byte类型，需要转为String类型
                System.out.println(recv_buff);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        //将受到的数据显示在TextView上
        if (recv_buff!=null){
            handler.post(runnableUi);

        }
    }

    //不能在子线程中刷新UI，应为textView是主线程建立的
    Runnable runnableUi = new Runnable() {
        @Override
        public void run() {
            tv_recv.append("\n"+recv_buff);
        }
    };


    private void initView() {
        et_send = (EditText) findViewById(R.id.et_send);
        bt_send = (Button) findViewById(R.id.bt_send);
        tv_recv = (TextView) findViewById(R.id.tv_recv);
        bt_forward = (Button) findViewById(R.id.bt_forward);
        bt_back = (Button) findViewById(R.id.bt_back);
        bt_left = (Button) findViewById(R.id.bt_left);
        bt_right = (Button) findViewById(R.id.bt_right);
        bt_oldspeed = (Button) findViewById(R.id.bt_oldspeed);
        bt_faster = (Button) findViewById(R.id.bt_faster);
        bt_slower = (Button) findViewById(R.id.bt_slower);
        bt_duankai = (Button) findViewById(R.id.bt_duankai);
        bt_stop = (Button) findViewById(R.id.bt_stop);
        bt_launch = (Button) findViewById(R.id.bt_launch);
        bt_reset = (Button) findViewById(R.id.bt_reset);
        bt_zuoxuan = (Button) findViewById(R.id.bt_zuoxuan);
        bt_youxuan = (Button) findViewById(R.id.bt_youxuan);
        bt_distance = (Button) findViewById(R.id.bt_distance);
        bt_xunji = (Button) findViewById(R.id.bt_xunji);
        bt_stopxundao = (Button) findViewById(R.id.bt_stopxundao);
        bt_forward.setOnClickListener(yourListener);
        bt_back.setOnClickListener(yourListener);
        bt_right.setOnClickListener(yourListener);
        bt_left.setOnClickListener(yourListener);
        bt_send.setOnClickListener(yourListener);
        bt_faster.setOnClickListener(yourListener);
        bt_slower.setOnClickListener(yourListener);
        bt_oldspeed.setOnClickListener(yourListener);
        bt_duankai.setOnClickListener(yourListener);
        bt_stop.setOnClickListener(yourListener);
        bt_launch.setOnClickListener(yourListener);
        bt_reset.setOnClickListener(yourListener);
        bt_zuoxuan.setOnClickListener(yourListener);
        bt_youxuan.setOnClickListener(yourListener);
        bt_distance.setOnClickListener(yourListener);
        bt_xunji.setOnClickListener(yourListener);
        bt_stopxundao.setOnClickListener(yourListener);
    }

}
