# -*- coding: utf-8 -*-
"""
Created on Fri Jul  5 10:27:12 2019

@author: 爱雪
"""
import sys
sys.path.append(r'F:/speech_recognition/code')
import multiprocessing as mp
import signal
import speech_recognition as sr
import control4 as tq
import time
import serial
import Command_File
COMMAND_FILE="F:/speech_recognition/txt/command.txt"

def search(key_word: int):
    with open(COMMAND_FILE) as f:
        for index, line in enumerate(f.readlines()):
            if key_word in line:
                return True

def main():
    ser = serial.Serial("/dev/ttyAMA0", 9600)#串口介入stm32
    ser.write(b"Raspberry pi is ready")
    print("connected to stm32!")
    
    q1=mp.Queue(100)
    q2=mp.Queue(10)
    q2.open()
    q3=mp.Queue(2)
    q_left = mp.Queue(100)
    q_forward = mp.Queue(100)
    p1=mp.Process(target=tq.main,args=(q1,q3))
    p2 = mp.Process(target=sr.music,args=(q2,q3))
    p_take=mp.Process(target=Command_File.avoid,args=(q_left,q_forward,q3,ser))
    
    p1.daemon=True
    p2.daemon=True
    p_take.daemon=True
    p1.start()
    p2.start()
    p_take.start()
    
    sign=True
    data=1000
    flush_sign=False
    write_sign = False
    command_list=[]
    s_name = 'liuhongrui'
    start=0
    end=0
    while True:
        
        #安卓与语音权限争夺
        if not q2.empty():
            data=q2.get()
            print(data)
        if data==100:
            sign=False
        elif data==0:
            sign=True
            data=1000
            flush_sign=True #清空队列使用
            while not q1.empty():
                print(q1.get())     
        if sign and flush_sign:
            flush_sign=False
            data=1000
            
        #安卓输入,其中含有是否进行路径学习的Write_sign和代码
        if  sign and not q1.empty():
            data=q1.get()
            if write_sign and data!=1000:
                end = time.time()
                start = time.time()
                command_time=end-start
                if command_time <1000:    
                    command_list.append(str(command_time))
                command_list.append(data)
            print(data)
        
        if not write_sign and command_list:
            #s_name = q1.get()
            command_list.pop()
            command_list.append('$')
            Command_File.learn_path(s_name,command_list)
            command_list = []
            
        #指令判断  
        if search(data+'$'):
            ser.write(data+'$')
        elif data == "200":   #应该自动取快递了
            data = 1000
            Command_File.auto_take(q1,q_forward,command_list)
        elif data=="10":                    #学习
            data=1000
            write_sign = not write_sign
        elif data=="50":                      #自动取快递
            s_name = q2.get()
            p4=mp.Process(target=Command_File.read_path,args=(s_name,q2,q_forward)) #可以增加进程同步的代码
            p4.start()
            data=1000
        elif data == "60":                   #调用图像识别取快递
            s_name = q2.get()
            if s_name == "moshengren":
                p5=mp.Process(target=Command_File.read_all_path,args=("moshengren",q2,q_forward,q_left,True,True))
                p5.start()
            else:
                p6=mp.Process(target=Command_File.read_path,args=(s_name,q2,q_forward)) 
                p6.start()
            data=1000
            
        
        if not q3.empty():
            
            data1=q3.get()
            if data1==-100:
                q3.put(-100)
                time.sleep(1)
                break
            

if __name__ == '__main__':
    main()
