# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import pyaudio
import wave
from aip import AipSpeech
import time
from pydub import AudioSegment
import sys

sys.path.append(r'F:/speech_recognition/code')

#自定义函数
import c_pinyin
import play_music
import record
import multiprocessing as mp

WAVE_OUTPUT_FILENAME = "F:/speech_recognition/music/test.wav"
mp3_output_filename = "F:/speech_recognition/music/test.mp3"
             
        
def music(q,q_close):      
    while True:
        record.rec(WAVE_OUTPUT_FILENAME) 
        result=record.m_to_word()   
        if result["err_no"]==0:
            tmp=result["result"][0]
            tmp_pin=c_pinyin.hp(tmp)
            print(tmp)
            if tmp_pin.find("xiaodu")!=-1 or tmp_pin.find("xiaozhu")!=-1:
                welcome_word='在呢'
                msg=100
                q.put(msg)
                play_music.initialize(welcome_word)
                play_music.play()
                print("程序开始")
                
                
                while(True):
                    record.rec(WAVE_OUTPUT_FILENAME) 
                    result=record.m_to_word()
                    if result["err_no"]==0:
                        tmp=result["result"][0]
                        tmp_pin=c_pinyin.hp(tmp)
                        if tmp_pin.find("jieshu")!=-1:
                            print(tmp_pin)
                            output='程序已结束'
                            q.put(0)
                            play_music.initialize(output)
                            play_music.play()
                            break
                        else:
                            print(result["result"])
                            print(c_pinyin.hp(result["result"][0]))
                            tmp1=result["result"][0]
                            command_string,msg=c_pinyin.command(tmp1,q)
                            q.put(msg)
                            if msg == 50 or msg == 60:
                                q.put(command_string)
                            output=command_string
                            play_music.initialize(output)
                            play_music.play()
            elif tmp_pin.find("tingzhi")!=-1:
                output="正在关机"
                play_music.initialize(output)
                play_music.play()
                q_close.put(-100)
                print(tmp_pin)
                break
                                
           






