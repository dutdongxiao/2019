import numpy
import cv2
import face_recognition

OUT_IMG="F:/speech_recognition/img/face.jpg"

def faceDetect():
    url = "http://192.168.137.34:8080/?action=snapshot"
    classifier = cv2.CascadeClassifier( "./haarcascade_frontalface_default.xml" )  
    sum = 0

    while(True):
        cap = cv2.VideoCapture(0)
        # Capture frame-by-frame
        ret, frame = cap.read()
        # Our operations on the frame come here
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faceRects = classifier.detectMultiScale( gray, scaleFactor=1.2, minNeighbors=3, minSize=(32, 32)) 
        print("length = ", len(faceRects))
        flag = 0
        if len(faceRects):
            for faceRect in faceRects:                   #单独框出每一张人脸
                x, y, w, h = faceRect 
                sum += 1
                if sum == 10:
                    flag = 1
                    Output = frame[y:y+w, x:x+h]
                    cv2.imwrite(OUT_IMG, Output)
        # Display the resulting frame
        if flag == 1:
            break

    # When everything done, release the capture
    cap.release()
    cv2.destroyAllWindows()
    
def faceRecognition():
    qianqian_face_encoding = numpy.load("maqianqian.npy")
    hongrui_face_encoding = numpy.load("liuhongrui.npy")
    jingjie_face_encoding = numpy.load("yuanjingjie.npy")

    unknown_image = face_recognition.load_image_file(OUT_IMG)
    unknown_face_encoding = face_recognition.face_encodings(unknown_image)[0]
    known_faces = [
        qianqian_face_encoding,
        jingjie_face_encoding,
        hongrui_face_encoding
    ]
    known_person = [
        'qianqian',
        'jingjie',
        'hongrui',
    ]

    # results is an array of True/False telling if the unknown face matched anyone in the known_faces array
    results = face_recognition.compare_faces(known_faces, unknown_face_encoding, tolerance = 0.2)

    i = 0
    for each in results:
        if each == True:
            result = known_person[i]
        i += 1
        print(each,end='\n')
    if not True in results:
        result = None
    
    return True in results, result
