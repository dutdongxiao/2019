# -*- coding: utf-8 -*-
"""
Created on Sat Jul  6 23:50:40 2019

@author: 爱雪
"""

# -*-coding:utf-8-*-
import os
import serial
import time
import string
import sys
sys.path.append(r'F:/speech_recognition/code')
import photo
TXT_OUTPUT_FILENAME = "F:/speech_recognition/txt/name.txt"
def avoid(q_left,q_forward,q_end,ser):
    signal = 0
    while True:
        count = ser.inWaiting()
        if count != 0:
            recv = ser.read(count)
            print ("heard:",recv)
            if(recv=='$'):
                signal=0
            else:
                signal=signal+1
                if(signal==1):
                    q_forward.put()
                    print ('q_forward.push>>',recv)
                elif(signal==2):
                    q_left.put()
                    print ('q_left.push>>',recv)

        if not q_end.empty():
            data1=q_end.get()
            if data1==-100:
                q_end.put(-100)
                time.sleep(1)
                break

def read_path(stemp,q,q_forward=[],q_left=[],forward_sign=True,left_sign=False):            #记得改前面的函数使用的东西
   s_name=os.path.join("F:/speech_recognition/txt/",stemp)
   s_name+='.txt'
   f = open(s_name,"r")
   lines = f.readlines()
   print("connected")
   s = 0
   data=0
   ssign = False
   while True:
       if lines[s][0] == '$':
           break;
       data = ord(lines[s][0]) - 48
       data = str(data)
       
       if data=="200" :     #是否到了应该取快递的时候
           ssign = not ssign
           if ssign:
               auto_take(q,q_forward)
           continue
       ###########根据不同的sign判断是否要进行避障########
       q.put(data)
       start_time = time.time()
       s = s+1
       runtime = float(lines[s])
       while runtime>0:
           
      ###########避障代码###############################
           if forward_sign and not q_forward.empty():
               fdis=q_forward.get()
               if fdis < 30:
                   q.put(5)
                   end_time=time.time()
                   runtime=runtime-(end_time-start_time)
                   while True:
                       time.sleep(0.1)
                       if not q_forward.empty() and q_forward.get() >30:
                           q.put(data)
                           start_time=time.time()
                           break
                       
           if left_sign and not q_left.empty():
               ldis = q_left.get()
               if ldis < 30 :
                   end_time=time.time()
                   runtime=runtime-(end_time-start_time)
        ###########进入判断及取快递状态###########
                   q.put(3)   
                   time.sleep(左转时间)
                   photo.faceDetect()
                   img_sign,s_name = photo.faceRecognition()
                   if img_sign and stemp == s_name:
                       auto_take(q,q_forward)
                       q.put(1)
                       time.sleep(前进时间)
                       q.put(3)
                       time.sleep(左转时间)
                    elif :
                        q.put(1)
                        time.sleep(快递距离位置)
                        run_time-=快递距离
                        continue
        ###########取快递结束##############
                   q.put(data)
                   start_time=time.time()
           end_time=time.time()
           runtime=runtime-(end_time-start_time)
           start_time=time.time()
           time.sleep(0.1)    
       s = s+1
       
def learn_path(stemp,s_command):
    s_name=os.path.join("F:/speech_recognition/txt/",stemp)
    s_name+='.txt'
    f = open(s_name,"w+")
    sign = False
    ssign = False
    for i in range(len(s_command)):
        command=s_command.pop(0)
        if ssign:
            continue
        elif command == '$':
            f.write(command)
            sign == True
            break
        elif command == "200":   #是否记录当前操作，200代表正在取快递，此后的操作不需要记录
            ssign = not ssign
            continue
        command+='\n'
        print(command)
        f.write(command)
    f = open(TXT_OUTPUT_FILENAME,"a")
    f.write(stemp)
    return sign

def read_all_path(stemp,q,q_forward=[],q_left=[],forward_sign=True,left_sign=False):
    read_path("First_all",q,q_forward)
    read_path("Take_Delivery",q,q_forward,q_left,True,True)
    read_path("End_all",q,q_forward)
   
def auto_take(q,q_forward,command_list=[]):              #人工控制到达后自动取快递并回来的过程
    q.put(1)
    while True:
        if not q_forward.empty():
            dis = q_forward.get()
        if dis<Min_arrive_dis:
            q.put(5)
            break
    q.put(6)
    q.put(1)
    while True:
        if not q_forward.empty():
            dis = q_forward.get()
        if dis<Min_take_dis:
            q.put(5)
            break
    q.put(7)
    q.put(8)
    q.put(2)
    while True:
        if not q_forward.empty():
            dis = q_forward.get()
        if dis>Min_take_dis:
            q.put(5)
            break
    q.put(3)
    time.sleep(180度时间)
    q.put(5)
    command_list.append("200")
            
    
    
    
    
#s_command=["1","2","$"]
#learn_path("fq",s_command)
