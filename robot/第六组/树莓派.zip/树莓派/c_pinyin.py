# -*- coding: utf-8 -*-
"""
Created on Sat Jun 29 20:29:14 2019

@author: 爱雪
"""
#-*- coding: utf-8 -*-

from aip import AipSpeech
from aip import AipNlp
import sys
sys.path.append(r'F:/speech_recognition/code')
import record
import pypinyin
import play_music
import c_pinyin
import multiprocessing as mp
import Command_File
import photo
APP_ID = '16676639'
API_KEY = 'hWthcMgVuSFa58sMRkzHFvNP'
SECRET_KEY = 'XGzzTeA8zl7nBqRRdEzbi2UpR3DWz1ey'
client = AipNlp(APP_ID, API_KEY, SECRET_KEY)
TXT_OUTPUT_FILENAME = "F:/speech_recognition/txt/name.txt"
WAVE_OUTPUT_FILENAME = "F:/speech_recognition/music/test.wav"

def hp(word):
        s = ''
        for i in pypinyin.pinyin(word,style=pypinyin.NORMAL):
            s=s+ ''.join(i)
        return s
    
def search(key_word: str):
    with open(TXT_OUTPUT_FILENAME) as f:
        for index, line in enumerate(f.readlines()):
            if key_word in line:
                return True
 
    return False
def command_analyze(strings,q1):
    sign = False   #程序是否完成
    name_sign=False
    
    #词法分析部分
    text =strings
    print(text)
    result=client.lexer(text)
    tmp=result["items"] 
    print (tmp)    #tmp是词法分析结果
    
    name_sign=False
    name_pin=""
    name=""
    for i in tmp:            #检测是否含有名字
        if i.get("ne")=="PER":
            name_sign=True
            name=i.get("item")
            print(name_sign)
    while sign==False:       #如果有名字，先确认后判断是否含有这个名字，没有名字重新输入
        j=0
        if name_sign==False: #name_sign用于确认是否有名字及确定文件中是否已经包含至这个名字
            output='请告诉我名字'
            play_music.initialize(output)
            play_music.play()
            
            while name_sign==False:   #等待输入到名字
                record.rec(WAVE_OUTPUT_FILENAME)
                result=record.m_to_word()
                if result["err_no"]==0:
                    name=result["result"][0]
                    name_pin=c_pinyin.hp(name)  #将名字转化成拼音
                    result=client.lexer(name)  #调用词法分析识别是否含有名字
                    name_tmp=result.get("items")
                    for i in name_tmp:
                        if i.get("ne")=="PER":
                            name_sign=True
                            name=i.get("item")
                            name_sign=True
                            break

        output='请确认是'+name+'吗'
        play_music.initialize(output)
        play_music.play()
        while True:  #用于确认名字是否正确
            record.rec(WAVE_OUTPUT_FILENAME)
            result=record.m_to_word()
            if result["err_no"]==0:
                tmp=result["result"][0]
                tmp_pin=c_pinyin.hp(tmp)
                if tmp_pin.find("bu")!=-1 or tmp_pin.find("fou")!=-1:
                    name_sign=False
                    break
                elif tmp_pin.find("shide")!=-1 or tmp_pin.find("queding")!=-1 or tmp_pin.find("queren")!=-1:
                    name_sign=True
                    break
            
        if name_sign and search(name_pin):
            q1.put(name_pin)
            sign=True
            return name
        else:  
            output='我的数据库中不存在这个人，请再次告诉我'
            play_music.initialize(output)
            play_music.play()
            continue

def command_learn():
    output = "正在进行图像识别"
    play_music.initialize(output)
    play_music.play()
    photo.faceDetect()
    img_sign,s_name = photo.faceRecognition()
    output = "图像识别结束"
    play_music.initialize(output)
    play_music.play()    
    s_name = hp(s_name)
    if img_sign==False:
        s_name = "moshengren"
    return s_name
   
def command(ystrings,q):
    strings=hp(ystrings)
    if strings.find("zuo")!=-1:
        strings="正在左转"
        return strings,3
    elif strings.find("you")!=-1:
        strings="正在右转"
        return strings,4
    elif strings.find("qian")!=-1 and strings.find("qianqian")==-1:
        strings="正在前进"
        return strings,1
    elif strings.find("hou")!=-1:
        strings="正在后退"
        return strings,2
    elif strings.find("ting")!=-1:
        strings="已停止"
        return strings,0
    elif strings.find("kuaidi")!=-1 or strings.find("qukuai")!=-1:
        strings=command_analyze(ystrings,q)
        return strings,50
    elif strings.find("xuexi")!=-1:
        strings=command_learn()
        return strings,60
    else:
        strings="我没有听清"
        return strings,99
