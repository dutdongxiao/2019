# -*- coding: utf-8 -*-
"""
Created on Sat Jun 29 23:40:54 2019

@author: 爱雪
"""
import time
import wave
import pyaudio
from aip import AipSpeech

CHUNK = 1024
FORMAT = pyaudio.paInt16
CHANNELS =1
RATE = 16000
RECORD_SECONDS =2

APP_ID = '16654766'
API_KEY = 'HbAl3FszqhtR1GVKjdqt7Mr5'
SECRET_KEY = 'X9dqIDM3O4lDWrSrWmkIaAtSBAupoNoM'
client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)
WAVE_OUTPUT_FILENAME = "F:/speech_recognition/music/test.wav"
mp3_output_filename = "F:/speech_recognition/music/test.mp3"

def get_file_content(filePath):
    with open(filePath, 'rb') as fp:
        return fp.read()  
    
def m_to_word():
    result=client.asr(get_file_content(WAVE_OUTPUT_FILENAME),'wav', 16000, {
    'dev_pid': 1536,}) 
    return result
    
def rec(file_name):
    p = pyaudio.PyAudio()

    print("1")
    
    stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK)
    
    frames = []

    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
        data = stream.read(CHUNK)
        frames.append(data)

    stream.stop_stream()
    stream.close()
    p.terminate()

    wf = wave.open(file_name, 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    wf.writeframes(b''.join(frames))
    wf.close()
    print("2")
    
