# -*- coding: utf-8 -*-
"""
Created on Sat Jun 29 23:36:23 2019

@author: 爱雪
"""
import pyaudio
import wave
from pydub import AudioSegment
from aip import AipSpeech

APP_ID = '16654766'
API_KEY = 'HbAl3FszqhtR1GVKjdqt7Mr5'
SECRET_KEY = 'X9dqIDM3O4lDWrSrWmkIaAtSBAupoNoM'
client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)

WAVE_OUTPUT_FILENAME = "F:/speech_recognition/music/test.wav"
mp3_output_filename = "F:/speech_recognition/music/test.mp3"
             
def initialize(tmp):
    play_result=client.synthesis(tmp, 'zh', 1, {
                'vol': 5,'per':4})  #语音合成
    if not isinstance(play_result, dict):
        with open(mp3_output_filename, 'wb') as f:
            f.write(play_result)
    sound = AudioSegment.from_mp3(mp3_output_filename)
    sound.export(WAVE_OUTPUT_FILENAME,format ='wav')

def play():
    
    chunk=1                                       # 指定WAV文件的大小
    wf=wave.open(WAVE_OUTPUT_FILENAME,'rb')              # 打开WAV文件
    p=pyaudio.PyAudio()                                   # 初始化PyAudio模块
    
    # 打开一个数据流对象，解码而成的帧将直接通过它播放出来，我们就能听到声音啦
    stream=p.open(format=p.get_format_from_width(wf.getsampwidth()), channels=wf.getnchannels(), rate=wf.getframerate(), output=True)
 
    data = wf.readframes(chunk)      # 读取第一帧数据
    print(data)                      # 以文本形式打印出第一帧数据，实际上是转义之后的十六进制字符串

    # 播放音频，并使用while循环继续读取并播放后面的帧数
    # 结束的标志为wave模块读到了空的帧
    while data != b'':   
        stream.write(data)                # 将帧写入数据流对象中，以此播放之
        data = wf.readframes(chunk)            # 继续读取后面的帧
        
    stream.stop_stream()            # 停止数据流
    stream.close()                        # 关闭数据流
    p.terminate()                          # 关闭 PyAudio
    print('play函数结束！')

    


    
    
    
    
    
    
    
    