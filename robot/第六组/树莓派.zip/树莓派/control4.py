#coding=utf-8
import serial
import time
import string
import socket
import os
import multiprocessing as mp
socket_name=6969

def main(q,q_close):
    
    server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)             
    server.bind(('192.168.137.1',socket_name))   
    server.listen(5)                   
    print(u"waiting for ndrd connection...")
    t=0
    while t==0:
        conn,addr = server.accept()#端口接入安卓
        print(conn,addr)
        print("connected to ndrd!")
        t=1
    

    while True:
        if not q_close.empty():
            data=q_close.get()
            if data==-100:
                q_close.put(-100)
                server.close()
                os.system('kill socket_name')
                break
        data = conn.recv(1024)#从安卓接收到的命令 
        data = str(data,encoding='utf8')
        print(u"from ndrd：")
        print(data)
        if not data:
            print("ndrd connection terminated!")
            break
        q.put(data)
        time.sleep(0.01)
        