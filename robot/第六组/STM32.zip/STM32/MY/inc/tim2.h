#ifndef __TIM2_H
#define __TIM2_H

#include "stm32f10x.h"	 
  /**************************************************************************
���ߣ�ƽ��С��֮��
�ҵ��Ա�С�꣺http://shop114407458.taobao.com/
**************************************************************************/
//void TIM2_Init(void);
//void TIM2_IRQHandler(void);
void HS_GPIO_Config(void);
float Hcsr04GetLength(void );
void TIM2_Init(void);
void hcsr04_NVIC(void);
void TIM2_IRQHandler(void);
u32 GetEchoTimer(void);

#endif
