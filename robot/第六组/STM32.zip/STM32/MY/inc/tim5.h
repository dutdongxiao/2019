#ifndef __TIM5_H
#define __TIM5_H

#include "stm32f10x.h"	 
  /**************************************************************************
���ߣ�ƽ��С��֮��
�ҵ��Ա�С�꣺http://shop114407458.taobao.com/
**************************************************************************/

void HS_GPIO_Config2(void);
float Hcsr04GetLength2(void );
void TIM5_Init(void);
void TIM5_IRQHandler(void);
u32 GetEchoTimer2(void);

#endif
