#ifndef __HCRR04_H
#define __HCSR04_H

#include "stm32f10x.h"	 

void HS_GPIO_Config(void);
float Hcsr04GetLength(void );

#endif

