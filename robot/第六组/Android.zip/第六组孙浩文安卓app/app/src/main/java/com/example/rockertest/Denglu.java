package com.example.rockertest;


import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Denglu extends AppCompatActivity {

    private Button login;
    private static Set<String> usernames = new HashSet<>();
    private static String password = "123";

    static {
        Collections.addAll(usernames, "孙浩文", "冯琦", "刘洪瑞","袁靖杰","马倩倩","a");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);
        login = (Button) findViewById(R.id.login_button);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView nameView = findViewById(R.id.name);
                TextView passwordView = findViewById(R.id.password);
                if (usernames.contains(nameView.getText().toString()) && password.equals(passwordView.getText().toString())) {
                    Toast.makeText(Denglu.this,"登陆成功",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Denglu.this, MainActivity.class);
                    startActivity(intent);

                    } else {
                    Toast.makeText(Denglu.this,"登陆失败",Toast.LENGTH_SHORT).show();
                    }
            }
        });
    }
}
