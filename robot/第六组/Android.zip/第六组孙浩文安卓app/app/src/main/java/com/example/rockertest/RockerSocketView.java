package com.example.rockertest;
import android.content.Context;
import android.os.AsyncTask;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;



public class RockerSocketView extends RockerView{
    //树莓派ip地址
    private String carIp;
    //端口
    private int carPort;
    //是否连接标志
    private boolean isConnect = false;

    private Context context;

    Socket socket = null;
    BufferedReader reader = null;
    public static BufferedWriter writer = null;

    private int rockerEvent = 0;
    private int oldrockerEvent = -1;

    //定义摇杆事件状态
    public static final int Movestop = 5;
    public static final int Moveforward = 1;
    public static final int Movebackward = 2;
    public static final int Turnleft = 3;
    public static final int Turnright = 4;
  //  TextView lj=findViewById(R.id.luj);
    // String aaa=lj.getText().toString();
    //String bbb="abc";
    //重新定义了构造方法，目的是为了得到使用该控件的Activity的context
    public RockerSocketView(Context context) {
        this(context, null);
    }

    public RockerSocketView(Context context, AttributeSet attrs) {
        super(context, attrs, 0);
        this.context = context;
    }


    //初始化函数，由使用该控件的Activity调用
    public void init(String carIp,int carPort){
        this.carIp = carIp;
        this.carPort = carPort;
        connectAsyncTask();
        //添加摇杆事件监听

        this.setListener(new RockerView.RockerListener() {
            @Override
            public void callback(int eventType, int currentAngle, float currentDistance) {
                Log.e("Rock", "Rock");
                switch (eventType) {
                    case RockerView.EVENT_ACTION:
                        // 触摸事件回调
                        Log.e("EVENT_ACTION-------->", "angle=" + currentAngle + " - distance" + currentDistance);
                        rockerEvent = judgeEvent(currentAngle);
                        send();
                        break;
                    case RockerView.EVENT_CLOCK:
                        // 定时回调
                        Log.e("EVENT_CLOCK", "angle=" + currentAngle + " - distance" + currentDistance);
                        rockerEvent = judgeEvent(currentAngle);
                        send();
                        break;
                }
            }
        });

    }

    //根据角度判断摇杆方向
    public int judgeEvent(int currentAngle){
        if (currentAngle == -1){
            return Movestop;
        }else if (currentAngle > 45 && currentAngle <= 135){
            return Moveforward;
        }else if (currentAngle > 135 && currentAngle <= 225){
            return Turnleft;
        }else if (currentAngle > 225 && currentAngle <= 315){
            return Movebackward;
        }else{
            return Turnright;
        }
    }

    public void Destroy(){
        isConnect = false;
    }

    //使用异步任务建立socket连接
    public void connectAsyncTask(){
        AsyncTask<Void,String,Void> connect =new AsyncTask<Void, String, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                try {
                    socket = new Socket(carIp,carPort);
                    writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                    reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    publishProgress("连接成功\n");
                    isConnect = true;

                }catch (UnsupportedEncodingException e) {
                    Toast.makeText(context,"无法建立连接",Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
                catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(context,"无法建立连接",Toast.LENGTH_SHORT).show();
                }
                String Line;
                try {
                    while ((Line = reader.readLine()) != null){
                        publishProgress(Line);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

                return null;
            }

            protected void onProgressUpdate(String...values){
                if(values[0].equals("连接成功\n")){
                    Toast.makeText(context,"连接成功",Toast.LENGTH_SHORT).show();
                }
                else{
                    System.out.println(values[0]);
                }

                super.onProgressUpdate(values[0]);
            }
        };
        connect.execute();

    }

    private Runnable sendTask = new Runnable() {
        @Override
        public void run() {
            if(isConnect){
                if(rockerEvent != oldrockerEvent){
                    oldrockerEvent = rockerEvent;
                    try {
                        //将要发送的int数据转换成String再发送
                        writer.write(String.valueOf(rockerEvent));
                        writer.flush();
                        Log.e("EVENT_ACTION-------->", "rockerEvent=" + rockerEvent);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    };

    private Runnable sendOpenTask = new Runnable() {
        @Override
        public void run() {
            try {
                writer.write(String.valueOf(6));
                writer.flush();
            } catch (Exception e) {

            }
        }
    };


    private Runnable sendCloseTask = new Runnable() {
        @Override
        public void run() {
            try {
                writer.write(String.valueOf(7));
                writer.flush();
            } catch (Exception e) {

            }
        }
    };
    private Runnable sendTopTask = new Runnable() {
        @Override
        public void run() {
            try {
                writer.write(String.valueOf(8));
                writer.flush();
            } catch (Exception e) {

            }
        }
    };
    private Runnable sendBelowTask = new Runnable() {
        @Override
        public void run() {
            try {
                writer.write(String.valueOf(9));
                writer.flush();
            } catch (Exception e) {

            }
        }
    };
    private Runnable autoTask = new Runnable() {
        @Override
        public void run() {
            try {
                    writer.write(String.valueOf(10));
                    writer.flush();
            }catch (Exception e){

            }
        }
    };
    private Runnable quTask = new Runnable() {
        @Override
        public void run() {
            try {
                writer.write(String.valueOf(200));
                writer.flush();
            }catch (Exception e){

            }
        }
    };
    private Runnable ljTask = new Runnable() {

        @Override
        public void run() {
            try {

               // TextView lj=findViewById(R.id.luj);
                Log.e("before lj: ", MainActivity.lj.getText().toString());
                writer.write(MainActivity.lj.getText().toString());
                writer.flush();
                Log.e("ljTask: ", MainActivity.lj.getText().toString());
            }catch (Exception e){
               Log.e("error: ", e.getMessage());
            }
        }
    };

    //不使用线程，事件变化时再发送状态
    public void send(){
        //先判断是否成功建立socket连接再向树莓派发送数据，避免出现错误
        MainActivity.threadPool.execute(sendTask);
    }

    public void sendOpen() {
        MainActivity.threadPool.execute(sendOpenTask);
    }

    public void sendClose() {
        MainActivity.threadPool.execute(sendCloseTask);
    }

    public void sendTop() {
        MainActivity.threadPool.execute(sendTopTask);
    }
    public  void auto(){
        MainActivity.threadPool.execute(autoTask);
    }

    public  void qu(){
        MainActivity.threadPool.execute(quTask);
    }
    public  void lujing(){
        MainActivity.threadPool.execute(ljTask);
    }
    public void sendBelow(){
        MainActivity.threadPool.execute(sendBelowTask);
        }
}
