package com.example.rockertest;


import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class MainActivity extends AppCompatActivity {
    private RockerSocketView rockersocket;
    private EditText carip, carport;
    public static ExecutorService threadPool = Executors.newSingleThreadExecutor();
    private WebView mWvmain;

    public static TextView lj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lj = findViewById(R.id.luj);

        mWvmain = findViewById(R.id.wv);
        mWvmain.getSettings().setJavaScriptEnabled(true);
        mWvmain.loadUrl("file:///android_asset/text.html");

        //mWvmain.loadUrl("https://m.baidu.com");


        rockersocket = (RockerSocketView) findViewById(R.id.rockersocket);
        carip = (EditText) findViewById(R.id.carip);
        carport = (EditText) findViewById(R.id.carport);
        findViewById(R.id.btn_car_connect).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rockersocket.init(carip.getText().toString(), Integer.parseInt(carport.getText().toString()));
            }
        });
        Button openBtn = findViewById(R.id.button);
        openBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                rockersocket.sendOpen();
            }
        });

        Button closeBtn = findViewById(R.id.button2);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rockersocket.sendClose();
            }
        });
        Button topBtn = findViewById(R.id.button3);
        topBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rockersocket.sendTop();
            }
        });
        Button belowBtn = findViewById(R.id.button4);
        belowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rockersocket.sendBelow();
            }
        });
        Button autoBtn = findViewById(R.id.button5);
        autoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rockersocket.auto();
            }
        });
        Button quBtn = findViewById(R.id.button6);
        quBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rockersocket.qu();
            }
        });
        Button ljBtn = findViewById(R.id.button7);
        ljBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rockersocket.lujing();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        rockersocket.Destroy();
        rockersocket = null;
        threadPool.shutdown();
    }
}
