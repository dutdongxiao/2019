#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
    * @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
    * @file        qr code
    * @version      V1.0
    * @details
    * @par History
    @author: longfuSun
"""

from imutils.video import VideoStream
from pyzbar import pyzbar
import argparse
import datetime
import imutils
import time
import cv2
from aip import AipSpeech
import pygame
#from speechconpound import fun


APP_ID='16677991'
API_KEY='WXOB6KKdfL77ES5ff0lAKrsb'
SECRET_KEY='AVIfqphxjVpksxmW3DyXPx1bGmdf9dlu'
    
aipSpeech=AipSpeech(APP_ID,API_KEY,SECRET_KEY)

def motion_speech(content):
    text=content
    result = aipSpeech.synthesis(text = text, 
                             options={'spd':3,'vol':9,'per':4,})
    if not isinstance(result,dict):
        with open('qrcode.mp3','wb') as f:
            f.write(result)  
    else:print(result)
    #我们利用树莓派自带的pygame
    pygame.mixer.init()
    pygame.mixer.music.load('/root/face/test2/qrcode.mp3')
    pygame.mixer.music.play()

def fun2():
    ap=argparse.ArgumentParser()
    #提供一个csv文件，这样，在最后不仅可以将二维码内容显示在屏幕上，还有专门的文件进行保存
    ap.add_argument("-o","--output",type=str,default="content.csv",
                    help="path to output csv file containing barcode")
    args=vars(ap.parse_args())

    print('starting video stream....')
    #这是使用web摄像头的写法
    vs=VideoStream(src=0).start()
    #使用树莓派自带摄像头的写法是：
    #vs=VideoStream(usePiCamera=True).start()
    time.sleep(2.0)

    #把内容写入csv
    csv=open(args["output"],"w")
    found=set()

    #避免拥塞，多次处理
    sendDate=0
    while True:
        frame=vs.read()
        frame=imutils.resize(frame,width=400)
        barcodes=pyzbar.decode(frame)
        for barcode in barcodes:
            (x,y,w,h)=barcode.rect

            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,0,255),2)
            #对二维码内呢绒进行解码，输入时间，内容和类型
            barcodeData=barcode.data.decode("utf-8")
            barcodeType=barcode.type
            text="{}({})".format(barcodeData,barcodeType)

            cv2.putText(frame,text,(x,y-10),cv2.FONT_HERSHEY_SIMPLEX,0.5,
                        (0,0,255),2)
            newData=barcodeData
            currentDate=time.time()
            if (currentDate-sendDate>3):
                print('1')
                motion_speech(newData)
                sendDate=time.time()

            if barcodeData not in found:
                csv.write("{},{}\n".format(datetime.datetime.now(),barcodeData))
                csv.flush()
                found.add(barcodeData)
        cv2.imshow("found_code",frame)
        key=cv2.waitKey(1)&0xFF
        if key==ord("q"):
            break


    csv.close()
    cv2.destroyAllWindows()
    vs.stop()
        
        
        
        
        
        
        
