#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
    Created on Tue Nov  6 01:18:45 2018
    * @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
    * @file        speech conpound
    * @version      V1.0
    * @details
    * @par History
    
    @author: longfuSun
"""
from aip import AipSpeech
import pygame
import time
#from time import time
#请输入自己的id和密钥

def fun(commend):
    APP_ID='16677832'
    API_KEY='ExsWDoFouwCmuvFkOAcEm2zE'
    SECRET_KEY='NqEBiB6FGNToNuuQKyTnK936EUDUFb41'
    print(commend)
    aipSpeech=AipSpeech(APP_ID,API_KEY,SECRET_KEY)
    #在可选的参数中对语速，音量，人声进行调整，个人感觉‘per’为0的女生最自然，最清晰
    t=time.time()
    result = aipSpeech.synthesis(text =commend, 
                                 options={'spd':3,'vol':9,'per':4,})
    #将合成的语音写如文件  '亚博智能调用语音接口进行语音合成'
    if not isinstance(result,dict):
        with open('audio.mp3','wb') as f:
            f.write(result)
            
    else:print(result)
    #我们利用树莓派自带的pygame
    pygame.mixer.init()
    pygame.mixer.music.load('/root/face/test2/audio.mp3')
    pygame.mixer.music.play()
    #s=pygame.mixer.Sound('/root/face/test2/audio.mp3')
    #s.play()
    t2=time.time()
    print(t2-t)
    time.sleep(5)
    pygame.quit()
    
    
'''
APP_ID='16677991'
API_KEY='WXOB6KKdfL77ES5ff0lAKrsb'
SECRET_KEY='AVIfqphxjVpksxmW3DyXPx1bGmdf9dlu'
    
aipSpeech=AipSpeech(APP_ID,API_KEY,SECRET_KEY)
    #在可选的参数中对语速，音量，人声进行调整，个人感觉‘per’为0的女生最自然，最清晰
t=time()
result = aipSpeech.synthesis(text =APP_ID, 
                                 options={'spd':4,'vol':9,'per':4,})
    #将合成的语音写如文件  '亚博智能调用语音接口进行语音合成'
if not isinstance(result,dict):
    
    with open('audio.mp3','wb') as f:
        f.write(result)
            
else:print(result)
    #我们利用树莓派自带的pygame
pygame.mixer.init()
pygame.mixer.music.load('/root/face/speech/audio.mp3')
pygame.mixer.music.play()
t2=time()
print(t2-t)
'''
