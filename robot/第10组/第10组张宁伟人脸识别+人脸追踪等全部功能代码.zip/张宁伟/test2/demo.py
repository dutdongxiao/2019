from speechconpound import fun
fun('123456')