import serial
from time import sleep
ser = serial.Serial("/dev/ttyAMA0", 115200)
def recv(serial):

    while True:
        data =serial.read(30)
        if data == '':
            continue
        else:
            break
        sleep(0.02)
    return data

def sendCommend(commend):
    ser.write(commend)

