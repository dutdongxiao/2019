#!/usr/bin/env python2
# -*- coding: utf-8 -*-
from __future__ import division
import cv2
#import speechconpound
import chuan
import time
from aip import AipSpeech
import pygame

APP_ID='16677991'
API_KEY='WXOB6KKdfL77ES5ff0lAKrsb'
SECRET_KEY='AVIfqphxjVpksxmW3DyXPx1bGmdf9dlu'
    
aipSpeech=AipSpeech(APP_ID,API_KEY,SECRET_KEY)

def motion_speech(content):
    text=content
    result = aipSpeech.synthesis(text = text, 
                             options={'spd':3,'vol':9,'per':4,})
    if not isinstance(result,dict):
        with open('face.mp3','wb') as f:
            f.write(result)  
    else:print(result)
    #我们利用树莓派自带的pygame
    pygame.mixer.init()
    pygame.mixer.music.load('/root/face/test2/face.mp3')
    pygame.mixer.music.play()

def fun1():
    cap = cv2.VideoCapture(0)
    cap.set(3, 320)
    cap.set(4, 240)
    # face.xml的位置要和本程序位于同一文件夹下
    face_cascade = cv2.CascadeClassifier('cascade.xml')
    # 避免拥塞，多次处理
    sendDate = 0
    sendDate2 = 0
    flag = 0
    t_start = time.time()
    fps = 0
    while True:
        ret, frame = cap.read()
        frame=cv2.flip(frame,1)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # 要先将每一帧先转换成灰度图，在灰度图中进行查找
        faces = face_cascade.detectMultiScale(gray)
        if len(faces) > 0:
            if (flag == 0):
                chuan.sendCommend("a$")
                flag = 1
            text = '这里有人需要救援'
            currentDate = time.time()
            if (currentDate - sendDate > 7):
                print('1')
                motion_speech(text)
                sendDate = time.time()
                # print('face found!')
            (x, y, w, h) = faces[0]
            cv2.rectangle(frame, (x, y), (x + h, y + w), (0, 255, 0), 2)
            '''
            result = (x, y, w, h)
            x = result[0] + w / 2
            y = result[1] + h / 2
            thisError_x = x - 160
            thisError_y = y - 120
            currentDate2 = time.time()
            if (currentDate2 - sendDate2 > 1.2):
                if thisError_x < -70:
                    chuan.sendCommend("7$")
                elif thisError_x > 70:
                    chuan.sendCommend("8$")
                if thisError_y < -50:
                    chuan.sendCommend("5$")
                elif thisError_y > 50:
                    chuan.sendCommend("6$")
                sendDate2=time.time()
                #if thisError_x < -150 and thisError_x > 150 and thisError_y < -90 and thisError_y > 90:
                 #   chuan.sendCommend("9$")
            '''
        fps = fps + 1
        sfps = fps / (time.time() - t_start)
        cv2.putText(frame, "FPS : " + str(int(sfps)), (10, 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
        cv2.imshow("capture", frame)

        if cv2.waitKey(1) > 0:
            break

    cap.release()
    cv2.destroyAllWindows()
