#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
    Created on Tue Nov  6 01:18:45 2018
    * @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
    * @file         face_tracking
    * @version      V1.0
    * @details
    * @par History
    
    @author: longfuSun
"""
from __future__ import division
import cv2
from aip import AipFace
import urllib
import base64
import time  
from PIL import Image,ImageDraw,ImageFont
import numpy as np
import sys
reload(sys)
sys.setdefaultencoding('utf8')
#请输入自己的id和密钥
APP_ID='16703330'
API_KEY='paIZ0XiyWldehPvRmAAeUes7'
SECRET_KEY='BWlZKS5YjdGqUFFOrxGBRt8mGMbAD0hn'

aipFace=AipFace(APP_ID,API_KEY,SECRET_KEY)
imageType = 'BASE64'
groupIdList = '001'
sendDate=0
#这是不带舵机的版本

cap = cv2.VideoCapture(0)
cap.set(3, 320)
cap.set(4, 320)
#face.xml的位置要和本程序位于同一文件夹下
face_cascade = cv2.CascadeClassifier( '123.xml' )
#显示中文
def change_cv2_draw(image,strs,local,sizes,colour):
    cv2img = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    pilimg = Image.fromarray(cv2img)
    draw = ImageDraw.Draw(pilimg)  # 图片上打印
    font = ImageFont.truetype("simhei.ttf",sizes, encoding="utf-8")
    draw.text(local, strs, colour, font=font)
    image = cv2.cvtColor(np.array(pilimg), cv2.COLOR_RGB2BGR)
    return image

def baiduyun():
    f = open('face1.jpg', 'rb')
    img = base64.b64encode(f.read())
    result1 = aipFace.search(str(img), imageType, groupIdList)
    if result1['error_msg'] == 'SUCCESS':  # if success
        name = result1['result']['user_list'][0]['user_id']
        score = result1['result']['user_list'][0]['score']
        print(score)
        if score > 80:  # simility>80
            if name == '001':
                name = '张宁伟'
                print("欢迎%s !" % name)
            else:
                print("对不起，我不认识你！")
                name = 'Unknow'
            return name
        else:
            print("相似度过低")
            return "错误"
    if result1['error_msg'] == 'pic not has face':
        print('检测不到人脸')
        time.sleep(2)
        return "错误"
#死循环，同学们可以积累一下，这里的死循环的写法还有哪些其他的
while True:
    ret,frame = cap.read()
    gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    #要先将每一帧先转换成灰度图，在灰度图中进行查找
    faces = face_cascade.detectMultiScale( gray )
    max_face = 0
    value_x = 0
    if len(faces)>0:
        #print('face found!')
        for (x,y,w,h) in faces:
            #参数分别是“目标帧”，“矩形”，“矩形大小”，“线条颜色”，“宽度”
            cv2.rectangle(frame,(x,y),(x+h,y+w),(0,255,0),2)
            #max_face=w*h
            result = (x,y,w,h)
            x=result[0]
            y = result[1]
            currentDate = time.time()
            if currentDate - sendDate > 600:
                # 如果在10分钟内没有发送过图片，
                # 将当前帧写入独立png中
                cv2.imwrite("face1.jpg", frame)
                name = baiduyun()
                print(name)
                if not isinstance(name,unicode):
                    name=name.decode('utf-8')
                frame=change_cv2_draw(frame,name,(20,20),20,(255,0,0))
                cv2.imwrite("face2.jpg", frame)
                sendDate = time.time()
    cv2.imshow("capture", frame)
    if cv2.waitKey(1)==119:
        break
    
cap.release()
cv2.destroyAllWindows()
