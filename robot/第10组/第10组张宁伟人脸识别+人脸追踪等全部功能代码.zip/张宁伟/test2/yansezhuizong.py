#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
    * @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
    * @file        sevo_ball_nosocket
    * @version      V1.0
    * @details
    * @par History
    @author: longfuSun
"""
from __future__ import division
import cv2


import time  
import numpy as np
import threading
import chuan

def fun5():
    #初始化摄像头并设置阙值
    #如果觉得卡顿严重，请调整“1”处和“2”处 两处代码
    cap = cv2.VideoCapture(0)
    #“1”处，摄像头的分辨率，中心点为（320，240）
    cap.set(3, 320)
    cap.set(4, 240)
    yellow_lower=np.array([26,43,46])
    yellow_upper=np.array([34,255,255])
    #每个自由度需要4个变量
    sendDate = 0
    
    while True:    
        ret,frame = cap.read()
        #高斯模糊
        frame=cv2.GaussianBlur(frame,(5,5),0)
        frame = cv2.flip(frame, 1)
        hsv= cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        #掩膜和形态学操作找到小球轮廓
        mask=cv2.inRange(hsv,yellow_lower,yellow_upper)
        mask=cv2.erode(mask,None,iterations=2)
        mask=cv2.dilate(mask,None,iterations=2)
        mask=cv2.GaussianBlur(mask,(3,3),0)
        res=cv2.bitwise_and(frame,frame,mask=mask)
        cnts=cv2.findContours(mask.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[-2]
        #当找到小球后
        if len(cnts)>0:
            #print('face found!')
            cnt=max(cnts,key=cv2.contourArea)
            (x,y),radius=cv2.minEnclosingCircle(cnt)
            cv2.circle(frame,(int(x),int(y)),int(radius),(255,0,255),2)
            #“2”处 误差值
            thisError_x=x-160
            thisError_y=y-120
            currentDate = time.time()
            if (currentDate - sendDate > 0.3):
                if thisError_x < -100:
                    chuan.sendCommend("7$")
                elif thisError_x > 100:
                    chuan.sendCommend("8$")
                if thisError_y < -80:
                    chuan.sendCommend("5$")
                elif thisError_y > 80:
                    chuan.sendCommend("6$")
                if radius > 80:
                    chuan.sendCommend("2$")
                if radius < 20:
                    chuan.sendCommend("1$")
                if radius >30 and radius <50:
                    chuan.sendCommend("0$")
                sendDate = time.time()
        cv2.imshow("capture", frame)
        if cv2.waitKey(1)>0:
            break
        
    cap.release()
    cv2.destroyAllWindows()
