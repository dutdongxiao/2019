#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
    * @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
    * @file         直方图(2)
    * @version      V1.0
    * @details
    * @par History
    
    @author: longfuSun
"""

import cv2
import numpy as np
from matplotlib import pyplot as plt
#import speechconpound
import time
from aip import AipSpeech
import pygame

APP_ID='16677991'
API_KEY='WXOB6KKdfL77ES5ff0lAKrsb'
SECRET_KEY='AVIfqphxjVpksxmW3DyXPx1bGmdf9dlu'
    
aipSpeech=AipSpeech(APP_ID,API_KEY,SECRET_KEY)

def motion_speech(content):
    text=content
    result = aipSpeech.synthesis(text = text, 
                             options={'spd':3,'vol':9,'per':4,})
    if not isinstance(result,dict):
        with open('color.mp3','wb') as f:
            f.write(result)  
    else:print(result)
    #我们利用树莓派自带的pygame
    pygame.mixer.init()
    pygame.mixer.music.load('/root/face/test2/color.mp3')
    pygame.mixer.music.play()

def color_hist(img):
    mask = np.zeros(img.shape[:2], dtype=np.uint8)
    mask[70:170, 100:220] = 255

    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    hist_mask = cv2.calcHist([hsv], [0], mask, [180], [0, 180])
    object_H = np.where(hist_mask == np.max(hist_mask))
    print(object_H[0])
    return object_H[0]
    plt.plot(hist_mask)
    plt.xlim([0, 180])
    plt.imshow(hist_mask, interplation='nearest')
    plt.show()


def color_distinguish(object_H):
    try:
        if object_H > 26 and object_H < 34:
            color = 'yellow'
        elif object_H > 156 and object_H < 180:
            color = 'red'
        elif object_H > 0 and object_H < 10:
            color = 'red'
        elif object_H > 100 and object_H < 124:
            color = 'blue'
        elif object_H > 35 and object_H < 50:
            color = 'green'
        elif object_H > 78 and object_H < 99:
            color = 'cyan-blue'
        elif object_H > 11 and object_H < 25:
            color = 'orange'
        else:
            color = 'None'
        print(color)
        return color
    except:
        pass

def fun4():
    cap = cv2.VideoCapture(0)
    #“1”处，摄像头的分辨率，中心点为（320，240）
    cap.set(3, 320)
    cap.set(4, 240)
    sendDate = 0
    while True:
        ret, frame = cap.read()
        # 高斯模糊
        frame = cv2.GaussianBlur(frame, (5, 5), 0)
        frame = cv2.flip(frame, 1)
        object_H=color_hist(frame)
        Color=color_distinguish(object_H)
        currentDate = time.time()
        if (currentDate - sendDate > 5):
            print('1')
            if Color=='yellow': motion_speech('这是黄色')
            elif Color == 'red': motion_speech('这是红色')
            elif Color == 'blue': motion_speech('这是蓝色')
            elif Color == 'green': motion_speech('这是绿色')
            elif Color == 'cyan-blue': motion_speech('这是青蓝色')
            elif Color == 'orange': motion_speech('这是橘黄色')
            sendDate = time.time()
        cv2.imshow('image',frame)
        if cv2.waitKey(1) >0:
            break
