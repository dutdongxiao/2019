#coding=utf-8
import socket
from enum import IntEnum
#from MotorModule.Motor import Motor
import traceback
import threading
import time
import chuan

from face_tracking.face_tracking import *
#from speech.speechconpound import fun2



def getLocalIp():
    '''Get the local ip'''
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()
    return ip

def cameraAction(command):
    if command == 'CamUp':
        print("CamUp")
        chuan.sendCommend("5$")
    elif command == 'CamDown':
        print("CamDown")
        chuan.sendCommend("6$")
    elif command == 'CamLeft':
        print("CamLeft")
        chuan.sendCommend("8$")
    elif command == 'CamRight':
        print("CamRight")
        chuan.sendCommend("7$")
    elif command == 'CamReset':
        print("CamReset")
        chuan.sendCommend("9$")



def motorAction(command):
    '''Set the action of motor according to the command'''
    if command == 'DirForward':
        print("DirForward")
        chuan.sendCommend("1$")
    elif command == 'DirBack':
        print("DirBack")
        chuan.sendCommend("2$")
    elif command == 'DirLeft':
        print("DirLeft")
        chuan.sendCommend("3$")
    elif command == 'DirRight':
        print("DirRight")
        chuan.sendCommend("4$")
    elif command == 'DirStop':
        print("DirStop")
        chuan.sendCommend("0$")
    elif command == 'text1':
        print("text1")
        fun()


def setCameraAction(command):
    if command == 'CamUp' or command == 'CamDown' or command == 'CamLeft' or command == 'CamRight' or command=='CamReset':
        return command
    else:
        return 'CamStop'




def main():
    '''The main thread, control the motor'''
    host = getLocalIp()
    print('localhost ip :' + host)
    port = 5050

    # Init the tcp socket
    tcpServer = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcpServer.bind((host, port))
    tcpServer.setblocking(0)  # Set unblock mode
    tcpServer.listen(5)


    while True:
        try:


            time.sleep(0.001)

            (client, addr) = tcpServer.accept()
            print('accept the client!')
            client.setblocking(1)
            while True:

                #print("data begin receive")
                #time.sleep(1)
                data = client.recv(1024)
                #print("data successful")

                #data = bytes.decode(data).encode(encoding='UTF-8')
                data = data.decode('UTF-8','strict')
                #print(data)
                if (len(data) == 0):
                    print('client is closed')

                    break
                if(data=='1'):
                    fun()
                    continue
                if(data[-1]=='#'):
                    data=data[:-1]
                    data=data.encode(encoding='UTF-8')
                    fun2(data)
                    cameraActionState = setCameraAction(data)
                    cameraAction(cameraActionState)
                    print(data)
                    continue
                motorAction(data)
                cameraActionState = setCameraAction(data)
                cameraAction(cameraActionState)
        except:
            continue




main()
