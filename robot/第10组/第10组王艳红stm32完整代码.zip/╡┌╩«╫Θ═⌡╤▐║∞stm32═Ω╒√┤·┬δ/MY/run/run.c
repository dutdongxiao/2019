#include "run.h"
#include "delay.h"
#include "tim3.h"

void Car_init(void)
{
	TIM3_PWM_Init();
	TIM3_Init();
	SysTick_Init();
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
}

void Car_up(void)
{
	GPIO_SetBits(GPIOE, GPIO_Pin_1);
	GPIO_SetBits(GPIOE, GPIO_Pin_3);
	GPIO_ResetBits(GPIOE,GPIO_Pin_2);
  GPIO_ResetBits(GPIOE,GPIO_Pin_4);
}

void Car_down(void)
{	
	GPIO_SetBits(GPIOE, GPIO_Pin_2);
	GPIO_SetBits(GPIOE, GPIO_Pin_4);
	GPIO_ResetBits(GPIOE,GPIO_Pin_1);
  GPIO_ResetBits(GPIOE,GPIO_Pin_3);
}

void Car_left(void)
{
	GPIO_SetBits(GPIOE, GPIO_Pin_2);
	GPIO_SetBits(GPIOE, GPIO_Pin_4);
	GPIO_SetBits(GPIOE,GPIO_Pin_1);
  GPIO_SetBits(GPIOE,GPIO_Pin_3);
}

void Car_right(void)
{
	GPIO_ResetBits(GPIOE, GPIO_Pin_2);
	GPIO_ResetBits(GPIOE, GPIO_Pin_4);
	GPIO_ResetBits(GPIOE,GPIO_Pin_1);
  GPIO_ResetBits(GPIOE,GPIO_Pin_3);
}

void Car_stop(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,DISABLE);
}

void Car_go(void)
{
	TIM3_Init();
}
