#ifndef _hc_sr501_H
#define _hc_sr501_H

#include "stm32f10x.h"


void HC_SR(void);
u8 HC_SR501_Statue(void);

#endif
