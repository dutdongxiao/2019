#ifndef __DUOJI_H
#define __DUOJI_H

#include "stm32f10x.h"
#include "delay.h"

void Duoji_init(void);
void Duoji_up(int y);
void Duoji_left(int x);

#endif
