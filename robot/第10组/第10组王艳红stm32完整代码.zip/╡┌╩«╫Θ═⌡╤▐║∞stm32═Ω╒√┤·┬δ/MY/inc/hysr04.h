#ifndef __HYSR04_H
#define __HYSR04_H

#include "stm32f10x.h"

void Hysr04(void);
void Hysr04_init(void);

#endif
