#ifndef __RUN_H
#define __RUN_H

#include "stm32f10x.h"

void Car_init(void); 
void Car_up(void);
void Car_down(void);
void Car_left(void);
void Car_right(void);
void Car_stop(void);
void Car_go(void);

#endif

