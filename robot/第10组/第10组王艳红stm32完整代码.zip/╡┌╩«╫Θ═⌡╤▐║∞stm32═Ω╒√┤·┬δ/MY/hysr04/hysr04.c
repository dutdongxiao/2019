#include "tim2.h"
#include <math.h>
#include "delay.h"
#include "run.h"
#include "hysr04.h"
#include "stm32f10x.h"

int TIM2_Flag = 0;

void Hysr04_init(void)
{
	SystemInit();
	SysTick_Init();
	TIM2_Init();
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
/*Echo pin define*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
/*Trigle pin define*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
}

void Hysr04(void)
{
		int distance = 0;
		u16 TIM = 0;
		TIM_Cmd(TIM2, ENABLE); 
		
		GPIO_SetBits(GPIOE,GPIO_Pin_12);
    Delay_us(10);
		GPIO_ResetBits(GPIOE,GPIO_Pin_12);
		
		while((!GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_11))&&TIM2_Flag==0);  
		TIM2->CNT = 0;              
		while(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_11)&&TIM2_Flag==0);   
		TIM_Cmd(TIM2, DISABLE);      
  
		if(TIM2_Flag==1)
			TIM2_Flag = 0;
  
		TIM = TIM_GetCounter(TIM2);
		distance = TIM*0.85;
		int diatance_Data = distance;
    int qian = diatance_Data/1000;
    int bai = diatance_Data/100%10;
    int shi = diatance_Data/10%10;
    int ge = diatance_Data%10;
    diatance_Data = qian*1000+bai*100+shi*10+ge;
    if(TIM2_Flag == 1)
    { 
      TIM2_Flag = 0;
    }
    if(diatance_Data<200)     
    {
      //GPIO_SetBits(GPIOC, GPIO_Pin_6);
			Car_left();
    }
//    else
//    {
//      //GPIO_ResetBits(GPIOC, GPIO_Pin_6);
//			Car_go();
//    }
}
