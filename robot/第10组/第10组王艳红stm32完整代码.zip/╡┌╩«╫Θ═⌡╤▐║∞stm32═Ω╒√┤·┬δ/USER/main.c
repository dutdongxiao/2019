#include "hysr04.h"
//#include "run.h"

//#include "stm32f10x.h"//���ͷ�ļ�
//#include "delay.h"
//#include "duoji.h"

//���ϲ���
//int main()
//{
//  	Car_init();
//	Hysr04_init();
//	Car_up(); 
//	while(1)
//	{
//		Hysr04();
//	}
//}
//���Ͻ���


//�������
//int main()
//{
//	Duoji_init();
//	Duoji_up();
//	Duoji_down();
//	Duoji_left();
//	Duoji_middle();
//	Duoji_right();
//	
//	while(1)
//	{
//	}
//}

//�������

//���ڲ���
#include "stm32f10x.h"
#include "led.h"
#include "delay.h"
#include "key.h"
#include "usart2.h"
#include "run.h"
#include "hc_sr501.h"
#include "duoji.h"

int main(void)//���հ汾
{
	extern int flag;
	extern int x;
	extern int y;
  //uint8_t j; 
  LED_Init();
  KEY_Init();
  uart2_init(115200);
	Duoji_init();
  SysTick_Init();
	Hysr04_init();
	HC_SR();
//	char *mes="123$";
//	RS232_1_Send_Data((u8*)mes,6);
	while(1)
	{
		Hysr04();
		if(HC_SR501_Statue()==1)
		{
			Car_stop();
			for(int i=0;i<5;i++)
			{
				for(int i=0;i<100;i++)
				{
					GPIO_SetBits(GPIOC,GPIO_Pin_3);
					Delay_us(1000);
					GPIO_ResetBits(GPIOC,GPIO_Pin_3);
					Delay_us(1000);
				}
				for(int i=0;i<9;i++)
				{
					GPIO_SetBits(GPIOC,GPIO_Pin_3);
					Delay_us(10000);
					GPIO_ResetBits(GPIOC,GPIO_Pin_3);
					Delay_us(10000);
				}
			}
			for(int y=195;y>=189;y--)
			{
				if(flag==0)
						break;
				for(int x=181;x<=195;x++)
				{
					if(flag==0)
						break;
					else
					{
						Duoji_left(x);
						Delay_ms(500);
					}
				}
				Duoji_up(y);
				Delay_ms(500);
			}
				flag=0;
		}
		if(flag==0)
			break;
	}
	while(1)
	{
		Hysr04();
	}
}



//int main()
//{
//	SystemInit();
//	SysTick_Init();
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
//	
//	GPIO_InitTypeDef GPIO_InitStructure;
//	/* TIM3��PWM1��PWM2ͨ����Ӧ������PA6��PA7����Щ������Ӳ���ֲ����ҵ�*/
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//	GPIO_Init(GPIOC, &GPIO_InitStructure);
//	
//	while(1)
//	{
//			GPIO_SetBits(GPIOC,GPIO_Pin_1);
//		else
//			GPIO_ResetBits(GPIOC,GPIO_Pin_1);
//	}
//}

////���ڽ���


//������
//#include "stm32f10x.h"
//#include "hc_sr501.h"
//#include "delay.h"
//#include "tim3.h"
//int main()
//{
//	SysTick_Init();
//	HC_SR();
//	while(1)
//	{	
//		//������		
//		if(HC_SR501_Statue()==1)
//		{
//			GPIO_ResetBits(GPIOE,GPIO_Pin_14);
//			for(int i=0;i<2000;i++)
//			{
//				GPIO_SetBits(GPIOE,GPIO_Pin_12);
//				Delay_us(1000);
//				GPIO_ResetBits(GPIOE,GPIO_Pin_12);
//				Delay_us(1000);
//			}
//			break;
//		}
//	}
//}
	
