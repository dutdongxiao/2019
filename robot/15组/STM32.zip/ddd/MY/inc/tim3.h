#ifndef __TIM3_H
#define __TIM3_H

#include "stm32f10x.h"	 
  /**************************************************************************
���ߣ�ƽ��С��֮��
�ҵ��Ա�С�꣺http://shop114407458.taobao.com/
**************************************************************************/
void TIM3_Init(void);
void LedPwmCtrl(uint8_t PWM1);
void TIM3_PWM_Init(void);
#endif
