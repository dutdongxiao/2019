#ifndef __TIM2_H
#define __TIM2_H

#include "stm32f10x.h"	 
  /**************************************************************************
���ߣ�ƽ��С��֮��
�ҵ��Ա�С�꣺http://shop114407458.taobao.com/
**************************************************************************/
void TIM2_Init(void);
void pin_init(void);
void TIM2_IRQHandler(void);
#endif
