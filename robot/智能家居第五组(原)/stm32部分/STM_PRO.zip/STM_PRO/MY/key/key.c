#include "key.h"
void KEY_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
	//PB8 IS A EX_KEY TO CONTROLL BEEP
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	//PE2 IS A EX_KEY TO CONTROLL LED
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	
  GPIO_Init(GPIOE, &GPIO_InitStructure);
	
	//PD3 IS A EX_KEY TO CONTROLL FAN
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	
  GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	//PB14 IS A EX_KEY TO CONTROLL DOOR
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
}
