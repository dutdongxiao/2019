#ifndef __CONRTOLLER_H
#define __CONRTOLLER_H

#include "stm32f10x.h"

#define LED_ON GPIO_SetBits(GPIOE,GPIO_Pin_5)
#define LED_OFF GPIO_ResetBits(GPIOE,GPIO_Pin_5)

#define BEEP_ON GPIO_SetBits(GPIOB,GPIO_Pin_7)
#define BEEP_OFF GPIO_ResetBits(GPIOB,GPIO_Pin_7)

#define FAN_ON GPIO_SetBits(GPIOD,GPIO_Pin_2)
#define FAN_OFF GPIO_ResetBits(GPIOD,GPIO_Pin_2)

void BEEP_Init(void);
void LED_Init(void);
void FAN_Init(void);
void TIM3_Init(void);
void TIM3_PWM_Init(void);
#endif
