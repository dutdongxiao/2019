
#ifndef __KEY_H
#define __KEY_H

#include "stm32f10x.h"

#define BEEP_KEY GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)
#define LED_KEY GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_2)
#define FAN_KEY GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_3)
#define DOOR_KEY GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14)

void KEY_Init(void);

#endif
