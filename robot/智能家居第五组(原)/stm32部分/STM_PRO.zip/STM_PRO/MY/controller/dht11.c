#include "dht11.h"

void dht11_Input(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
}

void dht11_Output(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
}

void dht11_reset(void)
{
  dht11_Output();
	GPIO_ResetBits(GPIOB,GPIO_Pin_11);
	Delay_ms(20);
	GPIO_SetBits(GPIOB,GPIO_Pin_11);
	Delay_us(30);
  dht11_Input();
}

u16 dht11_scan(void)
{
	return GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11);
}

u16 dht11_read_bit(void)
{
	while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11) == RESET){;}
  Delay_us(40);
  if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11) == SET)
  { 
    while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11) == SET);
    return 1;
  }
  else
  {
    return 0;
  }
}

u16 dht11_read_byte(void)
{	
	u16 i;
  u16 data = 0;
  for (i = 0; i < 8; i++)
  {
    data <<= 1;
    data |= dht11_read_bit();
  }
  return data;
}
u16 dht11_read_data(u8 buffer[5])
{
    u16 i = 0;
    
    dht11_reset();
    if (dht11_scan() == RESET)
    {
        while (dht11_scan() == RESET);
        while (dht11_scan() == SET);
        for (i = 0; i < 5; i++)
        {
            buffer[i] = dht11_read_byte();
        }
        
        while (dht11_scan() == RESET);
        dht11_Output();
        GPIO_SetBits(GPIOB,GPIO_Pin_11);
        
        u8 checksum = buffer[0] + buffer[1] + buffer[2] + buffer[3];
        if (checksum != buffer[4])
        {
            // checksum error
            return 1;
        }
    }
    
    return 0;
}

