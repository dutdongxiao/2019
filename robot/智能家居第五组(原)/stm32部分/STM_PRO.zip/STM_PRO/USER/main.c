
#include "stm32f10x.h"
#include "controller.h"
#include "delay.h"
#include "key.h"
#include "usart1.h"
#include "dht11.h"

int main(void)
{
	uart1_init(115200);	
	BEEP_Init();//BEEP��ʼ��
	LED_Init();
  KEY_Init();//������ʼ��
	FAN_Init();
  SysTick_Init();//��ʱ��ʼ
	TIM3_Init();
	TIM3_PWM_Init();//time initial
	LED_OFF;
	TIM_SetCompare1(TIM3,13);
	u8 buffer[5];
	int flag = 0;
	double hum,temp;
  while(1)
  {
		Delay_ms(1000);
		if(dht11_read_data(buffer)==0)
		{
			hum = buffer[0]+buffer[1]/10.0;
			temp = buffer[2]+buffer[3]/10.0;
			usart_printf("temperature: %.2f, humidness: %.2f\n", temp, hum);
			if(FAN_KEY==0)
			{
				if(temp>32.50)
				{
					FAN_ON;
					flag = 1;
					Delay_ms(1);
					BEEP_ON;
					Delay_ms(100);
					BEEP_OFF;
					Delay_ms(100);
					BEEP_ON;
					Delay_ms(100);
					BEEP_OFF;		
					Delay_ms(100);
					BEEP_ON;
					Delay_ms(100);
					BEEP_OFF;					
					Delay_ms(100);
				}
				else flag= 0;
			}
		}
		else
			usart_printf("error\n");
		if(DOOR_KEY)
		{
			TIM_SetCompare1(TIM3,21);
		}
		else
		{
			TIM_SetCompare1(TIM3,13);	
		}		
		
		if(LED_KEY)
			LED_ON;
		else
			LED_OFF;
		if(FAN_KEY||flag==1)
			FAN_ON;
		else
			FAN_OFF;
		if(BEEP_KEY)
		{
			while(BEEP_KEY)
			{
				BEEP_ON;
				Delay_ms(100);
				BEEP_OFF;
				Delay_ms(100);
			}
		}
	}
}

