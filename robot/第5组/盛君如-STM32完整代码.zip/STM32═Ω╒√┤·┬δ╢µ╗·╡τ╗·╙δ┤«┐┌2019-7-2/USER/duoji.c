#include "stm32f10x.h"
#include "bsp_Advance_tim.h"
#include "delay.h"
void duoji_Init()
{
	int delay_time;
	delay_init();
	TIM_Init();
//	delay_time = 500;
//	delay_ms(delay_time);
//	TIM_SetCompare1(ADVANCE_TIM, 195);
/*	delay_ms(delay_time);
	TIM_SetCompare1(ADVANCE_TIM, 190);//0
	*/
/*	while(1)
	{
		delay_ms(delay_time);
		TIM_SetCompare1(ADVANCE_TIM, 175);//ADVANCE_TIM �� TIM1��������180��
		delay_ms(delay_time);
   	TIM_SetCompare1(ADVANCE_TIM, 180);//135
		delay_ms(delay_time);
		TIM_SetCompare1(ADVANCE_TIM, 185);//90
		delay_ms(delay_time);
		TIM_SetCompare1(ADVANCE_TIM, 190);//45
		delay_ms(delay_time);
		TIM_SetCompare1(ADVANCE_TIM, 195);//0
	}
*/
}


