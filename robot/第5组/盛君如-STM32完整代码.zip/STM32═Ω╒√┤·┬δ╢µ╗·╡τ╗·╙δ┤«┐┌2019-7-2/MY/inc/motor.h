#ifndef __MOTOR_H
#define __MOTOR_H 
#include "sys.h"	

void motor_init(void);
void TIM4_IRQHandler(void);
#endif

