#!/usr/bin/env python
# -*- coding:utf-8 -*-
from flask import Flask, render_template, Response, request
import serial

# 导入 camera
# 注意！！！！！！！！！！！！！如果要启动在线视频监控，需要在TensorFlow官网下载相应的依赖包！！！限于代码大小限制，没有传到Github上去！！
# from camera import Camera

app = Flask(__name__)
global counter
counter=0

@app.route('/')
def index():
    """视频流主页"""
    return render_template('index.html')

@app.route('/expert')
def expert():
    """视频流主页"""
    return render_template('expert.html')

def gen(camera):
    """视频流生成函数"""
    while True:
        frame = camera.get_frame()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')


# 注意！！！！！！！！！！！！！如果要启动在线视频监控，需要在TensorFlow官网下载相应的依赖包！！！限于代码大小限制，没有传到Github上去！！
#@app.route('/video_feed')
#def video_feed():
#    """视频流路由(route).放到 img 标签的 src 属性."""
#    return Response(gen(Camera()),
#                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/do', methods = ["GET","POST"])   # GET 和 POST 都可以
def get_data():
    # 假设有如下 URL
    # http://localhost:5000/?act=stop&para=20

    #可以通过 request 的 args 属性来获取参数
    act = request.args.get("act")
    resp='Unknown Act!'
    portx="/dev/ttyUSB0"
    bps=115200
    timex=5
    if act == 'control':
        id = '#'+request.args.get("para")
        resp='control '+id
        ser=serial.Serial(portx,bps,timeout=timex)
        result=ser.write((id).encode("UTF-8"))
        ser.close()
    if act == 'multicontrol':
        id = "#"+request.args.get("para")
        id=id.replace("!", "!#")
        resp='multicontrol '+"{"+id[:-1]+"}"
        ser=serial.Serial(portx,bps,timeout=timex)
        result=ser.write(("{"+id[:-1]+"}").encode("UTF-8"))
        ser.close()
    if act == 'stopall':
        resp='stop all!'
        ser=serial.Serial(portx,bps,timeout=timex)
        result=ser.write(("$DST!").encode("UTF-8"))
        ser.close()
    if act == 'stop':
        id = request.args.get("id")
        resp='stop '+id
        ser=serial.Serial(portx,bps,timeout=timex)

        result=ser.write(("$DST:"+id+"!").encode("UTF-8"))
        ser.close()
    if act == 'resetall':
        resp='reset all!'
        ser=serial.Serial(portx,bps,timeout=timex)
        result=ser.write(("$DJR!").encode("UTF-8"))
        ser.close()
    if act == 'reset':
        id = request.args.get("id")
        resp='reset '+id
        ser=serial.Serial(portx,bps,timeout=timex)
        result=ser.write(("#"+id+"P1500T2000!").encode("UTF-8"))
        ser.close()
    if act == 'midall':
        resp='mid all!'
        ser=serial.Serial(portx,bps,timeout=timex)
        result=ser.write(("$DJR!").encode("UTF-8"))
        ser.close()
    if act == 'checkall':
        resp='check all!'
        ser=serial.Serial(portx,bps,timeout=timex)
        result=ser.write(("$GETA!").encode("UTF-8"))
        ser.close()

    return resp

@app.route('/get_counter')
def get_counter():
    """视频流路由(route).放到 img 标签的 src 属性."""
    global counter

    return str(counter)

@app.route('/add_counter')
def add_counter():
    """视频流路由(route).放到 img 标签的 src 属性."""
    global counter
    counter=counter+1
    return 'counter='+str(counter)

@app.route('/reset_counter')
def reset_counter():
    """视频流路由(route).放到 img 标签的 src 属性."""
    global counter
    counter=0
    return 'counter='+str(counter)


if __name__ == '__main__':
    
    app.run(host='0.0.0.0', debug=True, threaded=True)

