#include "stm32f10x.h"
#include "delay.h"
#include "usart1.h"
#include "led.h"

/*void left(void){
	GPIO_SetBits(GPIOA,GPIO_Pin_2);
	GPIO_SetBits(GPIOA,GPIO_Pin_3);
	Delay_ms(3000);
	GPIO_ResetBits(GPIOA,GPIO_Pin_2);
}
void right(void){
	GPIO_SetBits(GPIOA,GPIO_Pin_2);
	GPIO_ResetBits(GPIOA,GPIO_Pin_8);
	Delay_ms(3000);
	GPIO_ResetBits(GPIOA,GPIO_Pin_2);
}
void stop(void){
	GPIO_ResetBits(GPIOA,GPIO_Pin_2);
}
void start(void){
	GPIO_SetBits(GPIOA,GPIO_Pin_2);
	GPIO_ResetBits(GPIOA,GPIO_Pin_3);
	GPIO_SetBits(GPIOA,GPIO_Pin_8);
}*/
int main(){
	
	u8 buf[10]="a$";
	
	uart1_init(115200);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	
	
	//USART1_IRQHandler();


	//Res=USART_ReceiveData(USART1);


	
	SysTick_Init();
GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_8|GPIO_Pin_11|GPIO_Pin_12;
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;		 
GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	
	
	
	/* TIM3��PWM1��PWM2ͨ����Ӧ������PA6��PA7	����Щ������Ӳ���ֲ����ҵ�*/
	//A2 ʹ�ܣ�A3 ���ֵ�ת A4 ���ֵ�ת
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;	// ����ΪPWMģʽ	
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE); 
	TIM_TimeBaseStructure.TIM_Period= 199;	//����	
	//TIM_TimeBaseStructure.TIM_Prescaler= 71999;		//��Ƶ7199
	TIM_TimeBaseStructure.TIM_Prescaler= 7199;//��450
	TIM_TimeBaseStructure.TIM_ClockDivision=0;		
	TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up;	//	���ϴ���		
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); 
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
	TIM_OCInitStructure.TIM_Pulse = 0;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);
	TIM_OC2Init(TIM3, &TIM_OCInitStructure);
	TIM_OC3Init(TIM3, &TIM_OCInitStructure);
	TIM_OC4Init(TIM3, &TIM_OCInitStructure);
	TIM_Cmd(TIM3, ENABLE);
	
	
	GPIO_ResetBits(GPIOA,GPIO_Pin_2);//��������ʹ�ܶ�
	GPIO_ResetBits(GPIOA,GPIO_Pin_3);
	GPIO_ResetBits(GPIOA,GPIO_Pin_11);//�ص�
	GPIO_ResetBits(GPIOA,GPIO_Pin_12);//�ط���
	GPIO_SetBits(GPIOA,GPIO_Pin_8);
	TIM_SetCompare1(TIM3, 7 );//����
	TIM_SetCompare2(TIM3, 20);//����
	TIM_SetCompare3(TIM3, 100 );//�������
	TIM_SetCompare4(TIM3, 200 );
	
	
	/*while(1){
		start();
		Delay_ms(3000);
		left();	
		start();
		Delay_ms(3000);
		right();
		start();
		Delay_ms(3000);
		stop();
		Delay_ms(3000);
	}	*/
	//TIM_SetCompare1(TIM3, 3000 );//100΢�봥���ź�
	//GPIO_SetBits(GPIOA,GPIO_Pin_6);
	//RS232_1_Send_Data(buf,2);
	//TIM_SetCompare2(TIM3, 2000 );
	
	/*if(Res=='a')
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_7);
		//Delay_ms(1000);
	  //GPIO_ResetBits(GPIOE,GPIO_Pin_5);
		//Delay_ms(1000);
	}*/
	
	/*while(1){
		for(int i=0;i<100;i=i+5){
			TIM_SetCompare1(TIM3, 4000*i/100 );
			Delay_ms(0.01);
		}	
		for(int i=100;i>0;i=i-5){
			TIM_SetCompare1(TIM3, 4000*i/100 );
			Delay_ms(0.01);
		}
	}*/
	while(1);
}

	/*void LedPwmCtrl(uint8_t PWM)
{
	uint8_t Capture1;
	Capture1 = TIM_GetCapture1(TIM3);
    TIM_SetCompare1(TIM3, 40000*PWM/100 );//����TIMx�Զ���װ�ؼĴ���ֵ
}*/
