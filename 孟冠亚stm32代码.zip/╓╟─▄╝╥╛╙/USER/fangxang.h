
#include "stm32f10x.h"
#include "delay.h"
#include "usart1.h"
#include "led.h"

void left(void){
	GPIO_SetBits(GPIOA,GPIO_Pin_2);
	GPIO_SetBits(GPIOA,GPIO_Pin_3);
	Delay_ms(3000);
	GPIO_ResetBits(GPIOA,GPIO_Pin_2);
}
void right(void){
	GPIO_SetBits(GPIOA,GPIO_Pin_2);
	GPIO_ResetBits(GPIOA,GPIO_Pin_8);
	Delay_ms(3000);
	GPIO_ResetBits(GPIOA,GPIO_Pin_2);
}
void stop(void){
	GPIO_ResetBits(GPIOA,GPIO_Pin_2);
}
void start(void){
	GPIO_SetBits(GPIOA,GPIO_Pin_2);
	GPIO_ResetBits(GPIOA,GPIO_Pin_3);
	GPIO_SetBits(GPIOA,GPIO_Pin_8);
}