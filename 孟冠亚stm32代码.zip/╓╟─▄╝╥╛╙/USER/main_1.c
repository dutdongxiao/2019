#include "stm32f10x.h"
#include "delay.h"
int main(){
	uart1_init(115200);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	
	SysTick_Init();
	/* TIM3��PWM1��PWM2ͨ����Ӧ������PA6��PA7	����Щ������Ӳ���ֲ����ҵ�*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;	// ����ΪPWMģʽ	
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE); 
	TIM_TimeBaseStructure.TIM_Period= 199;	//����	
	TIM_TimeBaseStructure.TIM_Prescaler= 7199;		//��Ƶ
	TIM_TimeBaseStructure.TIM_ClockDivision=0;		
	TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up;	//	���ϴ���		
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); 
	/*4*36/72*/
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
	TIM_OCInitStructure.TIM_Pulse = 0;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);
	TIM_OC2Init(TIM3, &TIM_OCInitStructure);
	TIM_Cmd(TIM3, ENABLE);
	TIM_SetCompare1(TIM3, 5 );//100΢�봥���ź�
	
	TIM_SetCompare2(TIM3, 2000 );
	/*while(1){
		for(int i=0;i<100;i=i+5){
			TIM_SetCompare1(TIM3, 4000*i/100 );
			Delay_ms(0.01);
		}	
		for(int i=100;i>0;i=i-5){
			TIM_SetCompare1(TIM3, 4000*i/100 );
			Delay_ms(0.01);
		}
	}*/
}

	/*void LedPwmCtrl(uint8_t PWM)
{
	uint8_t Capture1;
	Capture1 = TIM_GetCapture1(TIM3);
    TIM_SetCompare1(TIM3, 40000*PWM/100 );//����TIMx�Զ���װ�ؼĴ���ֵ
}*/
