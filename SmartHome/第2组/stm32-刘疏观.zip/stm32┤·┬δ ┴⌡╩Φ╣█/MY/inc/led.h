#ifndef __LED_H
#define __LED_H

#include "stm32f10x.h"

#define FAN_ON GPIO_SetBits(GPIOD,GPIO_Pin_1)
#define FAN_OFF GPIO_ResetBits(GPIOD,GPIO_Pin_1)
#define LED_ON GPIO_SetBits(GPIOD,GPIO_Pin_2)
#define LED_OFF GPIO_ResetBits(GPIOD,GPIO_Pin_2)

#define LED2_OFF GPIO_SetBits(GPIOE,GPIO_Pin_5)
#define LED2_ON GPIO_ResetBits(GPIOE,GPIO_Pin_5)
#define LED2_REV GPIO_WriteBit(GPIOE, GPIO_Pin_5,(BitAction)(1-(GPIO_ReadOutputDataBit(GPIOE, GPIO_Pin_5))))

#define LED3_OFF GPIO_SetBits(GPIOB,GPIO_Pin_5)
#define LED3_ON GPIO_ResetBits(GPIOB,GPIO_Pin_5)
#define LED3_REV GPIO_WriteBit(GPIOB, GPIO_Pin_5,(BitAction)(1-(GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_5))))

#define MYLED_ON GPIO_SetBits(GPIOD,GPIO_Pin_1)
#define MYLED_OFF GPIO_ResetBits(GPIOD,GPIO_Pin_1)
#define MYLED_REV GPIO_WriteBit(GPIOD, GPIO_Pin_1,(BitAction)(1-(GPIO_ReadOutputDataBit(GPIOD, GPIO_Pin_1))))


void LED_Init(void);
void FAN_Init(void);

#endif
/*----------------------�·��� ������̳��www.doflye.net--------------------------*/
